<?php
session_start();
require_once '../config/config.php';
require_once '../config/db.php';

// ตรวจสอบการเข้าสู่ระบบ
if (!isset($_SESSION['user_id'])) {
    $_SESSION['error'] = 'กรุณาเข้าสู่ระบบก่อนเพื่อดูสถานที่ท่องเที่ยว';
    header('Location: ' . BASE_PATH . '/auth/login.php');
    exit();
}

// ดึงข้อมูลสถานที่ท่องเที่ยวจากฐานข้อมูล
$search = $_GET['search'] ?? '';
$query = "SELECT * FROM places";
if ($search) {
    $query .= " WHERE name LIKE :search OR description LIKE :search";
}
$query .= " ORDER BY created_at DESC";

$stmt = $pdo->prepare($query);
if ($search) {
    $stmt->execute(['search' => "%$search%"]);
} else {
    $stmt->execute();
}
$places = $stmt->fetchAll();
?>
<!DOCTYPE html>
<html lang="th">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>สถานที่ท่องเที่ยว | PhurinatUD</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css2?family=Athiti:wght@300;400;700&display=swap" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css" rel="stylesheet">
  <link href="../assets/css/style.css" rel="stylesheet">
  <style>
    body { font-family: 'Athiti', sans-serif; background-color: #f8f9fa; }
    .hero-section {
      background: linear-gradient(135deg, #ff6600 0%, #ff8533 100%);
      color: white;
      padding: 80px 0 60px;
      margin-bottom: 40px;
    }
    .place-card { 
      transition: transform 0.3s; 
      border-radius: 15px; 
      overflow: hidden;
      border: none;
      box-shadow: 0 5px 15px rgba(0,0,0,0.08);
    }
    .place-card:hover { 
      transform: translateY(-10px);
      box-shadow: 0 15px 30px rgba(0,0,0,0.15);
    }
    .place-card img { 
      height: 220px; 
      object-fit: cover;
      transition: transform 0.5s;
    }
    .place-card:hover img {
      transform: scale(1.1);
    }
    .category-badge {
      position: absolute;
      top: 10px;
      right: 10px;
      background: rgba(255, 102, 0, 0.9);
      color: white;
      padding: 5px 15px;
      border-radius: 20px;
      font-size: 0.85rem;
      font-weight: 600;
    }
  </style>
</head>
<body>
<?php include('../includes/navbar.php'); ?>

<!-- Hero Section -->
<div class="hero-section">
  <div class="container text-center">
    <h1 class="mb-3">🏞️ สถานที่ท่องเที่ยว</h1>
    <p class="lead mb-4">สำรวจสถานที่ท่องเที่ยวที่น่าสนใจในจังหวัดอุดรธานี</p>
    
    <!-- Search -->
    <div class="row justify-content-center">
      <div class="col-md-6">
        <form method="GET" class="input-group input-group-lg">
          <input type="text" name="search" class="form-control" 
                 placeholder="ค้นหาสถานที่..." value="<?= htmlspecialchars($search) ?>">
          <button class="btn btn-light" type="submit">
            <i class="bi bi-search"></i> ค้นหา
          </button>
        </form>
      </div>
    </div>
  </div>
</div>

<div class="container pb-5">
  <?php if (count($places) > 0): ?>
    <div class="row g-4">
      <?php foreach ($places as $place): ?>
        <div class="col-md-4">
          <div class="card place-card h-100">
            <div style="overflow: hidden; position: relative;">
              <?php if ($place['image']): ?>
              <img src="<?= htmlspecialchars($place['image']) ?>" class="card-img-top" alt="<?= htmlspecialchars($place['name']) ?>">
              <?php else: ?>
              <div class="bg-secondary d-flex align-items-center justify-content-center text-white" style="height: 220px;">
                <i class="bi bi-image" style="font-size: 4rem;"></i>
              </div>
              <?php endif; ?>
              
              <?php if ($place['category']): ?>
              <span class="category-badge"><?= htmlspecialchars($place['category']) ?></span>
              <?php endif; ?>
            </div>
            
            <div class="card-body">
              <h5 class="card-title fw-bold"><?= htmlspecialchars($place['name']) ?></h5>
              <p class="card-text text-muted">
                <?= htmlspecialchars(mb_substr($place['description'], 0, 100)) ?>...
              </p>
              
              <?php if ($place['latitude'] && $place['longitude']): ?>
              <div class="mb-2">
                <i class="bi bi-geo-alt text-danger"></i>
                <small class="text-muted">
                  <?= number_format($place['latitude'], 4) ?>, <?= number_format($place['longitude'], 4) ?>
                </small>
              </div>
              <?php endif; ?>
              
              <a href="place.php?slug=<?= htmlspecialchars($place['slug']) ?>" class="btn btn-sm btn-outline-primary w-100 mt-2">
                <i class="bi bi-arrow-right-circle"></i> ดูรายละเอียด
              </a>
            </div>
          </div>
        </div>
      <?php endforeach; ?>
    </div>
  <?php else: ?>
    <div class="text-center py-5">
      <i class="bi bi-search" style="font-size: 4rem; color: #ccc;"></i>
      <h3 class="mt-3 text-muted">ไม่พบสถานที่ที่คุณค้นหา</h3>
      <p class="text-muted">ลองค้นหาด้วยคำค้นหาอื่น</p>
      <a href="attractions.php" class="btn btn-primary mt-2">
        <i class="bi bi-arrow-left"></i> กลับหน้าแรก
      </a>
    </div>
  <?php endif; ?>
</div>

<?php include('../includes/footer.php'); ?>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>