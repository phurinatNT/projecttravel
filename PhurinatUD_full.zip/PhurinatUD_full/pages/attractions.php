<?php
session_start();
require_once '../config/config.php';
require_once '../config/db.php';

function normalizePlaceImagePath($path)
{
    $default = '../assets/images/default-place.jpg';
    if (empty($path)) {
        return $default;
    }

    $cleanPath = trim($path);
    if ($cleanPath === '') {
        return $default;
    }

    if (preg_match('#^(?:https?:)?//#', $cleanPath)) {
        return $cleanPath;
    }

    if ($cleanPath[0] === '/') {
        return $cleanPath;
    }

    if (strpos($cleanPath, '../') === 0) {
        return $cleanPath;
    }

    return '../' . ltrim($cleanPath, '/');
}

$categoryLabels = [
  'temple' => 'วัด/ศาสนสถาน',
  'museum' => 'พิพิธภัณฑ์',
  'park' => 'สวนสาธารณะ',
  'market' => 'ตลาด',
  'nature' => 'ธรรมชาติ',
  'other' => 'อื่นๆ',
  'สถานที่ทางศาสนา' => 'สถานที่ทางศาสนา'
];

$categoryAliasNormalization = [
  'ทางศาสนา' => 'สถานที่ทางศาสนา'
];

$categoryAliasGroups = [
  'สถานที่ทางศาสนา' => ['สถานที่ทางศาสนา', 'ทางศาสนา']
];

// ดึงข้อมูลสถานที่ท่องเที่ยวจากฐานข้อมูล
$search = trim($_GET['search'] ?? '');
$selectedCategory = $_GET['category'] ?? '';

$conditions = [];
$params = [];

if (isset($categoryAliasNormalization[$selectedCategory])) {
  $selectedCategory = $categoryAliasNormalization[$selectedCategory];
}

if ($search !== '') {
  $conditions[] = "(name LIKE :search OR description LIKE :search)";
  $params['search'] = "%$search%";
}

if ($selectedCategory !== '') {
  if (isset($categoryAliasGroups[$selectedCategory])) {
    $categoriesList = $categoryAliasGroups[$selectedCategory];
    $placeholderNames = [];
    foreach ($categoriesList as $index => $categoryName) {
      $placeholder = ':category' . $index;
      $placeholderNames[] = $placeholder;
      $params['category' . $index] = $categoryName;
    }
    $conditions[] = 'category IN (' . implode(',', $placeholderNames) . ')';
  } else {
    $conditions[] = "category = :category";
    $params['category'] = $selectedCategory;
  }
}

$query = "SELECT * FROM places";
if ($conditions) {
  $query .= ' WHERE ' . implode(' AND ', $conditions);
}
$query .= " ORDER BY created_at DESC";

$stmt = $pdo->prepare($query);
$stmt->execute($params);
$places = $stmt->fetchAll();

$categoryOptionsStmt = $pdo->query("SELECT DISTINCT category FROM places WHERE category IS NOT NULL AND category <> '' ORDER BY category ASC");
$availableCategoriesRaw = $categoryOptionsStmt->fetchAll(PDO::FETCH_COLUMN);
$availableCategories = [];
foreach ($availableCategoriesRaw as $categoryValue) {
  if ($categoryValue === null || $categoryValue === '') {
    continue;
  }
  $normalized = $categoryAliasNormalization[$categoryValue] ?? $categoryValue;
  if (!in_array($normalized, $availableCategories, true)) {
    $availableCategories[] = $normalized;
  }
}

$recommendedPlaces = [];
if ($selectedCategory !== '') {
  if (isset($categoryAliasGroups[$selectedCategory])) {
    $categoriesList = $categoryAliasGroups[$selectedCategory];
    $placeholders = implode(',', array_fill(0, count($categoriesList), '?'));
    $recStmt = $pdo->prepare("SELECT * FROM places WHERE category IN ($placeholders) ORDER BY RAND() LIMIT 3");
    $recStmt->execute($categoriesList);
  } else {
    $recStmt = $pdo->prepare("SELECT * FROM places WHERE category = ? ORDER BY RAND() LIMIT 3");
    $recStmt->execute([$selectedCategory]);
  }
  $recommendedPlaces = $recStmt->fetchAll();
}
?>
<!DOCTYPE html>
<html lang="th">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>สถานที่ท่องเที่ยว | PhurinatUD</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css2?family=Athiti:wght@300;400;700&display=swap" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css" rel="stylesheet">
  <link href="../assets/css/style.css" rel="stylesheet">
  <style>
    body { font-family: 'Athiti', sans-serif; background-color: #f8f9fa; }
    .hero-section {
      background: linear-gradient(135deg, #ff6600 0%, #ff8533 100%);
      color: white;
      padding: 80px 0 60px;
      margin-bottom: 40px;
    }
    .place-card { 
      transition: transform 0.3s; 
      border-radius: 15px; 
      overflow: hidden;
      border: none;
      box-shadow: 0 5px 15px rgba(0,0,0,0.08);
    }
    .place-card:hover { 
      transform: translateY(-10px);
      box-shadow: 0 15px 30px rgba(0,0,0,0.15);
    }
    .place-card img { 
      height: 220px; 
      object-fit: cover;
      transition: transform 0.5s;
    }
    .place-card:hover img {
      transform: scale(1.1);
    }
    .category-badge {
      position: absolute;
      top: 10px;
      right: 10px;
      background: rgba(255, 102, 0, 0.9);
      color: white;
      padding: 5px 15px;
      border-radius: 20px;
      font-size: 0.85rem;
      font-weight: 600;
    }
  </style>
</head>
<body>
<?php include('../includes/navbar.php'); ?>

<!-- Hero Section -->
<div class="hero-section">
  <div class="container text-center">
    <h1 class="mb-3">สถานที่ท่องเที่ยว</h1>
    <p class="lead mb-4">สำรวจสถานที่ท่องเที่ยวที่น่าสนใจ และเลือกประเภทเพื่อรับคำแนะนำเฉพาะ</p>
    
    <!-- Search -->
    <div class="row justify-content-center">
      <div class="col-lg-9">
        <form method="GET" class="row g-3 align-items-center bg-white p-3 rounded-4 shadow-sm">
          <div class="col-md-5">
            <input type="text" name="search" class="form-control form-control-lg" 
                   placeholder="ค้นหาสถานที่..." value="<?= htmlspecialchars($search) ?>">
          </div>
          <div class="col-md-4">
            <select name="category" class="form-select form-select-lg" onchange="this.form.submit()">
              <option value="">ทุกประเภท</option>
              <?php foreach ($availableCategories as $categoryValue): ?>
                <?php $label = $categoryLabels[$categoryValue] ?? $categoryValue; ?>
                <option value="<?= htmlspecialchars($categoryValue) ?>" <?= $selectedCategory === $categoryValue ? 'selected' : '' ?>>
                  <?= htmlspecialchars($label) ?>
                </option>
              <?php endforeach; ?>
            </select>
          </div>
          <div class="col-md-3 d-grid">
            <button class="btn btn-lg btn-dark" type="submit">
              <i class="bi bi-search"></i> ค้นหา
            </button>
          </div>
        </form>
      </div>
    </div>
  </div>
</div>

<?php if ($selectedCategory !== '' && count($recommendedPlaces) > 0): ?>
<div class="container mb-5">
  <div class="d-flex flex-column flex-md-row align-items-md-center justify-content-between mb-3">
    <div>
      <h3 class="fw-bold mb-1" style="color: #ff6600;">แนะนำสำหรับประเภท "<?= htmlspecialchars($categoryLabels[$selectedCategory] ?? $selectedCategory) ?>"</h3>
      <p class="text-muted mb-0">เลือกประเภทเพื่อดูสถานที่เด่นในหมวดหมู่นั้น</p>
    </div>
  </div>
  <div class="row g-4">
    <?php foreach ($recommendedPlaces as $recommended): ?>
      <div class="col-md-4">
        <div class="card place-card h-100 border-0">
          <div style="overflow: hidden; position: relative;">
            <?php if (!empty($recommended['image'])): ?>
            <img src="<?= htmlspecialchars(normalizePlaceImagePath($recommended['image'])) ?>"
                 class="card-img-top"
                 alt="<?= htmlspecialchars($recommended['name']) ?>"
                 onerror="this.src='../assets/images/default-place.jpg'">
            <?php else: ?>
            <div class="bg-secondary d-flex align-items-center justify-content-center text-white" style="height: 220px;">
              <i class="bi bi-image" style="font-size: 4rem;"></i>
            </div>
            <?php endif; ?>
            <span class="category-badge">แนะนำ</span>
          </div>
          <div class="card-body">
            <h5 class="card-title fw-bold"><?= htmlspecialchars($recommended['name']) ?></h5>
            <p class="card-text text-muted"><?= htmlspecialchars(mb_substr($recommended['description'], 0, 100)) ?>...</p>
            <a href="place.php?slug=<?= urlencode($recommended['slug'] ?? $recommended['name']) ?>" class="btn btn-sm btn-primary w-100 mt-2">
              ดูรายละเอียด
            </a>
          </div>
        </div>
      </div>
    <?php endforeach; ?>
  </div>
</div>
<?php endif; ?>

<div class="container pb-5">
  <?php if (count($places) > 0): ?>
    <div class="row g-4">
      <?php foreach ($places as $place): ?>
        <div class="col-md-4">
          <div class="card place-card h-100">
            <div style="overflow: hidden; position: relative;">
              <?php if (!empty($place['image'])): ?>
              <img src="<?= htmlspecialchars(normalizePlaceImagePath($place['image'])) ?>"
                   class="card-img-top"
                   alt="<?= htmlspecialchars($place['name']) ?>"
                   onerror="this.src='../assets/images/default-place.jpg'">
              <?php else: ?>
              <div class="bg-secondary d-flex align-items-center justify-content-center text-white" style="height: 220px;">
                <i class="bi bi-image" style="font-size: 4rem;"></i>
              </div>
              <?php endif; ?>
              
              <?php if (!empty($place['category'])): ?>
              <span class="category-badge"><?= htmlspecialchars($categoryLabels[$place['category']] ?? $place['category']) ?></span>
              <?php endif; ?>
            </div>
            
            <div class="card-body">
              <h5 class="card-title fw-bold"><?= htmlspecialchars($place['name']) ?></h5>
              <p class="card-text text-muted">
                <?= htmlspecialchars(mb_substr($place['description'], 0, 100)) ?>...
              </p>
              
              <?php if ($place['latitude'] && $place['longitude']): ?>
              <div class="mb-2">
                <i class="bi bi-geo-alt text-danger"></i>
                <small class="text-muted">
                  <?= number_format($place['latitude'], 4) ?>, <?= number_format($place['longitude'], 4) ?>
                </small>
              </div>
              <?php endif; ?>
              
              <?php $placeSlug = $place['slug'] ?? $place['name']; ?>
              <a href="place.php?slug=<?= urlencode($placeSlug) ?>" class="btn btn-sm btn-outline-primary w-100 mt-2">
                <i class="bi bi-arrow-right-circle"></i> ดูรายละเอียด
              </a>
            </div>
          </div>
        </div>
      <?php endforeach; ?>
    </div>
  <?php else: ?>
    <div class="text-center py-5">
      <i class="bi bi-search" style="font-size: 4rem; color: #ccc;"></i>
      <h3 class="mt-3 text-muted">ไม่พบสถานที่ที่คุณค้นหา</h3>
      <p class="text-muted">ลองค้นหาด้วยคำค้นหาอื่น</p>
      <a href="attractions.php" class="btn btn-primary mt-2">
        <i class="bi bi-arrow-left"></i> กลับหน้าแรก
      </a>
    </div>
  <?php endif; ?>
</div>

<?php include('../includes/footer.php'); ?>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>