<?php
session_start();
require_once '../config/config.php';
require_once '../config/db.php';

// ตรวจสอบการเข้าสู่ระบบ
if (!isset($_SESSION['user_id'])) {
    $_SESSION['error'] = 'กรุณาเข้าสู่ระบบก่อนเพื่อดูรายละเอียดสินค้า';
    header('Location: ' . BASE_PATH . '/auth/login.php');
    exit();
}

// ดึงข้อมูลสินค้า
$id = $_GET['id'] ?? 0;
$stmt = $pdo->prepare("SELECT * FROM products WHERE id = ?");
$stmt->execute([$id]);
$product = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$product) {
    header('Location: products.php');
    exit();
}

// ดึงรูปภาพ gallery
$stmt = $pdo->prepare("SELECT * FROM product_images WHERE product_id = ? ORDER BY id ASC");
$stmt->execute([$id]);
$gallery_images = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="th">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?= htmlspecialchars($product['name']) ?> | PhurinatUD</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Athiti:wght@300;400;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">
    <link href="../assets/css/style.css" rel="stylesheet">
    <style>
        body { font-family: 'Athiti', sans-serif; background: #f8f9fa; }
        .product-header {
            background: linear-gradient(135deg, #ff6600 0%, #ff8533 100%);
            color: white;
            padding: 40px 0;
            margin-bottom: 40px;
        }
        .main-image {
            width: 100%;
            height: 400px;
            object-fit: cover;
            border-radius: 15px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
        }
        .gallery-thumb {
            width: 80px;
            height: 80px;
            object-fit: cover;
            border-radius: 8px;
            cursor: pointer;
            transition: all 0.3s;
            border: 2px solid transparent;
        }
        .gallery-thumb:hover, .gallery-thumb.active {
            border-color: #ff6600;
            transform: scale(1.05);
        }
        .info-card {
            background: white;
            border-radius: 15px;
            padding: 30px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.08);
        }
        .price-tag {
            font-size: 32px;
            color: #ff6600;
            font-weight: bold;
        }
        .badge-category {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            padding: 8px 20px;
            border-radius: 20px;
            color: white;
        }
    </style>
</head>
<body>
<?php include('../includes/navbar.php'); ?>

<!-- Header -->
<div class="product-header">
    <div class="container">
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb text-white">
                <li class="breadcrumb-item"><a href="index.php" class="text-white text-decoration-none">หน้าหลัก</a></li>
                <li class="breadcrumb-item"><a href="products.php" class="text-white text-decoration-none">สินค้าชุมชน</a></li>
                <li class="breadcrumb-item active text-white" aria-current="page"><?= htmlspecialchars($product['name']) ?></li>
            </ol>
        </nav>
        <h1 class="display-5 fw-bold"><?= htmlspecialchars($product['name']) ?></h1>
    </div>
</div>

<div class="container pb-5">
    <div class="row g-4">
        <!-- รูปภาพ -->
        <div class="col-lg-6">
            <?php 
            $main_image = !empty($product['image']) ? '../' . htmlspecialchars($product['image']) : '../assets/images/default-product.jpg';
            ?>
            <img src="<?= $main_image ?>" class="main-image" id="mainImage" alt="<?= htmlspecialchars($product['name']) ?>" onerror="this.src='../assets/images/default-product.jpg'">
            
            <?php if (count($gallery_images) > 0): ?>
            <div class="d-flex gap-2 mt-3 flex-wrap">
                <img src="<?= $main_image ?>" class="gallery-thumb active" onclick="changeImage('<?= $main_image ?>', this)" onerror="this.src='../assets/images/default-product.jpg'">
                <?php foreach ($gallery_images as $img): ?>
                    <img src="../<?= htmlspecialchars($img['image_path']) ?>" class="gallery-thumb" onclick="changeImage('../<?= htmlspecialchars($img['image_path']) ?>', this)" onerror="this.src='../assets/images/default-product.jpg'">
                <?php endforeach; ?>
            </div>
            <?php endif; ?>
        </div>

        <!-- ข้อมูลสินค้า -->
        <div class="col-lg-6">
            <div class="info-card">
                <span class="badge-category mb-3 d-inline-block">
                    <?php
                    $categories = [
                        'souvenir' => 'ของที่ระลึก',
                        'food' => 'อาหาร',
                        'craft' => 'งานหัตถกรรม',
                        'fabric' => 'ผ้าทอ',
                        'other' => 'อื่นๆ'
                    ];
                    echo $categories[$product['category']] ?? $product['category'];
                    ?>
                </span>
                
                <h2 class="mb-3"><?= htmlspecialchars($product['name']) ?></h2>
                
                <div class="price-tag mb-4">
                    <?= number_format($product['price'], 2) ?> บาท
                </div>
                
                <div class="mb-4">
                    <h5 class="fw-bold mb-2"><i class="bi bi-card-text text-primary"></i> รายละเอียด</h5>
                    <p class="text-muted" style="line-height: 1.8;">
                        <?= nl2br(htmlspecialchars($product['description'])) ?>
                    </p>
                </div>
                
                <?php if (!empty($product['product_url'])): ?>
                <div class="d-grid gap-2">
                    <a href="<?= htmlspecialchars($product['product_url']) ?>" target="_blank" class="btn btn-lg" style="background: linear-gradient(135deg, #ff6600 0%, #ff8533 100%); color: white; border: none;">
                        <i class="bi bi-cart-plus"></i> ซื้อสินค้านี้
                    </a>
                </div>
                <?php endif; ?>
                
                <div class="mt-4 p-3 bg-light rounded">
                    <small class="text-muted">
                        <i class="bi bi-info-circle"></i> 
                        ข้อมูลเพิ่มเติมหรือสอบถามรายละเอียด กรุณาติดต่อผู้ขายโดยตรง
                    </small>
                </div>
            </div>
        </div>
    </div>

    <!-- สินค้าอื่นๆ -->
    <div class="mt-5">
        <h3 class="mb-4"><i class="bi bi-bag"></i> สินค้าอื่นๆ</h3>
        <div class="row g-4">
            <?php
            $stmt = $pdo->prepare("SELECT * FROM products WHERE id != ? ORDER BY RAND() LIMIT 3");
            $stmt->execute([$id]);
            while ($other = $stmt->fetch(PDO::FETCH_ASSOC)):
                $other_image = !empty($other['image']) ? '../' . htmlspecialchars($other['image']) : '../assets/images/default-product.jpg';
            ?>
            <div class="col-md-4">
                <div class="card border-0 shadow-sm h-100">
                    <img src="<?= $other_image ?>" class="card-img-top" style="height: 200px; object-fit: cover;" onerror="this.src='../assets/images/default-product.jpg'">
                    <div class="card-body">
                        <h5 class="card-title"><?= htmlspecialchars($other['name']) ?></h5>
                        <p class="text-muted small"><?= htmlspecialchars(mb_substr($other['description'], 0, 60)) ?>...</p>
                        <div class="d-flex justify-content-between align-items-center">
                            <span class="fw-bold" style="color: #ff6600;"><?= number_format($other['price'], 2) ?> ฿</span>
                            <a href="product_detail.php?id=<?= $other['id'] ?>" class="btn btn-sm btn-outline-primary">ดูรายละเอียด</a>
                        </div>
                    </div>
                </div>
            </div>
            <?php endwhile; ?>
        </div>
    </div>
</div>

<?php include('../includes/footer.php'); ?>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script>
function changeImage(src, element) {
    document.getElementById('mainImage').src = src;
    
    // Remove active class from all thumbnails
    document.querySelectorAll('.gallery-thumb').forEach(thumb => {
        thumb.classList.remove('active');
    });
    
    // Add active class to clicked thumbnail
    element.classList.add('active');
}
</script>
</body>
</html>
