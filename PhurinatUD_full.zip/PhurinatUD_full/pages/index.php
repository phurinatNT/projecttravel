<?php 
session_start();
require_once '../config/config.php'; 
?>
<!DOCTYPE html>
<html lang="th">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>ยินดีต้อนรับสู่อุดรธานี - PhurinatUD</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css2?family=Athiti:wght@300;400;700&display=swap" rel="stylesheet">
  <link href="../assets/css/style.css" rel="stylesheet">
  <style>
    body { font-family: 'Athiti', sans-serif; background-color: #f8f9fa; }
    .hero-section { position: relative; height: 100vh; overflow: hidden; }
    .hero-section img { width: 100%; height: 100%; object-fit: cover; filter: brightness(0.7); }
    .hero-content { position: absolute; top: 50%; left: 50%; transform: translate(-50%, -50%); text-align: center; color: white; z-index: 10; width: 90%; }
    .btn-main { background-color: #ff6600; color: white; padding: 12px 30px; border-radius: 50px; text-decoration: none; display: inline-block; transition: 0.3s; }
    .btn-main:hover { background-color: #ff8533; color: white; transform: scale(1.05); }
    .btn-outline { border: 2px solid white; color: black; padding: 12px 30px; border-radius: 50px; text-decoration: none; display: inline-block; transition: 0.3s; }
    .btn-outline:hover { background-color: rgba(255, 255, 255, 0.2); color: white; }
    .place-card { transition: transform 0.3s; border-radius: 20px; overflow: hidden; }
    .place-card:hover { transform: translateY(-10px); }
    .place-card img { height: 220px; object-fit: cover; transition: transform 0.7s; }
    .place-card:hover img { transform: scale(1.1); }
  </style>
</head>
<body>
<?php include('../includes/navbar.php'); ?>

  <section class="hero-section">
    <img src="../assets/images/udonthani.jpg" alt="Udon Thani">
    <div class="hero-content">
      <h1 class="display-3 fw-bold mb-3">ยินดีต้อนรับสู่เมืองอุดรธานี</h1>
      <p class="fs-5 mb-4">สัมผัสวัฒนธรรม ธรรมชาติ และเสน่ห์ท้องถิ่นของอุดรธานี</p>
      <div class="mt-4">
        <a href="#places" class="btn-main me-3">เริ่มสำรวจเลย</a>
        <?php if(isset($_SESSION['user_id'])): ?>
          <a href="<?= BASE_PATH ?>/pages/attractions.php" class="btn-outline">ดูสถานที่ทั้งหมด</a>
        <?php else: ?>
          <a href="<?= BASE_PATH ?>/auth/login.php" class="btn-outline">ดูสถานที่ทั้งหมด</a>
        <?php endif; ?>
      </div>
    </div>
    <div style="position: absolute; bottom: 30px; left: 50%; transform: translateX(-50%); color: white; z-index: 10;">
      เลื่อนลงเพื่อดูสถานที่แนะนำ ↓
    </div>
  </section>

  <section id="places" class="py-5 bg-white">
    <div class="container">
      <h2 class="text-center fw-bold mb-5" style="color: #ff6600; font-size: 2.5rem;">สถานที่แนะนำของเรา</h2>
      <div class="row g-4">
        <?php
          $places = [
            ['name'=>'สวนสาธารณะหนองประจักษ์','desc'=>'สวนสาธารณะใจกลางเมือง มีเป็ดยักษ์สีเหลืองเป็นสัญลักษณ์','img'=>'../assets/images/13.jpg'],
            ['name'=>'ทะเลบัวแดง','desc'=>'เป็นแหล่งท่องเที่ยวจังหวัดอุดรธานี ดอกบัวสีชมพูจำนวนมหาศาลจะบานสะพรั่งเต็มผืนน้ำ ทำให้เกิดภาพทิวทัศน์ที่งดงามสุดลูกหูลูกตา','img'=>'../assets/images/3.jpg'],
            ['name'=>'พิพิธภัณฑ์บ้านเชียง','desc'=>'ตั้งอยู่ที่อำเภอหนองหาน จังหวัดอุดรธานี เป็นสถานที่สำคัญทางประวัติศาสตร์และโบราณคดี ที่ได้รับการขึ้นทะเบียนเป็นมรดกโลกโดย UNESCO','img'=>'../assets/images/9.jpg'],
            ['name'=>'คำชะโนด','desc'=>'เป็นสถานที่ศักดิ์สิทธิ์ที่ตั้งอยู่ในพื้นที่ป่าบนเกาะกลางน้ำที่เต็มไปด้วยต้นชะโนดในอำเภอบ้านดุง จังหวัดอุดรธานี','img'=>'../assets/images/k10.jpg'],
            ['name'=>'อุทยานภูพระบาท','desc'=>'เป็นแหล่งมรดกโลกทางวัฒนธรรมแห่งใหม่ล่าสุดของประเทศไทย ตั้งอยู่ในเขตตำบลเมืองพาน อำเภอบ้านผือ จังหวัดอุดรธานี เป็นเพิงหินและภาพเขียนสีโบราณ มีทัศนียภาพที่น่าตื่นตา','img'=>'../assets/images/p2.jpg'],
            ['name'=>'วัดป่าภูก้อน','desc'=>'ตั้งอยู่ในเขตป่าสงวนแห่งชาติป่านายูงและป่าน้ำโสม อำเภอนายูง จังหวัดอุดรธานี เป็นวัดที่มีทัศนียภาพงดงามบนยอดเขา ','img'=>'../assets/images/4.jpg']
          ];
          foreach($places as $p){
            echo '<div class="col-md-4">';
            echo '<div class="card place-card shadow-sm border-0">';
            echo '<div style="overflow: hidden;"><img src="'.$p['img'].'" class="card-img-top" alt="'.$p['name'].'"></div>';
            echo '<div class="card-body">';
            echo '<h5 class="card-title fw-bold">'.$p['name'].'</h5>';
            echo '<p class="card-text text-muted">'.$p['desc'].'</p>';
            echo '<a href="'.BASE_PATH.'/pages/place.php?name='.urlencode($p['name']).'" class="text-decoration-none" style="color: #ff6600;">ดูรายละเอียด →</a>';
            echo '</div></div>';
            echo '</div>';
          }
        ?>
      </div>
    </div>
  </section>

  <?php include('../includes/footer.php'); ?>
  
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>