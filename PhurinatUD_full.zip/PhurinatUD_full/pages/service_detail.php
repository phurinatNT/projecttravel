<?php
session_start();
require_once '../config/config.php';
require_once '../config/db.php';

if (!isset($_SESSION['user_id'])) {
    $_SESSION['error'] = 'กรุณาเข้าสู่ระบบก่อนเพื่อดูรายละเอียดสถานที่บริการ';
    header('Location: ' . BASE_PATH . '/auth/login.php');
    exit();
}

$id = isset($_GET['id']) ? (int) $_GET['id'] : 0;
if ($id <= 0) {
    header('Location: services.php');
    exit();
}

$stmt = $pdo->prepare("SELECT * FROM services WHERE id = ?");
$stmt->execute([$id]);
$service = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$service) {
    header('Location: services.php');
    exit();
}

function getTypeLabel($type)
{
    $labels = [
        'hospital' => 'โรงพยาบาล',
        'police' => 'สถานีตำรวจ',
        'fire_station' => 'สถานีดับเพลิง',
        'gas_station' => 'ปั๊มน้ำมัน',
        'bank' => 'ธนาคาร',
        'post_office' => 'ไปรษณีย์',
        'other' => 'อื่นๆ'
    ];
    return $labels[$type] ?? $type;
}

function getTypeIcon($type)
{
    $icons = [
        'hospital' => 'bi-hospital',
        'police' => 'bi-shield-fill-check',
        'fire_station' => 'bi-fire',
        'gas_station' => 'bi-fuel-pump',
        'bank' => 'bi-bank',
        'post_office' => 'bi-mailbox',
        'other' => 'bi-info-circle'
    ];
    return $icons[$type] ?? 'bi-info-circle';
}

function getTypeColor($type)
{
    $colors = [
        'hospital' => '#dc3545',
        'police' => '#0d6efd',
        'fire_station' => '#fd7e14',
        'gas_station' => '#198754',
        'bank' => '#6f42c1',
        'post_office' => '#ffc107',
        'other' => '#6c757d'
    ];
    return $colors[$type] ?? '#6c757d';
}
?>
<!DOCTYPE html>
<html lang="th">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= htmlspecialchars($service['name']) ?> | สถานที่บริการ</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Athiti:wght@300;400;700&display=swap" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css" rel="stylesheet">
    <link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css" />
    <link href="../assets/css/style.css" rel="stylesheet">
    <style>
        body {
            font-family: 'Athiti', sans-serif;
            background-color: #f8f9fa;
        }
        .hero {
            background: linear-gradient(135deg, #ff6600 0%, #ff8533 100%);
            color: white;
            padding: 60px 0;
            margin-bottom: 40px;
        }
        .info-card {
            background: white;
            border-radius: 20px;
            padding: 30px;
            box-shadow: 0 10px 25px rgba(0,0,0,0.08);
            margin-bottom: 25px;
        }
        .badge-type {
            background-color: <?= getTypeColor($service['type']) ?>;
            padding: 8px 20px;
            border-radius: 999px;
            color: white;
            font-weight: 600;
        }
        #map {
            height: 380px;
            border-radius: 15px;
        }
    </style>
</head>
<body>
<?php include('../includes/navbar.php'); ?>

<section class="hero">
    <div class="container">
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb text-white">
                <li class="breadcrumb-item"><a href="index.php" class="text-white text-decoration-none">หน้าหลัก</a></li>
                <li class="breadcrumb-item"><a href="services.php" class="text-white text-decoration-none">สถานที่บริการ</a></li>
                <li class="breadcrumb-item active text-white" aria-current="page">รายละเอียด</li>
            </ol>
        </nav>
        <h1 class="fw-bold mb-2"><?= htmlspecialchars($service['name']) ?></h1>
        <span class="badge-type">
            <i class="bi <?= getTypeIcon($service['type']) ?> me-2"></i>
            <?= getTypeLabel($service['type']) ?>
        </span>
    </div>
</section>

<div class="container pb-5">
    <div class="mb-4">
        <a href="services.php" class="btn btn-outline-secondary">
            <i class="bi bi-arrow-left"></i> กลับไปหน้ารายการ
        </a>
    </div>

    <div class="row g-4">
        <div class="col-lg-8">
            <div class="info-card">
                <h4 class="fw-bold mb-3">รายละเอียด</h4>
                <p class="text-muted" style="line-height: 1.8;">
                    <?= nl2br(htmlspecialchars($service['description'] ?: 'ยังไม่มีรายละเอียดเพิ่มเติม')) ?>
                </p>
            </div>

            <?php if (!empty($service['latitude']) && !empty($service['longitude'])): ?>
            <div class="info-card">
                <h4 class="fw-bold mb-3">แผนที่</h4>
                <div id="map"></div>
            </div>
            <?php endif; ?>
        </div>

        <div class="col-lg-4">
            <div class="info-card">
                <h4 class="fw-bold mb-3">ข้อมูลติดต่อ</h4>
                <?php if (!empty($service['address'])): ?>
                    <div class="mb-3">
                        <small class="text-muted d-block">ที่อยู่</small>
                        <p class="mb-0"><?= nl2br(htmlspecialchars($service['address'])) ?></p>
                    </div>
                <?php endif; ?>
                <?php if (!empty($service['phone'])): ?>
                    <div class="mb-3">
                        <small class="text-muted d-block">โทรศัพท์</small>
                        <a href="tel:<?= htmlspecialchars($service['phone']) ?>" class="text-decoration-none fw-semibold">
                            <?= htmlspecialchars($service['phone']) ?>
                        </a>
                    </div>
                <?php endif; ?>
                <?php if (!empty($service['operating_hours'])): ?>
                    <div>
                        <small class="text-muted d-block">เวลาให้บริการ</small>
                        <p class="mb-0"><?= nl2br(htmlspecialchars($service['operating_hours'])) ?></p>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<?php include('../includes/footer.php'); ?>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script>
<?php if (!empty($service['latitude']) && !empty($service['longitude'])): ?>
<script>
    const map = L.map('map').setView([<?= $service['latitude'] ?>, <?= $service['longitude'] ?>], 15);
    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        attribution: '© OpenStreetMap contributors'
    }).addTo(map);
    L.marker([<?= $service['latitude'] ?>, <?= $service['longitude'] ?>]).addTo(map)
        .bindPopup('<?= htmlspecialchars($service['name']) ?>')
        .openPopup();
</script>
<?php endif; ?>
</body>
</html>
