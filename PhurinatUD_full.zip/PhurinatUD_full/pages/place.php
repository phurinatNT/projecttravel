<?php
// pages/place.php
session_start();
require_once '../config/config.php';

// ตรวจสอบการเข้าสู่ระบบ
if (!isset($_SESSION['user_id'])) {
    $_SESSION['error'] = 'กรุณาเข้าสู่ระบบก่อนเพื่อดูรายละเอียดสถานที่';
    header('Location: ' . BASE_PATH . '/auth/login.php');
    exit();
}

// config DB (ปรับค่าให้ตรงกับเครื่องของคุณ)
$dbHost = 'localhost';
$dbName = 'udonjourney';
$dbUser = 'root';
$dbPass = 'root'; // เปลี่ยนตามจริง

try {
  $pdo = new PDO("mysql:host=$dbHost;dbname=$dbName;charset=utf8mb4", $dbUser, $dbPass, [
    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION
  ]);
} catch (Exception $e) {
  die('Database connection failed: ' . $e->getMessage());
}

// รับ slug หรือ name จาก query (ผมใช้ slug เพื่อปลอดภัย)
$slug = isset($_GET['slug']) ? $_GET['slug'] : (isset($_GET['name']) ? urlencode($_GET['name']) : null);
if (!$slug) {
  echo "ไม่พบสถานที่";
  exit;
}

// ดึงข้อมูลสถานที่
$stmt = $pdo->prepare("SELECT * FROM places WHERE slug = :slug OR name = :name LIMIT 1");
$stmt->execute([':slug' => $slug, ':name' => urldecode($slug)]);
$place = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$place) {
  echo "ไม่พบข้อมูลสถานที่: " . htmlspecialchars($slug);
  exit;
}
?>
<!DOCTYPE html>
<html lang="th">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title><?=htmlspecialchars($place['name'])?> | PhurinatUD</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css2?family=Athiti:wght@300;400;700&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="https://unpkg.com/leaflet/dist/leaflet.css" />
  <link href="../assets/css/style.css" rel="stylesheet">
  
  <style>
    body { font-family: 'Athiti', sans-serif; background-color: #f8f9fa; }
    .container { max-width: 900px; margin-top: 40px; }
    #map { height: 400px; border-radius: 16px; margin-top: 15px; }
    .place-img { border-radius: 16px; box-shadow: 0 3px 10px rgba(0,0,0,0.15); }
    .btn-back {
      background-color: #ff6600; color: #fff; border-radius: 50px;
      padding: 8px 20px; text-decoration: none; transition: .3s;
    }
    .btn-back:hover { background-color: #ff8533; color: white; }
  </style>
</head>
<body>
  <?php include('../includes/navbar.php'); ?>
  <div class="container bg-white p-4 shadow rounded">
    <h2 class="fw-bold mb-3 text-center"><?=htmlspecialchars($place['name'])?></h2>
    <?php if(!empty($place['image'])): ?>
      <img src="<?=htmlspecialchars($place['image'])?>" alt="" class="place-img w-100 mb-3">
    <?php endif; ?>
    <p class="lead"><?=nl2br(htmlspecialchars($place['description']))?></p>

    <div id="map"></div>

    <div class="text-center mt-4">
      <a href="<?= BASE_PATH ?>/pages/index.php" class="btn-back">กลับหน้าหลัก</a>
    </div>
  </div>

  <script src="https://unpkg.com/leaflet/dist/leaflet.js"></script>
  <script>
    const lat = <?= $place['latitude'] ?? '0' ?>;
    const lng = <?= $place['longitude'] ?? '0' ?>;
    const name = <?= json_encode($place['name']) ?>;
    const map = L.map('map').setView([lat, lng], 13);
    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
      attribution: '&copy; OpenStreetMap contributors'
    }).addTo(map);
    L.marker([lat, lng]).addTo(map).bindPopup(name).openPopup();
  </script>
  
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>

