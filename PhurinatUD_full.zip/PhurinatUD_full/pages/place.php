<?php
session_start();
require_once '../config/config.php';
require_once '../config/db.php';

function normalizePlaceImagePath($path)
{
    $default = '../assets/images/default-place.jpg';
    if (empty($path)) {
        return $default;
    }

    $cleanPath = trim($path);
    if ($cleanPath === '') {
        return $default;
    }

    if (preg_match('#^(?:https?:)?//#', $cleanPath)) {
        return $cleanPath;
    }

    if ($cleanPath[0] === '/') {
        return $cleanPath;
    }

    if (strpos($cleanPath, '../') === 0) {
        return $cleanPath;
    }

    return '../' . ltrim($cleanPath, '/');
}

// ตรวจสอบการเข้าสู่ระบบ
if (!isset($_SESSION['user_id'])) {
    $_SESSION['error'] = 'กรุณาเข้าสู่ระบบก่อนเพื่อดูรายละเอียดสถานที่';
    header('Location: ' . BASE_PATH . '/auth/login.php');
    exit();
}

// รับ slug หรือ name จาก query
$slug = isset($_GET['slug']) ? $_GET['slug'] : (isset($_GET['name']) ? urlencode($_GET['name']) : null);
if (!$slug) {
    echo "ไม่พบสถานที่";
    exit;
}

// ดึงข้อมูลสถานที่
$stmt = $pdo->prepare("SELECT * FROM places WHERE slug = :slug OR name = :name LIMIT 1");
$stmt->execute([':slug' => $slug, ':name' => urldecode($slug)]);
$place = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$place) {
    echo "ไม่พบข้อมูลสถานที่: " . htmlspecialchars($slug);
    exit;
}

// ดึงรูปภาพ gallery
$stmt = $pdo->prepare("SELECT * FROM place_images WHERE place_id = ? ORDER BY id ASC");
$stmt->execute([$place['id']]);
$gallery_images = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="th">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?= htmlspecialchars($place['name']) ?> | PhurinatUD</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Athiti:wght@300;400;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">
    <link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css" />
    <link href="../assets/css/style.css" rel="stylesheet">
    
    <style>
        body { 
            font-family: 'Athiti', sans-serif; 
            background: #f8f9fa; 
        }
        .place-header {
            background: linear-gradient(135deg, #ff6600 0%, #ff8533 100%);
            color: white;
            padding: 40px 0;
            margin-bottom: 40px;
        }
        .main-image {
            width: 100%;
            height: 500px;
            object-fit: cover;
            border-radius: 20px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.15);
        }
        .gallery-thumb {
            width: 100px;
            height: 100px;
            object-fit: cover;
            border-radius: 12px;
            cursor: pointer;
            transition: all 0.3s;
            border: 3px solid transparent;
        }
        .gallery-thumb:hover, .gallery-thumb.active {
            border-color: #ff6600;
            transform: scale(1.05);
            box-shadow: 0 5px 15px rgba(255, 102, 0, 0.3);
        }
        .info-card {
            background: white;
            border-radius: 20px;
            padding: 35px;
            box-shadow: 0 5px 20px rgba(0,0,0,0.08);
            margin-bottom: 25px;
        }
        .info-card h4 {
            color: #ff6600;
            font-weight: 600;
            margin-bottom: 20px;
        }
        .info-item {
            background: #f8f9fa;
            padding: 15px 20px;
            border-radius: 12px;
            margin-bottom: 15px;
            border-left: 4px solid #ff6600;
        }
        .info-item i {
            color: #ff6600;
            font-size: 1.3rem;
            margin-right: 10px;
        }
        #map {
            height: 450px;
            border-radius: 15px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
        }
        .breadcrumb-item a {
            text-decoration: none;
        }
        .description-text {
            font-size: 1.15rem;
            line-height: 2;
            color: #555;
        }
        .contact-box {
            background: linear-gradient(135deg, #ff6600 0%, #ff8533 100%);
            color: white;
            padding: 25px;
            border-radius: 15px;
            text-align: center;
        }
        .contact-box i {
            font-size: 2rem;
            margin-bottom: 15px;
        }
    </style>
</head>
<body>
<?php include('../includes/navbar.php'); ?>

<!-- Header -->
<div class="place-header">
    <div class="container">
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb text-white mb-3">
                <li class="breadcrumb-item"><a href="index.php" class="text-white">หน้าหลัก</a></li>
                <li class="breadcrumb-item"><a href="attractions.php" class="text-white">สถานที่ท่องเที่ยว</a></li>
                <li class="breadcrumb-item active text-white" aria-current="page"><?= htmlspecialchars($place['name']) ?></li>
            </ol>
        </nav>
        <h1 class="display-4 fw-bold mb-2"><?= htmlspecialchars($place['name']) ?></h1>
        <?php if (!empty($place['category'])): ?>
        <p class="lead">
            <i class="bi bi-tag-fill"></i> 
            <?php
            $categories = [
                'temple' => 'วัด/ศาสนสถาน',
                'museum' => 'พิพิธภัณฑ์',
                'park' => 'สวนสาธารณะ',
                'market' => 'ตลาด',
                'nature' => 'ธรรมชาติ',
                'other' => 'อื่นๆ'
            ];
            echo $categories[$place['category']] ?? $place['category'];
            ?>
        </p>
        <?php endif; ?>
    </div>
</div>

<div class="container pb-5">
    <div class="row g-4">
        <!-- คอลัมน์ซ้าย: รูปภาพและรายละเอียด -->
        <div class="col-lg-8">
            <!-- รูปภาพหลัก -->
              <?php 
              $main_image = normalizePlaceImagePath($place['image']);
              ?>
              <img src="<?= htmlspecialchars($main_image) ?>" 
                 class="main-image mb-4" 
                 id="mainImage" 
                 alt="<?= htmlspecialchars($place['name']) ?>"
                 onerror="this.src='../assets/images/default-place.jpg'">
            
            <!-- Gallery Thumbnails -->
            <?php if (count($gallery_images) > 0): ?>
            <div class="d-flex gap-3 mb-4 flex-wrap">
                 <img src="<?= htmlspecialchars($main_image) ?>" 
                     class="gallery-thumb active" 
                     onclick="changeImage('<?= htmlspecialchars($main_image, ENT_QUOTES) ?>', this)"
                     onerror="this.src='../assets/images/default-place.jpg'">
                <?php foreach ($gallery_images as $img): ?>
                    <?php $galleryPath = normalizePlaceImagePath($img['image_path']); ?>
                    <img src="<?= htmlspecialchars($galleryPath) ?>" 
                         class="gallery-thumb" 
                        onclick="changeImage('<?= htmlspecialchars($galleryPath, ENT_QUOTES) ?>', this)"
                         onerror="this.src='../assets/images/default-place.jpg'">
                <?php endforeach; ?>
            </div>
            <?php endif; ?>

            <!-- รายละเอียด -->
            <div class="info-card">
                <h4><i class="bi bi-journal-text"></i> รายละเอียด</h4>
                <p class="description-text">
                    <?= nl2br(htmlspecialchars($place['description'])) ?>
                </p>
            </div>

            <!-- แผนที่ -->
            <?php if (!empty($place['latitude']) && !empty($place['longitude'])): ?>
            <div class="info-card">
                <h4><i class="bi bi-geo-alt-fill"></i> ตำแหน่งที่ตั้ง</h4>
                <div id="map"></div>
            </div>
            <?php endif; ?>
        </div>

        <!-- คอลัมน์ขวา: ข้อมูลเพิ่มเติม -->
        <div class="col-lg-4">
            <!-- ข้อมูลติดต่อ -->
            <div class="info-card sticky-top" style="top: 20px;">
                <h4><i class="bi bi-info-circle-fill"></i> ข้อมูลเพิ่มเติม</h4>
                
                <?php if (!empty($place['open_time'])): ?>
                <div class="info-item">
                    <i class="bi bi-clock"></i>
                    <strong>เวลาเปิด-ปิด:</strong><br>
                    <?= nl2br(htmlspecialchars($place['open_time'])) ?>
                </div>
                <?php endif; ?>

                <?php if (!empty($place['price'])): ?>
                <div class="info-item">
                    <i class="bi bi-cash-coin"></i>
                    <strong>ค่าเข้าชม:</strong><br>
                    <?= nl2br(htmlspecialchars($place['price'])) ?>
                </div>
                <?php endif; ?>

                <?php if (!empty($place['contact'])): ?>
                <div class="info-item">
                    <i class="bi bi-telephone-fill"></i>
                    <strong>ติดต่อ:</strong><br>
                    <a href="tel:<?= htmlspecialchars($place['contact']) ?>" class="text-decoration-none">
                        <?= htmlspecialchars($place['contact']) ?>
                    </a>
                </div>
                <?php endif; ?>

                <?php if (!empty($place['address'])): ?>
                <div class="info-item">
                    <i class="bi bi-pin-map-fill"></i>
                    <strong>ที่อยู่:</strong><br>
                    <?= nl2br(htmlspecialchars($place['address'])) ?>
                </div>
                <?php endif; ?>

                <!-- ปุ่มดำเนินการ -->
                <div class="contact-box mt-4">
                    <i class="bi bi-map"></i>
                    <h5 class="mb-3">ต้องการเดินทาง?</h5>
                    <?php if (!empty($place['latitude']) && !empty($place['longitude'])): ?>
                    <a href="https://www.google.com/maps?q=<?= $place['latitude'] ?>,<?= $place['longitude'] ?>" 
                       target="_blank" 
                       class="btn btn-light btn-lg w-100">
                        <i class="bi bi-compass"></i> เปิดใน Google Maps
                    </a>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>

    <!-- สถานที่แนะนำอื่นๆ -->
    <div class="mt-5">
        <h3 class="mb-4"><i class="bi bi-geo-fill"></i> สถานที่แนะนำอื่นๆ</h3>
        <div class="row g-4">
            <?php
            $stmt = $pdo->prepare("SELECT * FROM places WHERE id != ? ORDER BY RAND() LIMIT 3");
            $stmt->execute([$place['id']]);
            while ($other = $stmt->fetch(PDO::FETCH_ASSOC)):
                $other_image = normalizePlaceImagePath($other['image']);
            ?>
            <div class="col-md-4">
                <div class="card border-0 shadow-sm h-100 hover-card">
                    <img src="<?= htmlspecialchars($other_image) ?>" 
                         class="card-img-top" 
                         style="height: 220px; object-fit: cover;"
                         onerror="this.src='../assets/images/default-place.jpg'">
                    <div class="card-body">
                        <h5 class="card-title fw-bold"><?= htmlspecialchars($other['name']) ?></h5>
                        <p class="text-muted small"><?= htmlspecialchars(mb_substr($other['description'], 0, 80)) ?>...</p>
                        <a href="place.php?slug=<?= urlencode($other['slug'] ?? $other['name']) ?>" 
                           class="btn btn-outline-primary w-100">
                            <i class="bi bi-eye"></i> ดูรายละเอียด
                        </a>
                    </div>
                </div>
            </div>
            <?php endwhile; ?>
        </div>
    </div>
</div>

<?php include('../includes/footer.php'); ?>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>

<!-- Leaflet Map -->
<?php if (!empty($place['latitude']) && !empty($place['longitude'])): ?>
<script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script>
<script>
    const lat = <?= $place['latitude'] ?? '0' ?>;
    const lng = <?= $place['longitude'] ?? '0' ?>;
    const name = <?= json_encode($place['name']) ?>;
    
    const map = L.map('map').setView([lat, lng], 15);
    
    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        attribution: '© OpenStreetMap contributors'
    }).addTo(map);
    
    L.marker([lat, lng]).addTo(map)
        .bindPopup(`<b>${name}</b><br><?= htmlspecialchars($place['address'] ?? '') ?>`)
        .openPopup();
</script>
<?php endif; ?>

<!-- Gallery Image Changer -->
<script>
function changeImage(src, element) {
    document.getElementById('mainImage').src = src;
    
    // Remove active class from all thumbnails
    document.querySelectorAll('.gallery-thumb').forEach(thumb => {
        thumb.classList.remove('active');
    });
    
    // Add active class to clicked thumbnail
    element.classList.add('active');
}
</script>
</body>
</html>

