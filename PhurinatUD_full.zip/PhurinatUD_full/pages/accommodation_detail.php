<?php
session_start();
require_once '../config/config.php';
require_once '../config/db.php';

// ตรวจสอบการเข้าสู่ระบบ
if (!isset($_SESSION['user_id'])) {
    $_SESSION['error'] = 'กรุณาเข้าสู่ระบบก่อนเพื่อดูรายละเอียดที่พัก';
    header('Location: ' . BASE_PATH . '/auth/login.php');
    exit();
}

// รับ ID ที่พัก
$id = $_GET['id'] ?? 0;

// ดึงข้อมูลที่พัก
$stmt = $pdo->prepare("SELECT * FROM accommodations WHERE id = ?");
$stmt->execute([$id]);
$acc = $stmt->fetch();

// ถ้าไม่พบข้อมูล
if (!$acc) {
    header('Location: accommodations.php');
    exit();
}
?>
<!DOCTYPE html>
<html lang="th">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?= htmlspecialchars($acc['name']) ?> - PhurinatUD</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Athiti:wght@300;400;700&display=swap" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css" rel="stylesheet">
    <link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css" />
    <link href="../assets/css/style.css" rel="stylesheet">
    <style>
        body { 
            font-family: 'Athiti', sans-serif; 
            background-color: #f8f9fa; 
        }
        .hero-image {
            width: 100%;
            height: 400px;
            object-fit: cover;
            border-radius: 20px;
        }
        .info-card {
            background: white;
            border-radius: 20px;
            padding: 30px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.08);
            margin-bottom: 20px;
        }
        .price-badge {
            background: linear-gradient(135deg, #ff6600 0%, #ff8533 100%);
            color: white;
            padding: 12px 24px;
            border-radius: 25px;
            font-size: 1.3rem;
            font-weight: 600;
            display: inline-block;
        }
        .amenity-item {
            background: #f8f9fa;
            padding: 10px 15px;
            border-radius: 10px;
            margin: 5px;
            display: inline-block;
        }
        .amenity-item i {
            color: #ff6600;
        }
        .rating {
            color: #ffc107;
            font-size: 1.5rem;
        }
        #map {
            height: 400px;
            border-radius: 15px;
            margin-top: 20px;
        }
        .contact-info {
            background: linear-gradient(135deg, #ff6600 0%, #ff8533 100%);
            color: white;
            padding: 20px;
            border-radius: 15px;
            margin-top: 20px;
        }
        .contact-info i {
            font-size: 1.5rem;
            margin-right: 10px;
        }
    </style>
</head>
<body>
<?php include('../includes/navbar.php'); ?>

<div class="container mt-4 mb-5">
    <!-- ปุ่มกลับ -->
    <div class="mb-4">
        <a href="accommodations.php" class="btn btn-outline-secondary">
            <i class="bi bi-arrow-left"></i> กลับไปหน้าที่พัก
        </a>
    </div>

    <div class="row">
        <!-- คอลัมน์ซ้าย: รูปภาพและข้อมูล -->
        <div class="col-lg-8">
            <!-- รูปภาพหลัก -->
            <?php if ($acc['image']): ?>
            <img src="<?= htmlspecialchars($acc['image']) ?>" 
                 alt="<?= htmlspecialchars($acc['name']) ?>" 
                 class="hero-image mb-4"
                 onerror="this.src='../assets/images/default-accommodation.jpg'">
            <?php else: ?>
            <img src="../assets/images/default-accommodation.jpg" 
                 alt="<?= htmlspecialchars($acc['name']) ?>" 
                 class="hero-image mb-4">
            <?php endif; ?>

            <!-- ข้อมูลหลัก -->
            <div class="info-card">
                <h1 class="mb-3"><?= htmlspecialchars($acc['name']) ?></h1>
                
                <!-- คะแนน -->
                <?php if ($acc['rating'] > 0): ?>
                <div class="rating mb-3">
                    <?php for ($i = 1; $i <= 5; $i++): ?>
                        <?php if ($i <= floor($acc['rating'])): ?>
                            <i class="bi bi-star-fill"></i>
                        <?php elseif ($i - 0.5 <= $acc['rating']): ?>
                            <i class="bi bi-star-half"></i>
                        <?php else: ?>
                            <i class="bi bi-star"></i>
                        <?php endif; ?>
                    <?php endfor; ?>
                    <span class="ms-2 text-muted">(<?= number_format($acc['rating'], 1) ?>)</span>
                </div>
                <?php endif; ?>

                <!-- ราคา -->
                <div class="mb-4">
                    <span class="price-badge">
                        <i class="bi bi-tag-fill"></i> <?= htmlspecialchars($acc['price_range']) ?>
                    </span>
                </div>

                <!-- คำอธิบาย -->
                <h4 class="mt-4 mb-3">รายละเอียด</h4>
                <p class="text-muted" style="font-size: 1.1rem; line-height: 1.8;">
                    <?= nl2br(htmlspecialchars($acc['description'])) ?>
                </p>

                <!-- สิ่งอำนวยความสะดวก -->
                <?php if ($acc['amenities']): ?>
                <h4 class="mt-4 mb-3">สิ่งอำนวยความสะดวก</h4>
                <div>
                    <?php 
                    $amenities = explode(',', $acc['amenities']);
                    foreach ($amenities as $amenity): 
                    ?>
                    <span class="amenity-item">
                        <i class="bi bi-check-circle-fill"></i> 
                        <?= trim(htmlspecialchars($amenity)) ?>
                    </span>
                    <?php endforeach; ?>
                </div>
                <?php endif; ?>
            </div>

            <!-- แผนที่ -->
            <?php if ($acc['latitude'] && $acc['longitude']): ?>
            <div class="info-card">
                <h4 class="mb-3">
                    <i class="bi bi-geo-alt-fill text-danger"></i> ตำแหน่งที่ตั้ง
                </h4>
                <div id="map"></div>
            </div>
            <?php endif; ?>
        </div>

        <!-- คอลัมน์ขวา: ข้อมูลติดต่อ -->
        <div class="col-lg-4">
            <div class="info-card sticky-top" style="top: 20px;">
                <h4 class="mb-4">ข้อมูลติดต่อ</h4>
                
                <!-- ที่อยู่ -->
                <?php if ($acc['address']): ?>
                <div class="mb-3">
                    <h6 class="text-muted mb-2">
                        <i class="bi bi-geo-alt-fill text-danger"></i> ที่อยู่
                    </h6>
                    <p><?= nl2br(htmlspecialchars($acc['address'])) ?></p>
                </div>
                <?php endif; ?>

                <!-- เบอร์โทร -->
                <?php if ($acc['phone']): ?>
                <div class="mb-3">
                    <h6 class="text-muted mb-2">
                        <i class="bi bi-telephone-fill text-success"></i> โทรศัพท์
                    </h6>
                    <p>
                        <a href="tel:<?= htmlspecialchars($acc['phone']) ?>" 
                           class="text-decoration-none">
                            <?= htmlspecialchars($acc['phone']) ?>
                        </a>
                    </p>
                </div>
                <?php endif; ?>

                <!-- ปุ่มติดต่อ -->
                <div class="contact-info text-center">
                    <i class="bi bi-chat-dots-fill"></i>
                    <h5 class="mb-3">ต้องการจองหรือสอบถาม?</h5>
                    <?php if ($acc['phone']): ?>
                    <a href="tel:<?= htmlspecialchars($acc['phone']) ?>" 
                       class="btn btn-light btn-lg w-100 mb-2">
                        <i class="bi bi-telephone-fill"></i> โทรติดต่อ
                    </a>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include('../includes/footer.php'); ?>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<?php if ($acc['latitude'] && $acc['longitude']): ?>
<script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script>
<script>
    // สร้างแผนที่
    var map = L.map('map').setView([<?= $acc['latitude'] ?>, <?= $acc['longitude'] ?>], 15);
    
    // เพิ่ม tile layer
    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        attribution: '© OpenStreetMap contributors'
    }).addTo(map);
    
    // เพิ่ม marker
    var marker = L.marker([<?= $acc['latitude'] ?>, <?= $acc['longitude'] ?>]).addTo(map);
    marker.bindPopup("<b><?= htmlspecialchars($acc['name']) ?></b><br><?= htmlspecialchars($acc['address']) ?>").openPopup();
</script>
<?php endif; ?>
</body>
</html>
