<?php
session_start();
require_once '../config/config.php';
require_once '../config/db.php';

// สร้างตารางที่พักถ้ายังไม่มี
$pdo->exec("CREATE TABLE IF NOT EXISTS accommodations (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(255) NOT NULL,
  description TEXT,
  address TEXT,
  phone VARCHAR(20),
  price_range VARCHAR(50),
  image VARCHAR(512),
  latitude DECIMAL(10,7),
  longitude DECIMAL(10,7),
  amenities TEXT,
  rating DECIMAL(3,2) DEFAULT 0.00,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

// ดึงข้อมูลที่พัก
$search = $_GET['search'] ?? '';
$query = "SELECT * FROM accommodations";
if ($search) {
    $query .= " WHERE name LIKE :search OR address LIKE :search";
}
$query .= " ORDER BY rating DESC, created_at DESC";

$stmt = $pdo->prepare($query);
if ($search) {
    $stmt->execute(['search' => "%$search%"]);
} else {
    $stmt->execute();
}
$accommodations = $stmt->fetchAll();
?>
<!DOCTYPE html>
<html lang="th">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>ที่พัก - PhurinatUD</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Athiti:wght@300;400;700&display=swap" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css" rel="stylesheet">
    <link href="../assets/css/style.css" rel="stylesheet">
    <style>
        body { 
            font-family: 'Athiti', sans-serif; 
            background-color: #f8f9fa; 
        }
        .hero-section {
            background: linear-gradient(135deg, #ff6600 0%, #ff8533 100%);
            color: white;
            padding: 80px 0 60px;
            margin-bottom: 40px;
        }
        .accommodation-card {
            border: none;
            border-radius: 15px;
            overflow: hidden;
            transition: all 0.3s;
            box-shadow: 0 5px 15px rgba(0,0,0,0.08);
        }
        .accommodation-card:hover {
            transform: translateY(-10px);
            box-shadow: 0 15px 30px rgba(0,0,0,0.15);
        }
        .accommodation-card img {
            height: 250px;
            object-fit: cover;
            transition: transform 0.5s;
        }
        .accommodation-card:hover img {
            transform: scale(1.1);
        }
        .rating {
            color: #ffc107;
            font-size: 1.1rem;
        }
        .price-badge {
            background: linear-gradient(135deg, #ff6600 0%, #ff8533 100%);
            color: white;
            padding: 8px 16px;
            border-radius: 20px;
            font-weight: 600;
        }
        .amenities {
            font-size: 0.9rem;
        }
        .amenities i {
            color: #ff6600;
            margin-right: 5px;
        }
    </style>
</head>
<body>
<?php include('../includes/navbar.php'); ?>

    <!-- Hero Section -->
    <div class="hero-section">
        <div class="container text-center">
            <h1 class="mb-3">ที่พักในจังหวัดอุดรธานี</h1>
            <p class="lead mb-4">ค้นหาที่พักที่เหมาะกับคุณ โรงแรม รีสอร์ท และอื่นๆ</p>
            
            <!-- Search -->
            <div class="row justify-content-center">
                <div class="col-md-6">
                    <form method="GET" class="input-group input-group-lg">
                        <input type="text" name="search" class="form-control" 
                               placeholder="ค้นหาที่พัก..." value="<?= htmlspecialchars($search) ?>">
                        <button class="btn btn-light" type="submit">
                            <i class="bi bi-search"></i> ค้นหา
                        </button>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <!-- Accommodations List -->
    <div class="container pb-5">
        <?php if (count($accommodations) > 0): ?>
            <div class="row g-4">
                <?php foreach ($accommodations as $acc): ?>
                <div class="col-md-6 col-lg-4">
                    <div class="card accommodation-card h-100">
                        <div style="overflow: hidden;">
                            <?php if ($acc['image']): ?>
                            <img src="<?= htmlspecialchars($acc['image']) ?>" class="card-img-top" alt="<?= htmlspecialchars($acc['name']) ?>">
                            <?php else: ?>
                            <div class="bg-secondary d-flex align-items-center justify-content-center text-white" style="height: 250px;">
                                <i class="bi bi-building" style="font-size: 5rem;"></i>
                            </div>
                            <?php endif; ?>
                        </div>
                        
                        <div class="card-body">
                            <div class="d-flex justify-content-between align-items-start mb-2">
                                <h5 class="card-title fw-bold mb-0"><?= htmlspecialchars($acc['name']) ?></h5>
                                <div class="rating">
                                    <i class="bi bi-star-fill"></i> <?= number_format($acc['rating'], 1) ?>
                                </div>
                            </div>
                            
                            <p class="card-text text-muted small mb-3">
                                <?= htmlspecialchars(mb_substr($acc['description'], 0, 100)) ?>...
                            </p>
                            
                            <div class="mb-2">
                                <i class="bi bi-geo-alt text-danger"></i>
                                <small class="text-muted"><?= htmlspecialchars(mb_substr($acc['address'], 0, 50)) ?>...</small>
                            </div>
                            
                            <?php if ($acc['phone']): ?>
                            <div class="mb-2">
                                <i class="bi bi-telephone text-success"></i>
                                <small><?= htmlspecialchars($acc['phone']) ?></small>
                            </div>
                            <?php endif; ?>
                            
                            <?php if ($acc['amenities']): ?>
                            <div class="amenities mb-3">
                                <?php 
                                $amenities = explode(',', $acc['amenities']);
                                foreach (array_slice($amenities, 0, 3) as $amenity): 
                                ?>
                                <span class="badge bg-light text-dark me-1 mb-1">
                                    <i class="bi bi-check-circle-fill"></i> <?= trim(htmlspecialchars($amenity)) ?>
                                </span>
                                <?php endforeach; ?>
                            </div>
                            <?php endif; ?>
                            
                            <div class="d-flex justify-content-between align-items-center">
                                <span class="price-badge"><?= htmlspecialchars($acc['price_range']) ?></span>
                                <a href="accommodation_detail.php?id=<?= $acc['id'] ?>" class="btn btn-sm btn-outline-primary">
                                    ดูรายละเอียด <i class="bi bi-arrow-right"></i>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
        <?php else: ?>
            <div class="text-center py-5">
                <i class="bi bi-search" style="font-size: 4rem; color: #ccc;"></i>
                <h3 class="mt-3 text-muted">ไม่พบที่พักที่คุณค้นหา</h3>
                <p class="text-muted">ลองค้นหาด้วยคำค้นหาอื่น</p>
            </div>
        <?php endif; ?>
    </div>

    <?php include('../includes/footer.php'); ?>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
