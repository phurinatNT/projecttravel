<?php
session_start();
require_once '../config/config.php';
require_once '../config/db.php';

// ตรวจสอบการเข้าสู่ระบบ
if (!isset($_SESSION['user_id'])) {
    $_SESSION['error'] = 'กรุณาเข้าสู่ระบบก่อนเพื่อดูสถานที่ให้บริการ';
    header('Location: ' . BASE_PATH . '/auth/login.php');
    exit();
}

// สร้างตารางถ้ายังไม่มี
$pdo->exec("CREATE TABLE IF NOT EXISTS services (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(255) NOT NULL,
  type ENUM('hospital', 'police', 'fire_station', 'gas_station', 'bank', 'post_office', 'other') NOT NULL,
  address TEXT,
  phone VARCHAR(20),
  latitude DECIMAL(10,7),
  longitude DECIMAL(10,7),
  operating_hours VARCHAR(100),
  description TEXT,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

// ดึงข้อมูลสถานที่บริการ
$search = $_GET['search'] ?? '';
$type = $_GET['type'] ?? '';

$query = "SELECT * FROM services WHERE 1=1";
$params = [];

if ($search) {
    $query .= " AND (name LIKE :search OR address LIKE :search)";
    $params['search'] = "%$search%";
}

if ($type) {
    $query .= " AND type = :type";
    $params['type'] = $type;
}

$query .= " ORDER BY type, name";

$stmt = $pdo->prepare($query);
$stmt->execute($params);
$services = $stmt->fetchAll();

// แปลงประเภทเป็นภาษาไทย
function getTypeLabel($type) {
    $labels = [
        'hospital' => 'โรงพยาบาล',
        'police' => 'สถานีตำรวจ',
        'fire_station' => 'สถานีดับเพลิง',
        'gas_station' => 'ปั๊มน้ำมัน',
        'bank' => 'ธนาคาร',
        'post_office' => 'ไปรษณีย์',
        'other' => 'อื่นๆ'
    ];
    return $labels[$type] ?? $type;
}

function getTypeIcon($type) {
    $icons = [
        'hospital' => 'bi-hospital',
        'police' => 'bi-shield-fill-check',
        'fire_station' => 'bi-fire',
        'gas_station' => 'bi-fuel-pump',
        'bank' => 'bi-bank',
        'post_office' => 'bi-mailbox',
        'other' => 'bi-info-circle'
    ];
    return $icons[$type] ?? 'bi-info-circle';
}

function getTypeColor($type) {
    $colors = [
        'hospital' => '#dc3545',
        'police' => '#0d6efd',
        'fire_station' => '#fd7e14',
        'gas_station' => '#198754',
        'bank' => '#6f42c1',
        'post_office' => '#ffc107',
        'other' => '#6c757d'
    ];
    return $colors[$type] ?? '#6c757d';
}
?>
<!DOCTYPE html>
<html lang="th">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>สถานที่บริการ - PhurinatUD</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Athiti:wght@300;400;700&display=swap" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css" rel="stylesheet">
    <link href="../assets/css/style.css" rel="stylesheet">
    <style>
        body { 
            font-family: 'Athiti', sans-serif; 
            background-color: #f8f9fa; 
        }
        .hero-section {
            background: linear-gradient(135deg, #ff6600 0%, #ff8533 100%);
            color: white;
            padding: 60px 0;
            margin-bottom: 40px;
        }
        .search-box {
            max-width: 800px;
            margin: 0 auto;
        }
        .service-card {
            border: none;
            border-radius: 15px;
            overflow: hidden;
            transition: all 0.3s ease-in-out;
            box-shadow: 0 5px 15px rgba(0,0,0,0.08);
            margin-bottom: 20px;
        }
        .service-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 15px 30px rgba(0,0,0,0.15);
        }
        .service-icon {
            font-size: 3rem;
            margin-bottom: 15px;
        }
        .type-badge {
            display: inline-block;
            padding: 5px 15px;
            border-radius: 20px;
            color: white;
            font-size: 0.9rem;
            font-weight: 600;
        }
        .filter-btn {
            margin: 5px;
            border-radius: 20px;
        }
    </style>
</head>
<body>
<?php include('../includes/navbar.php'); ?>

<!-- Hero Section with Search -->
<div class="hero-section">
    <div class="container text-center">
        <h1 class="mb-4"><i class="bi bi-geo-alt-fill"></i> สถานที่บริการในอุดรธานี</h1>
        <p class="lead mb-4">ค้นหาสถานที่บริการที่คุณต้องการในจังหวัดอุดรธานี</p>
        <div class="search-box">
            <form method="GET" action="">
                <div class="row g-2 justify-content-center">
                    <div class="col-md-6">
                        <input type="text" class="form-control form-control-lg" name="search" 
                               placeholder="ค้นหาสถานที่บริการ..." value="<?= htmlspecialchars($search) ?>">
                    </div>
                    <div class="col-md-4">
                        <select name="type" class="form-select form-select-lg">
                            <option value="">ทุกประเภท</option>
                            <option value="hospital" <?= $type === 'hospital' ? 'selected' : '' ?>>โรงพยาบาล</option>
                            <option value="police" <?= $type === 'police' ? 'selected' : '' ?>>สถานีตำรวจ</option>
                            <option value="fire_station" <?= $type === 'fire_station' ? 'selected' : '' ?>>สถานีดับเพลิง</option>
                            <option value="gas_station" <?= $type === 'gas_station' ? 'selected' : '' ?>>ปั๊มน้ำมัน</option>
                            <option value="bank" <?= $type === 'bank' ? 'selected' : '' ?>>ธนาคาร</option>
                            <option value="post_office" <?= $type === 'post_office' ? 'selected' : '' ?>>ไปรษณีย์</option>
                        </select>
                    </div>
                    <div class="col-md-2">
                        <button class="btn btn-light btn-lg w-100" type="submit">
                            <i class="bi bi-search"></i> ค้นหา
                        </button>
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>

<div class="container pb-5">
    <!-- Quick Filter Buttons -->
    <div class="text-center mb-4">
        <h5 class="mb-3">กรองตามประเภท:</h5>
        <a href="?" class="btn btn-outline-secondary filter-btn <?= !$type ? 'active' : '' ?>">
            <i class="bi bi-grid"></i> ทั้งหมด
        </a>
        <a href="?type=hospital" class="btn btn-outline-danger filter-btn <?= $type === 'hospital' ? 'active' : '' ?>">
            <i class="bi bi-hospital"></i> โรงพยาบาล
        </a>
        <a href="?type=police" class="btn btn-outline-primary filter-btn <?= $type === 'police' ? 'active' : '' ?>">
            <i class="bi bi-shield-fill-check"></i> ตำรวจ
        </a>
        <a href="?type=fire_station" class="btn btn-outline-warning filter-btn <?= $type === 'fire_station' ? 'active' : '' ?>">
            <i class="bi bi-fire"></i> ดับเพลิง
        </a>
        <a href="?type=gas_station" class="btn btn-outline-success filter-btn <?= $type === 'gas_station' ? 'active' : '' ?>">
            <i class="bi bi-fuel-pump"></i> ปั๊มน้ำมัน
        </a>
        <a href="?type=bank" class="btn btn-outline-info filter-btn <?= $type === 'bank' ? 'active' : '' ?>">
            <i class="bi bi-bank"></i> ธนาคาร
        </a>
        <a href="?type=post_office" class="btn btn-outline-secondary filter-btn <?= $type === 'post_office' ? 'active' : '' ?>">
            <i class="bi bi-mailbox"></i> ไปรษณีย์
        </a>
    </div>

    <?php if (count($services) > 0): ?>
        <div class="row">
            <?php foreach ($services as $service): ?>
                <div class="col-md-6 col-lg-4">
                    <div class="card service-card h-100">
                        <div class="card-body text-center">
                            <i class="bi <?= getTypeIcon($service['type']) ?> service-icon" 
                               style="color: <?= getTypeColor($service['type']) ?>"></i>
                            
                            <h5 class="card-title fw-bold"><?= htmlspecialchars($service['name']) ?></h5>
                            
                            <span class="type-badge mb-3" style="background-color: <?= getTypeColor($service['type']) ?>">
                                <?= getTypeLabel($service['type']) ?>
                            </span>
                            
                            <?php if ($service['description']): ?>
                                <p class="card-text text-muted mt-3">
                                    <?= htmlspecialchars($service['description']) ?>
                                </p>
                            <?php endif; ?>
                            
                            <hr>
                            
                            <?php if ($service['address']): ?>
                                <div class="text-start mb-2">
                                    <i class="bi bi-geo-alt text-danger"></i>
                                    <small><?= htmlspecialchars($service['address']) ?></small>
                                </div>
                            <?php endif; ?>
                            
                            <?php if ($service['phone']): ?>
                                <div class="text-start mb-2">
                                    <i class="bi bi-telephone text-success"></i>
                                    <small><a href="tel:<?= htmlspecialchars($service['phone']) ?>" class="text-decoration-none">
                                        <?= htmlspecialchars($service['phone']) ?>
                                    </a></small>
                                </div>
                            <?php endif; ?>
                            
                            <?php if ($service['operating_hours']): ?>
                                <div class="text-start mb-2">
                                    <i class="bi bi-clock text-primary"></i>
                                    <small><?= htmlspecialchars($service['operating_hours']) ?></small>
                                </div>
                            <?php endif; ?>
                            
                            <?php if ($service['latitude'] && $service['longitude']): ?>
                                <div class="mt-3">
                                    <a href="https://www.google.com/maps?q=<?= $service['latitude'] ?>,<?= $service['longitude'] ?>" 
                                       target="_blank" class="btn btn-sm btn-outline-primary w-100">
                                        <i class="bi bi-map"></i> ดูแผนที่
                                    </a>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    <?php else: ?>
        <div class="text-center py-5">
            <i class="bi bi-search" style="font-size: 4rem; color: #ccc;"></i>
            <h3 class="mt-3 text-muted">ไม่พบสถานที่บริการที่คุณค้นหา</h3>
            <p class="text-muted">ลองค้นหาด้วยคำค้นหาอื่น หรือเลือกประเภทอื่น</p>
            <a href="services.php" class="btn btn-primary mt-2">
                <i class="bi bi-arrow-left"></i> ดูทั้งหมด
            </a>
        </div>
    <?php endif; ?>
</div>

<?php include('../includes/footer.php'); ?>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
