<?php
session_start();
require_once '../config/config.php';
require_once '../config/db.php';

// ตรวจสอบการเข้าสู่ระบบ
if (!isset($_SESSION['user_id'])) {
    $_SESSION['error'] = 'กรุณาเข้าสู่ระบบก่อนเพื่อดูสินค้า';
    header('Location: ' . BASE_PATH . '/auth/login.php');
    exit();
}

// รับคำค้นหา
$search = $_GET['search'] ?? '';

// Query ข้อมูล
if (!empty($search)) {
    $stmt = $pdo->prepare("SELECT * FROM products WHERE name LIKE ? OR description LIKE ? ORDER BY id DESC");
    $searchParam = "%{$search}%";
    $stmt->execute([$searchParam, $searchParam]);
} else {
    $stmt = $pdo->query("SELECT * FROM products ORDER BY id DESC");
}
?>
<!DOCTYPE html>
<html lang="th">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>สินค้าชุมชน | PhurinatUD</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css2?family=Athiti:wght@300;400;700&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">
  <link href="../assets/css/style.css" rel="stylesheet">
  <style>
    body { font-family: 'Athiti', sans-serif; background: #f8f9fa; }
    .hero-section {
      background: linear-gradient(135deg, #ff6600 0%, #ff8533 100%);
      color: white;
      padding: 60px 0;
      margin-bottom: 40px;
      
    }
    .search-box {
      max-width: 600px;
      margin: 0 auto;
    }
    .card {
      border: none;
      border-radius: 20px;
      box-shadow: 0 5px 15px rgba(0,0,0,0.08);
      overflow: hidden;
      transition: all 0.3s ease-in-out;
    }
    .card:hover {
      transform: translateY(-5px);
      box-shadow: 0 10px 20px rgba(0,0,0,0.15);
    }
    .card img {
      height: 220px;
      object-fit: cover;
    }
    .price {
      color: #ff6600;
      font-weight: bold;
      font-size: 18px;
    }
  </style>
</head>
<body>
<?php include('../includes/navbar.php'); ?>

<!-- Hero Section with Search -->
<div class="hero-section">
  <div class="container text-center">
    <h1 class="mb-4">🛍️ สินค้าชุมชน</h1>
    <p class="lead mb-4">สำรวจสินค้าชุมชนที่น่าสนใจในจังหวัดอุดรธานี</p>
    <div class="search-box">
      <form method="GET" action="">
        <div class="input-group input-group-lg">
          <input type="text" class="form-control" name="search" placeholder="ค้นหาสินค้า..." value="<?= htmlspecialchars($search) ?>">
          <button class="btn btn-light" type="submit">
            <i class="bi bi-search"></i> ค้นหา
          </button>
        </div>
      </form>
    </div>
  </div>
</div>

<div class="container pb-5">
  <div class="row g-4">
    <?php
    $hasData = false;
    while ($row = $stmt->fetch(PDO::FETCH_ASSOC)):
      $hasData = true;
    ?>
      <div class="col-md-4 col-sm-6">
        <div class="card">
          <img src="<?= htmlspecialchars($row['image']) ?>" alt="<?= htmlspecialchars($row['name']) ?>">
          <div class="card-body text-center">
            <h5 class="card-title"><?= htmlspecialchars($row['name']) ?></h5>
            <p class="text-muted"><?= htmlspecialchars($row['description']) ?></p>
            <p class="price"><?= number_format($row['price'], 2) ?> บาท</p>
            <?php if (!empty($row['product_url'])): ?>
              <a href="<?= htmlspecialchars($row['product_url']) ?>" target="_blank" class="btn btn-primary w-100 mt-2">
                <i class="bi bi-cart-plus"></i> ซื้อสินค้า
              </a>
            <?php endif; ?>
          </div>
        </div>
      </div>
    <?php endwhile; ?>

    <?php if (!$hasData): ?>
      <div class="text-center text-muted">ยังไม่มีข้อมูลสินค้า</div>
    <?php endif; ?>
  </div>
</div>

  <?php include('../includes/footer.php'); ?>


<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
