<?php
session_start();
require_once '../config/config.php';
require_once '../config/db.php';

$search = trim($_GET['search'] ?? '');
$categoryFilter = $_GET['category'] ?? '';

$productCategoryLabels = [
    'food' => 'ของกิน',
    'souvenir' => 'สินค้าที่ระลึก',
    'other' => 'อื่นๆ'
];

$primaryFilterButtons = [
    '' => 'ทั้งหมด',
    'food' => 'ของกิน',
    'souvenir' => 'สินค้าที่ระลึก'
];

if ($categoryFilter !== '' && !array_key_exists($categoryFilter, $productCategoryLabels)) {
    $categoryFilter = '';
}

$sql = "SELECT * FROM products WHERE 1=1";
$params = [];

if ($categoryFilter !== '') {
    $sql .= " AND category = ?";
    $params[] = $categoryFilter;
}

if ($search !== '') {
    $sql .= " AND (name LIKE ? OR description LIKE ?)";
    $searchParam = "%{$search}%";
    $params[] = $searchParam;
    $params[] = $searchParam;
}

$sql .= " ORDER BY id DESC";
$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$products = $stmt->fetchAll(PDO::FETCH_ASSOC);

$groupedProducts = [];
foreach ($products as $row) {
    $key = $row['category'] ?? 'other';
    if (!array_key_exists($key, $productCategoryLabels)) {
        $key = 'other';
    }
    $groupedProducts[$key][] = $row;
}
$hasData = !empty($groupedProducts);

$categoryOrder = ['food', 'souvenir', 'other'];
if ($categoryFilter !== '' && !in_array($categoryFilter, $categoryOrder, true)) {
    $categoryOrder[] = $categoryFilter;
}

if ($categoryFilter !== '') {
    $renderOrder = [$categoryFilter];
} else {
    $renderOrder = $categoryOrder;
    foreach (array_keys($groupedProducts) as $key) {
        if (!in_array($key, $renderOrder, true)) {
            $renderOrder[] = $key;
        }
    }
}

$buildProductUrl = function (array $overrides = []) use ($search, $categoryFilter) {
    $params = [];
    if ($search !== '') {
        $params['search'] = $search;
    }

    $categoryValue = $categoryFilter;
    if (array_key_exists('category', $overrides)) {
        $categoryValue = $overrides['category'];
    }

    if ($categoryValue !== '') {
        $params['category'] = $categoryValue;
    }

    $query = http_build_query($params);
    return 'products.php' . ($query ? '?' . $query : '');
};

$fallbackImages = [];
$uploadDir = realpath(__DIR__ . '/../assets/uploads/products');
if ($uploadDir && is_dir($uploadDir)) {
    $files = glob($uploadDir . '/*.{jpg,jpeg,png,gif,webp}', GLOB_BRACE);
    if ($files) {
        foreach ($files as $file) {
            $fallbackImages[] = basename($file);
        }
    }
}
$fallbackIndex = 0;
?>
<!DOCTYPE html>
<html lang="th">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>สินค้าชุมชน | PhurinatUD</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css2?family=Athiti:wght@300;400;700&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">
  <link href="../assets/css/style.css" rel="stylesheet">
  <style>
    body { font-family: 'Athiti', sans-serif; background: #f8f9fa; }
    .hero-section {
      background: linear-gradient(135deg, #ff6600 0%, #ff8533 100%);
      color: white;
      padding: 60px 0;
      margin-bottom: 40px;
      
    }
    .search-box {
      max-width: 600px;
      margin: 0 auto;
    }
    .category-pills {
      margin-top: 25px;
      gap: 12px;
      flex-wrap: wrap;
    }
    .category-pills .btn {
      border-radius: 999px;
      padding: 0.35rem 1.2rem;
      font-weight: 600;
    }
    .card {
      border: none;
      border-radius: 20px;
      box-shadow: 0 5px 15px rgba(0,0,0,0.08);
      overflow: hidden;
      transition: all 0.3s ease-in-out;
    }
    .card:hover {
      transform: translateY(-5px);
      box-shadow: 0 10px 20px rgba(0,0,0,0.15);
    }
    .card img {
      height: 220px;
      object-fit: cover;
    }
    .price {
      color: #ff6600;
      font-weight: bold;
      font-size: 18px;
    }
    .category-section {
      padding-bottom: 20px;
      border-bottom: 1px solid #f1f1f1;
      margin-bottom: 40px;
    }
    .category-section:last-of-type {
      border-bottom: none;
      margin-bottom: 0;
      padding-bottom: 0;
    }
    .contact-section {
      background: white;
      border-radius: 20px;
      padding: 35px;
      box-shadow: 0 10px 25px rgba(0,0,0,0.08);
    }
    .contact-detail {
      display: flex;
      align-items: center;
      gap: 15px;
      margin-bottom: 15px;
    }
    .contact-detail i {
      font-size: 1.4rem;
      color: #ff6600;
    }
  </style>
</head>
<body>
<?php include('../includes/navbar.php'); ?>

<!-- Hero Section with Search -->
<div class="hero-section">
  <div class="container text-center">
    <h1 class="mb-4">สินค้าชุมชน</h1>
    <p class="lead mb-4">สำรวจสินค้าชุมชนที่น่าสนใจในจังหวัดอุดรธานี</p>
    <div class="search-box">
      <form method="GET" action="">
        <div class="row g-3 justify-content-center">
          <div class="col-md-5">
            <input type="text" class="form-control form-control-lg" name="search" placeholder="ค้นหาสินค้า..." value="<?= htmlspecialchars($search) ?>">
          </div>
          <div class="col-md-4">
            <select name="category" class="form-select form-select-lg">
              <option value="">ทุกหมวดหมู่</option>
              <?php foreach ($productCategoryLabels as $key => $label): ?>
                <?php if ($key === 'other') continue; ?>
                <option value="<?= htmlspecialchars($key) ?>" <?= $categoryFilter === $key ? 'selected' : '' ?>>
                  <?= htmlspecialchars($label) ?>
                </option>
              <?php endforeach; ?>
              <option value="other" <?= $categoryFilter === 'other' ? 'selected' : '' ?>>อื่นๆ</option>
            </select>
          </div>
          <div class="col-md-3">
            <button class="btn btn-light btn-lg w-100" type="submit">
              <i class="bi bi-search"></i> ค้นหา
            </button>
          </div>
        </div>
      </form>
    </div>
  </div>
<div class="container">
  <div class="d-flex justify-content-center category-pills mb-4">
    <?php foreach ($primaryFilterButtons as $value => $label): ?>
      <?php $isActive = ($value === '' && $categoryFilter === '') || ($value !== '' && $categoryFilter === $value); ?>
      <a href="<?= htmlspecialchars($buildProductUrl(['category' => $value])) ?>" 
         class="btn <?= $isActive ? 'btn-dark text-white' : 'btn-outline-light text-white' ?>"
         style="border-color: rgba(255,255,255,0.4);">
        <?= htmlspecialchars($label) ?>
      </a>
    <?php endforeach; ?>
  </div>
</div>

<div class="container pb-5">
  <?php if ($hasData): ?>
    <?php foreach ($renderOrder as $categoryKey): ?>
      <?php if (empty($groupedProducts[$categoryKey])) continue; ?>
      <div class="category-section">
        <div class="d-flex flex-column flex-md-row justify-content-between align-items-md-center mb-3">
          <div>
            <h3 class="fw-bold mb-1">หมวด<?= htmlspecialchars($productCategoryLabels[$categoryKey] ?? $categoryKey) ?></h3>
            <p class="text-muted mb-0">ทั้งหมด <?= count($groupedProducts[$categoryKey]) ?> รายการ</p>
          </div>
          <?php if ($categoryFilter === ''): ?>
            <a href="<?= htmlspecialchars($buildProductUrl(['category' => $categoryKey])) ?>" class="btn btn-outline-primary btn-sm">ดูเฉพาะหมวดนี้</a>
          <?php else: ?>
            <a href="<?= htmlspecialchars($buildProductUrl(['category' => ''])) ?>" class="btn btn-outline-secondary btn-sm">ดูทุกหมวดหมู่</a>
          <?php endif; ?>
        </div>
        <div class="row g-4">
          <?php foreach ($groupedProducts[$categoryKey] as $row): ?>
            <div class="col-md-4 col-sm-6">
              <div class="card">
                <?php
                if (!empty($row['image'])) {
                    $image_src = '../' . ltrim($row['image'], '/');
                } elseif (!empty($fallbackImages)) {
                    $image_src = '../assets/uploads/products/' . $fallbackImages[$fallbackIndex % count($fallbackImages)];
                    $fallbackIndex++;
                } else {
                    $image_src = '../assets/images/default-product.jpg';
                }
                ?>
                <img src="<?= htmlspecialchars($image_src) ?>" alt="<?= htmlspecialchars($row['name']) ?>" onerror="this.src='../assets/images/default-product.jpg'">
                <div class="card-body">
                  <h5 class="card-title"><?= htmlspecialchars($row['name']) ?></h5>
                  <p class="text-muted"><?= htmlspecialchars(mb_substr($row['description'], 0, 80)) ?>...</p>
                  <p class="price"><?= number_format($row['price'], 2) ?> บาท</p>
                  <div class="d-grid gap-2">
                    <a href="product_detail.php?id=<?= $row['id'] ?>" class="btn btn-outline-primary">
                      <i class="bi bi-info-circle"></i> ดูรายละเอียด
                    </a>
                    <?php if (!empty($row['product_url'])): ?>
                      <a href="<?= htmlspecialchars($row['product_url']) ?>" target="_blank" class="btn btn-primary">
                        <i class="bi bi-cart-plus"></i> ซื้อสินค้า
                      </a>
                    <?php endif; ?>
                  </div>
                </div>
              </div>
            </div>
          <?php endforeach; ?>
        </div>
      </div>
    <?php endforeach; ?>
  <?php else: ?>
    <div class="text-center text-muted py-5">ยังไม่มีข้อมูลสินค้า</div>
  <?php endif; ?>

  <div class="contact-section mt-5">
    <div class="row g-4">
      <div class="col-md-6">
        <h3 class="fw-bold mb-2">ติดต่อทีมงาน PhurinatUD</h3>
        <p class="text-muted mb-0">สอบถามเกี่ยวกับสินค้าชุมชน หรือต้องการนำสินค้ามาลงทะเบียน สามารถติดต่อเราได้ทุกช่องทาง</p>
      </div>
      <div class="col-md-6">
        <div class="contact-detail">
          <i class="bi bi-telephone-fill"></i>
          <div>
            <small class="text-muted">โทร</small>
            <a href="tel:0800000000" class="text-decoration-none fw-semibold">080-000-0000</a>
          </div>
        </div>
        <div class="contact-detail">
          <i class="bi bi-envelope-fill"></i>
          <div>
            <small class="text-muted">อีเมล</small>
            <a href="mailto:phurinat.ud@gmail.com" class="text-decoration-none fw-semibold">phurinat.ud@gmail.com</a>
          </div>
        </div>
        <div class="contact-detail">
          <i class="bi bi-chat-dots-fill"></i>
          <div>
            <small class="text-muted">LINE Official</small>
            <a href="https://line.me/R/ti/p/@phurinatud" target="_blank" class="text-decoration-none fw-semibold">@phurinatud</a>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>

<?php include('../includes/footer.php'); ?>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
