# คู่มือการอัพโหลดขึ้น Hosting

## ขั้นตอนการอัพโหลด

### 1. อัพโหลดไฟล์ทั้งหมดไปที่ hosting
อัพโหลดโฟลเดอร์ทั้งหมดไปที่ `/~cs67040249104/project/`

### 2. แก้ไขไฟล์ config/config.php
ระบบจะ auto-detect ว่าอยู่ localhost หรือ hosting

**สำหรับ localhost:**
- ใช้ path: `/PhurinatUD_full`

**สำหรับ hosting:**
- ใช้ path: `/~cs67040249104/project`

ไฟล์ config/config.php จะตรวจสอบอัตโนมัติแล้ว ไม่ต้องแก้อะไรเพิ่ม

### 3. แก้ไขไฟล์ config/db.php
แก้ไขข้อมูลการเชื่อมต่อฐานข้อมูลให้ตรงกับ hosting:

```php
$dbHost = 'localhost'; // หรือ host ที่ hosting กำหนดให้
$dbName = 'ชื่อฐานข้อมูล'; // เปลี่ยนตามจริง
$dbUser = 'username'; // เปลี่ยนตามจริง
$dbPass = 'password'; // เปลี่ยนตามจริง
```

### 4. Import Database
1. สร้างฐานข้อมูลบน hosting (phpMyAdmin)
2. Import ไฟล์ `udonjourney.sql`
3. Import ไฟล์ `accommodations.sql` (ถ้ามี)

### 5. แก้ไข path รูปภาพ (ถ้าจำเป็น)
เมื่อเพิ่มข้อมูลในหน้าแอดมิน ให้ใช้ path รูปภาพแบบนี้:

**สำหรับ localhost:**
- `/PhurinatUD_full/assets/images/example.jpg`

**สำหรับ hosting:**
- `/~cs67040249104/project/assets/images/example.jpg`

หรือใช้ URL เต็ม:
- `https://hosting.udru.ac.th/~cs67040249104/project/assets/images/example.jpg`

### 6. เข้าถึงเว็บไซต์

**Localhost:**
- http://localhost/PhurinatUD_full/pages/index.php
- http://localhost/PhurinatUD_full/admin/index.php

**Hosting:**
- https://hosting.udru.ac.th/~cs67040249104/project/pages/index.php
- https://hosting.udru.ac.th/~cs67040249104/project/admin/index.php

## ไฟล์ที่ได้รับการแก้ไขแล้ว

✅ config/config.php - ระบบ auto-detect path
✅ includes/navbar.php - ใช้ BASE_PATH
✅ pages/index.php - ใช้ BASE_PATH
✅ pages/attractions.php - ใช้ BASE_PATH
✅ pages/accommodations.php - ใช้ BASE_PATH
✅ pages/products.php - ใช้ BASE_PATH
✅ pages/place.php - ใช้ BASE_PATH

## หมายเหตุ

1. ไฟล์ admin/*.php ใช้ relative path อยู่แล้ว ไม่ต้องแก้
2. ไฟล์ auth/*.php ใช้ relative path อยู่แล้ว ไม่ต้องแก้
3. Assets (CSS, images) ใช้ relative path (`../assets/...`) ทำงานได้ทั้ง localhost และ hosting

## การทดสอบ

1. ทดสอบการเข้าสู่ระบบ
2. ทดสอบการแสดงรูปภาพ
3. ทดสอบการเปิดหน้าต่างๆ จาก navbar
4. ทดสอบหน้า admin ต่างๆ

## การแก้ปัญหา

**ถ้ารูปภาพไม่แสดง:**
- ตรวจสอบ path ในฐานข้อมูล
- อาจต้องใช้ URL แบบเต็ม หรือ BASE_PATH

**ถ้า redirect ไม่ทำงาน:**
- ตรวจสอบ config/config.php
- อาจต้องปรับ BASE_PATH ให้ตรงกับ hosting

**ถ้า database connect error:**
- ตรวจสอบ config/db.php
- ตรวจสอบว่า import database ครบแล้ว
