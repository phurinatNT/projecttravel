<?php
// กำหนด Base URL สำหรับ Hosting
// สำหรับ localhost ใช้ /PhurinatUD_full
// สำหรับ hosting ใช้ /~cs67040249104/project

// ตรวจสอบว่าอยู่บน localhost หรือ hosting
if ($_SERVER['HTTP_HOST'] === 'localhost' || $_SERVER['HTTP_HOST'] === '127.0.0.1') {
    define('BASE_PATH', '/PhurinatUD_full');
} else {
    // สำหรับ hosting
    define('BASE_PATH', '/~cs67040249104/project');
}

define('BASE_URL', BASE_PATH);
?>
