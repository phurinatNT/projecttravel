<?php
// config/db.php
$host = 'localhost';
$dbname = 'udonjourney';
$username = 'root';
$password = 'root'; // หรือ '' ถ้าไม่ได้ตั้งรหัส

// --- สร้างการเชื่อมต่อแบบ PDO ---
try {
  $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8mb4", $username, $password, [
    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION
  ]);
} catch (PDOException $e) {
  die("PDO Connection failed: " . $e->getMessage());
}

// --- สร้างการเชื่อมต่อแบบ MySQLi (สำหรับไฟล์ที่ใช้ $mysqli) ---
$mysqli = new mysqli($host, $username, $password, $dbname);
if ($mysqli->connect_errno) {
  die("MySQLi Connection failed: " . $mysqli->connect_error);
}
?>
