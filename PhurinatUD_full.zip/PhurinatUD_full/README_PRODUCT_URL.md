# การเพิ่มลิงก์ขายสินค้า - Product URL Feature

## 🛍️ ฟีเจอร์ที่เพิ่มเข้ามา

เพิ่มความสามารถในการใส่ลิงก์ขายสินค้าภายนอก เช่น:
- Shopee
- Lazada
- Facebook Shop
- LINE Official
- เว็บไซต์ของตัวเอง

## 📊 การติดตั้ง

### 1. อัพเดทฐานข้อมูล

เปิด phpMyAdmin หรือใช้ command line:

```bash
mysql -u root -p udonjourney < add_product_url.sql
```

หรือ copy SQL ด้านล่างไปรันใน phpMyAdmin:

```sql
USE udonjourney;

-- เพิ่มคอลัมน์ product_url
ALTER TABLE products ADD COLUMN product_url VARCHAR(512) AFTER image;
```

### 2. ทดสอบการทำงาน

- เข้าหน้า Admin: `http://localhost/PhurinatUD_full/admin/products.php`
- กดปุ่ม "เพิ่มสินค้าใหม่"
- ใส่ข้อมูลสินค้าและลิงก์ขายสินค้า
- บันทึกข้อมูล

## 🎨 การใช้งาน

### สำหรับ Admin

1. **เพิ่มสินค้าใหม่**
   - กรอกข้อมูลสินค้าตามปกติ
   - ในช่อง "ลิงก์ขายสินค้า (URL)" ใส่ลิงก์ เช่น:
     - `https://shopee.co.th/product/123456789`
     - `https://www.lazada.co.th/products/i987654321.html`
     - `https://www.facebook.com/yourshop/posts/123`

2. **แก้ไขสินค้า**
   - คลิกปุ่มแก้ไขสินค้าที่ต้องการ
   - เพิ่มหรือแก้ไขลิงก์ขายสินค้า
   - บันทึกข้อมูล

### สำหรับผู้ใช้งานทั่วไป

เมื่อเข้าหน้า **สินค้าชุมชน** (`/pages/products.php`):
- สินค้าที่มีลิงก์จะมีปุ่ม **"🛒 ซื้อสินค้า"**
- คลิกปุ่มจะเปิดลิงก์ในแท็บใหม่
- สินค้าที่ไม่มีลิงก์จะไม่แสดงปุ่ม

## 📝 ตัวอย่างข้อมูล

### ตัวอย่างลิงก์ที่ใช้ได้:

```
Shopee:
https://shopee.co.th/product/123456789/987654321

Lazada:
https://www.lazada.co.th/products/i987654321.html

Facebook:
https://www.facebook.com/yourshop/posts/123456

LINE OA:
https://lin.ee/xxxxx

เว็บไซต์เอง:
https://yourshop.com/product/handmade-bag
```

## 🎯 ฟีเจอร์ที่ได้

### หน้า Admin (admin/products.php)
- ✅ เพิ่มฟิลด์ "ลิงก์ขายสินค้า (URL)"
- ✅ รองรับการเพิ่ม/แก้ไข/ลบ
- ✅ Validation ว่าเป็น URL ที่ถูกต้อง

### หน้าผู้ใช้ (pages/products.php)
- ✅ แสดงปุ่ม "ซื้อสินค้า" เมื่อมีลิงก์
- ✅ เปิดลิงก์ในแท็บใหม่ (target="_blank")
- ✅ ไอคอนรถเข็นสวยงาม (🛒)
- ✅ ปุ่มเต็มความกว้าง (w-100)

## 🔧 ไฟล์ที่แก้ไข

1. **add_product_url.sql** - SQL script สำหรับเพิ่มคอลัมน์
2. **admin/products.php** - เพิ่มฟิลด์ในฟอร์มและ query
3. **pages/products.php** - แสดงปุ่มซื้อสินค้า

## 💡 เคล็ดลับ

### ตัวย่อ URL
ถ้าลิงก์ยาวเกินไป สามารถใช้บริการตัวย่อ URL:
- Bitly: https://bitly.com
- TinyURL: https://tinyurl.com

### Google Analytics
เพิ่ม UTM parameters เพื่อติดตามยอดขาย:
```
https://shopee.co.th/product/123?utm_source=phurinatud&utm_medium=website
```

### QR Code
สร้าง QR Code จากลิงก์เพื่อให้ลูกค้าสแกนง่าย:
- https://www.qr-code-generator.com/

## 🚀 การใช้งานบน Hosting

เมื่ออัพโหลดไปยัง hosting:
1. Import ไฟล์ `add_product_url.sql` ผ่าน phpMyAdmin
2. อัพโหลดไฟล์ที่แก้ไขทั้งหมด
3. ทดสอบการทำงาน

## 📞 ตัวอย่างการใช้งานจริง

### สินค้า: ผ้าไหมมัดหมี่อุดร
- ชื่อ: ผ้าไหมมัดหมี่อุดร
- ราคา: 1,500 บาท
- ลิงก์: `https://shopee.co.th/product/thai-silk`
- ผลลัพธ์: แสดงปุ่ม "🛒 ซื้อสินค้า" ที่คลิกแล้วไปหน้า Shopee

### สินค้า: น้ำพริกหนุ่ม
- ชื่อ: น้ำพริกหนุ่มแสนอร่อย
- ราคา: 120 บาท
- ลิงก์: `https://lin.ee/abc123`
- ผลลัพธ์: แสดงปุ่ม "🛒 ซื้อสินค้า" ที่คลิกแล้วไปหน้า LINE OA

## ⚠️ ข้อควรระวัง

1. **ตรวจสอบลิงก์ให้ถูกต้อง** - ลิงก์ที่ผิดจะทำให้ลูกค้าไม่สามารถซื้อสินค้าได้
2. **อัพเดทลิงก์เป็นประจำ** - สินค้าบางรายการอาจหมดหรือลิงก์เปลี่ยน
3. **ไม่บังคับใส่** - สินค้าที่ไม่มีลิงก์ยังแสดงได้ปกติ แค่ไม่มีปุ่มซื้อ

## 🎉 สรุป

ตอนนี้คุณสามารถ:
- ✅ เพิ่มลิงก์ขายสินค้าภายนอกได้
- ✅ แสดงปุ่มซื้อสินค้าในหน้าแสดงผล
- ✅ เชื่อมต่อไปยังร้านค้าออนไลน์ต่างๆ
- ✅ เพิ่มโอกาสในการขายสินค้า
