-- ใช้งานฐานข้อมูล
CREATE DATABASE IF NOT EXISTS udonjourney CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE udonjourney;

-- =========================================================
-- ตารางเก็บข้อมูลผู้ใช้ (ระบบล็อกอิน)
-- =========================================================
CREATE TABLE IF NOT EXISTS users (
  id INT AUTO_INCREMENT PRIMARY KEY,
  username VARCHAR(100) NOT NULL UNIQUE,
  email VARCHAR(255) NOT NULL UNIQUE,
  password VARCHAR(255) NOT NULL,
  role ENUM('user','admin') DEFAULT 'user',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ตัวอย่างข้อมูลผู้ใช้
INSERT INTO users (username, email, password, role)
VALUES
('admin', 'admin@example.com', '$2y$10$CjU5kCniqAAKx0np3kWw..EVJW3QZPHvPVtfUgELUkP6UNizS9CKK', 'admin'),
('user1', 'user1@example.com', '$2y$10$CjU5kCniqAAKx0np3kWw..EVJW3QZPHvPVtfUgELUkP6UNizS9CKK', 'user');
-- (รหัสผ่านของทั้งคู่คือ "123456")

-- =========================================================
-- ตารางเก็บข้อมูลสถานที่ท่องเที่ยว
-- =========================================================
CREATE TABLE IF NOT EXISTS places (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(255) NOT NULL,
  slug VARCHAR(255) NOT NULL UNIQUE,
  description TEXT,
  image VARCHAR(512),
  latitude DECIMAL(10,7),
  longitude DECIMAL(10,7),
  category VARCHAR(100),
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ตัวอย่างข้อมูลสถานที่
INSERT INTO places (name, slug, description, image, latitude, longitude, category) VALUES
('สวนสาธารณะหนองประจักษ์','nong-prajakt','สวนสาธารณะใจกลางเมือง มีเป็ดยักษ์สีเหลืองเป็นสัญลักษณ์','/PhurinatUD_full/assets/images/13.jpg',17.4055000,102.7875000,'park'),
('ทะเลบัวแดง','red-lotus-sea','ทะเลบัวแดง บานเต็มผืนน้ำ ช่วงฤดูบัว','/PhurinatUD_full/assets/images/3.jpg',17.4090000,102.7730000,'nature'),
('พิพิธภัณฑ์บ้านเชียง','ban-chiang-museum','พิพิธภัณฑ์บ้านเชียง แหล่งโบราณคดีสำคัญ','/PhurinatUD_full/assets/images/9.jpg',17.4062000,102.9435000,'museum'),
('คำชะโนด','kamchanod','สถานที่ศักดิ์สิทธิ์ในพื้นที่ป่า','/PhurinatUD_full/assets/images/k10.jpg',17.4260000,102.8290000,'religion'),
('อุทยานภูพระบาท','phu-phra-bat','เพิงหินและภาพเขียนสีโบราณ','/PhurinatUD_full/assets/images/p2.jpg',17.4285000,102.9364000,'park'),
('วัดป่าภูก้อน','wat-pa-phu-kon','วัดสวยบนยอดเขา มีทัศนียภาพดี','/PhurinatUD_full/assets/images/4.jpg',17.2770000,102.7510000,'temple');

-- =========================================================
-- ตารางเก็บข้อมูลสินค้า
-- =========================================================
CREATE TABLE IF NOT EXISTS products (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(255) NOT NULL,
  description TEXT,
  price DECIMAL(10,2) NOT NULL DEFAULT 0.00,
  image VARCHAR(512),
  category VARCHAR(100),
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ตัวอย่างสินค้า
INSERT INTO products (name, description, price, image, category) VALUES
('ของที่ระลึกคำชะโนด', 'ของที่ระลึกจากสถานที่ศักดิ์สิทธิ์ คำชะโนด', 150.00, '/PhurinatUD_full/assets/images/pd1.jpg', 'souvenir'),
('โปสการ์ดอุดรธานี', 'โปสการ์ดลายสวยงามจากสถานที่ท่องเที่ยวในจังหวัดอุดรธานี', 25.00, '/PhurinatUD_full/assets/images/pd2.jpg', 'souvenir'),
('หมวกอุดร', 'หมวกปักลายเป็ดยักษ์หนองประจักษ์', 180.00, '/PhurinatUD_full/assets/images/pd3.jpg', 'souvenir');

