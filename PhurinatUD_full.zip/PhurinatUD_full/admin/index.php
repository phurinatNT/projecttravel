<?php
session_start();
require_once '../config/db.php';

// ตรวจสอบว่าเป็น admin หรือไม่
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header('Location: ../auth/login.php');
    exit;
}

// นับจำนวนข้อมูล
$countPlaces = $pdo->query("SELECT COUNT(*) FROM places")->fetchColumn();
$countProducts = $pdo->query("SELECT COUNT(*) FROM products")->fetchColumn();
$countUsers = $pdo->query("SELECT COUNT(*) FROM users")->fetchColumn();

// สร้างตารางที่พัก
$pdo->exec("CREATE TABLE IF NOT EXISTS accommodations (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(255) NOT NULL,
  description TEXT,
  address TEXT,
  phone VARCHAR(20),
  price_range VARCHAR(50),
  image VARCHAR(512),
  latitude DECIMAL(10,7),
  longitude DECIMAL(10,7),
  amenities TEXT,
  rating DECIMAL(3,2) DEFAULT 0.00,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

$countAccommodations = $pdo->query("SELECT COUNT(*) FROM accommodations")->fetchColumn();

// สร้างตารางสถานที่บริการ
$pdo->exec("CREATE TABLE IF NOT EXISTS services (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(255) NOT NULL,
  type ENUM('hospital', 'police', 'fire_station', 'gas_station', 'bank', 'post_office', 'other') NOT NULL,
  address TEXT,
  phone VARCHAR(20),
  latitude DECIMAL(10,7),
  longitude DECIMAL(10,7),
  operating_hours VARCHAR(100),
  description TEXT,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

$countServices = $pdo->query("SELECT COUNT(*) FROM services")->fetchColumn();

// สร้างตารางประเภทสถานที่ถ้ายังไม่มี
$pdo->exec("CREATE TABLE IF NOT EXISTS place_categories (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL UNIQUE,
    description TEXT,
    icon VARCHAR(50),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

$countCategories = $pdo->query("SELECT COUNT(*) FROM place_categories")->fetchColumn();

// เพิ่มข้อมูลเริ่มต้นถ้ายังไม่มี
if ($countCategories == 0) {
    $pdo->exec("INSERT INTO place_categories (name, description, icon) VALUES
        ('สถานที่ท่องเที่ยว', 'สถานที่ท่องเที่ยวต่างๆ ในจังหวัด', '🏞️'),
        ('ที่พัก', 'โรงแรม รีสอร์ท ที่พัก', '🏨'),
        ('สถานที่ทางศาสนา', 'วัด ศาลเจ้า สถานที่ศักดิ์สิทธิ์', '⛩️'),
        ('สถานพยาบาล', 'โรงพยาบาล คลินิก', '🏥'),
        ('สถานีตำรวจ', 'สถานีตำรวจต่างๆ', '🚔')
    ");
}
?>
<!DOCTYPE html>
<html lang="th">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>ระบบจัดการ - Admin Dashboard</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Athiti:wght@300;400;700&display=swap" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css" rel="stylesheet">
    <style>
        body { 
            font-family: 'Athiti', sans-serif; 
            background-color: #f8f9fa;
        }
        .sidebar {
            min-height: 100vh;
            background: linear-gradient(180deg, #ff6600 0%, #ff8533 100%);
            color: white;
            position: fixed;
            top: 0;
            left: 0;
            width: 250px;
            padding-top: 20px;
        }
        .sidebar .nav-link {
            color: rgba(255, 255, 255, 0.8);
            padding: 12px 20px;
            margin: 5px 10px;
            border-radius: 8px;
            transition: all 0.3s;
        }
        .sidebar .nav-link:hover,
        .sidebar .nav-link.active {
            background-color: rgba(255, 255, 255, 0.2);
            color: white;
        }
        .main-content {
            margin-left: 250px;
            padding: 30px;
        }
        .stat-card {
            border-radius: 15px;
            padding: 25px;
            color: white;
            transition: transform 0.3s;
        }
        .stat-card:hover {
            transform: translateY(-5px);
        }
        .stat-card.blue { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); }
        .stat-card.green { background: linear-gradient(135deg, #f093fb 0%, #f5576c 100%); }
        .stat-card.orange { background: linear-gradient(135deg, #4facfe 0%, #00f2fe 100%); }
        .stat-card.purple { background: linear-gradient(135deg, #43e97b 0%, #38f9d7 100%); }
        .stat-card.red { background: linear-gradient(135deg, #fa709a 0%, #fee140 100%); }
        .stat-card.teal { background: linear-gradient(135deg, #30cfd0 0%, #330867 100%); }
    </style>
</head>
<body>
    <!-- Sidebar -->
    <div class="sidebar">
        <div class="text-center mb-4">
            <h3 class="fw-bold">Admin Panel</h3>
            <p class="small mb-0">PhurinatUD</p>
        </div>
        <nav class="nav flex-column">
            <a class="nav-link active" href="index.php">
                <i class="bi bi-speedometer2 me-2"></i> Dashboard
            </a>
            <a class="nav-link" href="categories.php">
                <i class="bi bi-tags me-2"></i> ประเภทสถานที่
            </a>
            <a class="nav-link" href="places.php">
                <i class="bi bi-geo-alt me-2"></i> จัดการสถานที่
            </a>
            <a class="nav-link" href="accommodations.php">
                <i class="bi bi-building me-2"></i> จัดการที่พัก
            </a>
            <a class="nav-link" href="services.php">
                <i class="bi bi-hospital me-2"></i> สถานที่บริการ
            </a>
            <a class="nav-link" href="products.php">
                <i class="bi bi-box-seam me-2"></i> จัดการสินค้า
            </a>
            <a class="nav-link" href="users.php">
                <i class="bi bi-people me-2"></i> จัดการผู้ใช้
            </a>
            <hr class="text-white">
            <a class="nav-link" href="../pages/index.php">
                <i class="bi bi-house me-2"></i> กลับหน้าหลัก
            </a>
            <a class="nav-link" href="../auth/logout.php">
                <i class="bi bi-box-arrow-right me-2"></i> ออกจากระบบ
            </a>
        </nav>
    </div>

    <!-- Main Content -->
    <div class="main-content">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <div>
                <h2 class="fw-bold mb-0">Dashboard</h2>
                <p class="text-muted">ภาพรวมระบบจัดการข้อมูล</p>
            </div>
            <div>
                <span class="text-muted">สวัสดี, </span>
                <strong><?= htmlspecialchars($_SESSION['username']) ?></strong>
            </div>
        </div>

        <!-- Statistics Cards -->
        <div class="row g-4 mb-4">
            <div class="col-md-3">
                <div class="stat-card blue">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <p class="mb-1 opacity-75">ประเภทสถานที่</p>
                            <h2 class="fw-bold mb-0"><?= $countCategories ?></h2>
                        </div>
                        <i class="bi bi-tags" style="font-size: 3rem; opacity: 0.3;"></i>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="stat-card green">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <p class="mb-1 opacity-75">สถานที่ทั้งหมด</p>
                            <h2 class="fw-bold mb-0"><?= $countPlaces ?></h2>
                        </div>
                        <i class="bi bi-geo-alt" style="font-size: 3rem; opacity: 0.3;"></i>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="stat-card orange">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <p class="mb-1 opacity-75">ที่พักทั้งหมด</p>
                            <h2 class="fw-bold mb-0"><?= $countAccommodations ?></h2>
                        </div>
                        <i class="bi bi-building" style="font-size: 3rem; opacity: 0.3;"></i>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="stat-card purple">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <p class="mb-1 opacity-75">สินค้าชุมชน</p>
                            <h2 class="fw-bold mb-0"><?= $countProducts ?></h2>
                        </div>
                        <i class="bi bi-box-seam" style="font-size: 3rem; opacity: 0.3;"></i>
                    </div>
                </div>
            </div>
        </div>

        <!-- Row 2 -->
        <div class="row g-4 mb-4">
            <div class="col-md-3">
                <div class="stat-card red">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <p class="mb-1 opacity-75">สถานที่บริการ</p>
                            <h2 class="fw-bold mb-0"><?= $countServices ?></h2>
                        </div>
                        <i class="bi bi-hospital" style="font-size: 3rem; opacity: 0.3;"></i>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="stat-card teal">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <p class="mb-1 opacity-75">ผู้ใช้ทั้งหมด</p>
                            <h2 class="fw-bold mb-0"><?= $countUsers ?></h2>
                        </div>
                        <i class="bi bi-people" style="font-size: 3rem; opacity: 0.3;"></i>
                    </div>
                </div>
            </div>
        </div>

        <!-- Quick Actions -->
        <div class="row g-4">
            <div class="col-md-12">
                <div class="card border-0 shadow-sm">
                    <div class="card-body">
                        <h5 class="card-title fw-bold mb-4">เมนูจัดการด่วน</h5>
                        <div class="row g-3">
                            <div class="col-md-3">
                                <a href="categories.php" class="btn btn-outline-primary w-100 py-3">
                                    <i class="bi bi-tags d-block fs-2 mb-2"></i>
                                    จัดการประเภทสถานที่
                                </a>
                            </div>
                            <div class="col-md-3">
                                <a href="places.php" class="btn btn-outline-success w-100 py-3">
                                    <i class="bi bi-geo-alt d-block fs-2 mb-2"></i>
                                    จัดการสถานที่
                                </a>
                            </div>
                            <div class="col-md-3">
                                <a href="accommodations.php" class="btn btn-outline-info w-100 py-3">
                                    <i class="bi bi-building d-block fs-2 mb-2"></i>
                                    จัดการที่พัก
                                </a>
                            </div>
                            <div class="col-md-3">
                                <a href="services.php" class="btn btn-outline-danger w-100 py-3">
                                    <i class="bi bi-hospital d-block fs-2 mb-2"></i>
                                    จัดการสถานที่บริการ
                                </a>
                            </div>
                        </div>
                        <div class="row g-3 mt-2">
                            <div class="col-md-3">
                                <a href="products.php" class="btn btn-outline-warning w-100 py-3">
                                    <i class="bi bi-box-seam d-block fs-2 mb-2"></i>
                                    จัดการสินค้า
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Recent Data -->
        <div class="row g-4 mt-1">
            <div class="col-md-6">
                <div class="card border-0 shadow-sm">
                    <div class="card-body">
                        <h5 class="card-title fw-bold mb-3">สถานที่ล่าสุด</h5>
                        <div class="list-group list-group-flush">
                            <?php
                            $recentPlaces = $pdo->query("SELECT name, created_at FROM places ORDER BY created_at DESC LIMIT 5")->fetchAll();
                            foreach ($recentPlaces as $place):
                            ?>
                            <div class="list-group-item d-flex justify-content-between align-items-center">
                                <span><?= htmlspecialchars($place['name']) ?></span>
                                <small class="text-muted"><?= date('d/m/Y', strtotime($place['created_at'])) ?></small>
                            </div>
                            <?php endforeach; ?>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-6">
                <div class="card border-0 shadow-sm">
                    <div class="card-body">
                        <h5 class="card-title fw-bold mb-3">สินค้าล่าสุด</h5>
                        <div class="list-group list-group-flush">
                            <?php
                            $recentProducts = $pdo->query("SELECT name, price, created_at FROM products ORDER BY created_at DESC LIMIT 5")->fetchAll();
                            foreach ($recentProducts as $product):
                            ?>
                            <div class="list-group-item d-flex justify-content-between align-items-center">
                                <span><?= htmlspecialchars($product['name']) ?></span>
                                <span>
                                    <span class="badge bg-success"><?= number_format($product['price'], 2) ?> ฿</span>
                                    <small class="text-muted ms-2"><?= date('d/m/Y', strtotime($product['created_at'])) ?></small>
                                </span>
                            </div>
                            <?php endforeach; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
