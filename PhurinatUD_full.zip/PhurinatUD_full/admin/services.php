<?php
session_start();
require_once '../config/db.php';

// ตรวจสอบสิทธิ์ admin
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header('Location: ../auth/login.php');
    exit;
}

// สร้างตารางถ้ายังไม่มี
$pdo->exec("CREATE TABLE IF NOT EXISTS services (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(255) NOT NULL,
  type ENUM('hospital', 'police', 'fire_station', 'gas_station', 'bank', 'post_office', 'other') NOT NULL,
  address TEXT,
  phone VARCHAR(20),
  latitude DECIMAL(10,7),
  longitude DECIMAL(10,7),
  operating_hours VARCHAR(100),
  description TEXT,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

// ลบข้อมูล
if (isset($_GET['delete'])) {
    $id = (int)$_GET['delete'];
    $stmt = $pdo->prepare("DELETE FROM services WHERE id = ?");
    $stmt->execute([$id]);
    header('Location: services.php?success=deleted');
    exit;
}

// เพิ่ม/แก้ไขข้อมูล
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id = $_POST['id'] ?? null;
    $name = $_POST['name'];
    $type = $_POST['type'];
    $address = $_POST['address'];
    $phone = $_POST['phone'];
    $latitude = $_POST['latitude'] ?: null;
    $longitude = $_POST['longitude'] ?: null;
    $operating_hours = $_POST['operating_hours'];
    $description = $_POST['description'];

    if ($id) {
        // แก้ไข
        $stmt = $pdo->prepare("UPDATE services SET name=?, type=?, address=?, phone=?, latitude=?, longitude=?, operating_hours=?, description=? WHERE id=?");
        $stmt->execute([$name, $type, $address, $phone, $latitude, $longitude, $operating_hours, $description, $id]);
        header('Location: services.php?success=updated');
    } else {
        // เพิ่มใหม่
        $stmt = $pdo->prepare("INSERT INTO services (name, type, address, phone, latitude, longitude, operating_hours, description) VALUES (?,?,?,?,?,?,?,?)");
        $stmt->execute([$name, $type, $address, $phone, $latitude, $longitude, $operating_hours, $description]);
        header('Location: services.php?success=added');
    }
    exit;
}

// ดึงข้อมูลสำหรับแก้ไข
$editData = null;
if (isset($_GET['edit'])) {
    $stmt = $pdo->prepare("SELECT * FROM services WHERE id = ?");
    $stmt->execute([$_GET['edit']]);
    $editData = $stmt->fetch(PDO::FETCH_ASSOC);
}

// ค้นหา
$search = $_GET['search'] ?? '';
$typeFilter = $_GET['type'] ?? '';

$query = "SELECT * FROM services WHERE 1=1";
$params = [];

if ($search) {
    $query .= " AND (name LIKE :search OR address LIKE :search)";
    $params['search'] = "%$search%";
}

if ($typeFilter) {
    $query .= " AND type = :type";
    $params['type'] = $typeFilter;
}

$query .= " ORDER BY type, name";

$stmt = $pdo->prepare($query);
$stmt->execute($params);
$services = $stmt->fetchAll(PDO::FETCH_ASSOC);

// นับจำนวนแต่ละประเภท
$countStmt = $pdo->query("SELECT type, COUNT(*) as count FROM services GROUP BY type");
$counts = [];
while ($row = $countStmt->fetch(PDO::FETCH_ASSOC)) {
    $counts[$row['type']] = $row['count'];
}
?>
<!DOCTYPE html>
<html lang="th">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>จัดการสถานที่บริการ - Admin</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Athiti:wght@300;400;700&display=swap" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css" rel="stylesheet">
    <style>
        body { 
            font-family: 'Athiti', sans-serif; 
            background-color: #f8f9fa;
        }
        .sidebar {
            min-height: 100vh;
            background: linear-gradient(180deg, #ff6600 0%, #ff8533 100%);
            color: white;
            position: fixed;
            top: 0;
            left: 0;
            width: 250px;
            padding-top: 20px;
        }
        .sidebar .nav-link {
            color: rgba(255, 255, 255, 0.8);
            padding: 12px 20px;
            margin: 5px 10px;
            border-radius: 8px;
            transition: all 0.3s;
        }
        .sidebar .nav-link:hover,
        .sidebar .nav-link.active {
            background-color: rgba(255, 255, 255, 0.2);
            color: white;
        }
        .main-content {
            margin-left: 250px;
            padding: 30px;
        }
        .stat-card {
            border-radius: 15px;
            padding: 20px;
            color: white;
            margin-bottom: 20px;
        }
    </style>
</head>
<body>
    <!-- Sidebar -->
    <div class="sidebar">
        <div class="text-center mb-4">
            <h3 class="fw-bold">Admin Panel</h3>
            <p class="small mb-0">PhurinatUD</p>
        </div>
        <nav class="nav flex-column">
            <a class="nav-link" href="index.php">
                <i class="bi bi-speedometer2 me-2"></i> Dashboard
            </a>
            <a class="nav-link" href="categories.php">
                <i class="bi bi-tags me-2"></i> ประเภทสถานที่
            </a>
            <a class="nav-link" href="places.php">
                <i class="bi bi-geo-alt me-2"></i> จัดการสถานที่
            </a>
            <a class="nav-link" href="accommodations.php">
                <i class="bi bi-building me-2"></i> จัดการที่พัก
            </a>
            <a class="nav-link active" href="services.php">
                <i class="bi bi-hospital me-2"></i> จัดการสถานที่บริการ
            </a>
            <a class="nav-link" href="products.php">
                <i class="bi bi-box-seam me-2"></i> จัดการสินค้า
            </a>
            <a class="nav-link" href="users.php">
                <i class="bi bi-people me-2"></i> จัดการผู้ใช้
            </a>
            <hr class="text-white">
            <a class="nav-link" href="../pages/index.php">
                <i class="bi bi-house me-2"></i> กลับหน้าหลัก
            </a>
            <a class="nav-link" href="../auth/logout.php">
                <i class="bi bi-box-arrow-right me-2"></i> ออกจากระบบ
            </a>
        </nav>
    </div>

    <!-- Main Content -->
    <div class="main-content">
            <div class="d-flex justify-content-between align-items-center mb-4">
                <h2><i class="bi bi-hospital"></i> จัดการสถานที่บริการ</h2>
                <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#serviceModal" onclick="clearForm()">
                    <i class="bi bi-plus-circle"></i> เพิ่มสถานที่บริการ
                </button>
            </div>

            <?php if (isset($_GET['success'])): ?>
                <div class="alert alert-success alert-dismissible fade show">
                    <?php
                    if ($_GET['success'] === 'added') echo 'เพิ่มข้อมูลสำเร็จ!';
                    if ($_GET['success'] === 'updated') echo 'แก้ไขข้อมูลสำเร็จ!';
                    if ($_GET['success'] === 'deleted') echo 'ลบข้อมูลสำเร็จ!';
                    ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
            <?php endif; ?>

            <!-- Statistics -->
            <div class="row mb-4">
                <div class="col-md-3">
                    <div class="stat-card" style="background: linear-gradient(135deg, #f093fb 0%, #f5576c 100%);">
                        <h3><?= $counts['hospital'] ?? 0 ?></h3>
                        <p><i class="bi bi-hospital"></i> โรงพยาบาล</p>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="stat-card" style="background: linear-gradient(135deg, #4facfe 0%, #00f2fe 100%);">
                        <h3><?= $counts['police'] ?? 0 ?></h3>
                        <p><i class="bi bi-shield-fill-check"></i> สถานีตำรวจ</p>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="stat-card" style="background: linear-gradient(135deg, #fa709a 0%, #fee140 100%);">
                        <h3><?= $counts['fire_station'] ?? 0 ?></h3>
                        <p><i class="bi bi-fire"></i> สถานีดับเพลิง</p>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="stat-card" style="background: linear-gradient(135deg, #30cfd0 0%, #330867 100%);">
                        <h3><?= count($services) ?></h3>
                        <p><i class="bi bi-geo-alt"></i> ทั้งหมด</p>
                    </div>
                </div>
            </div>

        <!-- Search & Filter -->
        <div class="card border-0 shadow-sm mb-4">
            <div class="card-body">
                    <form method="GET" class="row g-3">
                        <div class="col-md-6">
                            <input type="text" name="search" class="form-control" placeholder="ค้นหาสถานที่บริการ..." value="<?= htmlspecialchars($search) ?>">
                        </div>
                        <div class="col-md-4">
                            <select name="type" class="form-select">
                                <option value="">ทุกประเภท</option>
                                <option value="hospital" <?= $typeFilter === 'hospital' ? 'selected' : '' ?>>โรงพยาบาล</option>
                                <option value="police" <?= $typeFilter === 'police' ? 'selected' : '' ?>>สถานีตำรวจ</option>
                                <option value="fire_station" <?= $typeFilter === 'fire_station' ? 'selected' : '' ?>>สถานีดับเพลิง</option>
                                <option value="gas_station" <?= $typeFilter === 'gas_station' ? 'selected' : '' ?>>ปั๊มน้ำมัน</option>
                                <option value="bank" <?= $typeFilter === 'bank' ? 'selected' : '' ?>>ธนาคาร</option>
                                <option value="post_office" <?= $typeFilter === 'post_office' ? 'selected' : '' ?>>ไปรษณีย์</option>
                                <option value="other" <?= $typeFilter === 'other' ? 'selected' : '' ?>>อื่นๆ</option>
                            </select>
                        </div>
                        <div class="col-md-2">
                            <button type="submit" class="btn btn-primary w-100">
                                <i class="bi bi-search"></i> ค้นหา
                            </button>
                        </div>
                    </form>
                </div>
            </div>

        <!-- Services Table -->
        <div class="card border-0 shadow-sm">
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-hover">
                        <thead class="table-light">
                            <tr>
                                <th width="50">#</th>
                                <th>ชื่อ</th>
                                <th>ประเภท</th>
                                <th>ที่อยู่</th>
                                <th>โทรศัพท์</th>
                                <th>เวลาทำการ</th>
                                <th width="120" class="text-center">จัดการ</th>
                            </tr>
                        </thead>
                            <tbody>
                                <?php if (count($services) > 0): ?>
                                    <?php foreach ($services as $service): ?>
                                        <tr>
                                            <td><?= $service['id'] ?></td>
                                            <td><strong><?= htmlspecialchars($service['name']) ?></strong></td>
                                            <td>
                                                <?php
                                                $typeLabels = [
                                                    'hospital' => '<span class="badge bg-danger">โรงพยาบาล</span>',
                                                    'police' => '<span class="badge bg-primary">ตำรวจ</span>',
                                                    'fire_station' => '<span class="badge bg-warning">ดับเพลิง</span>',
                                                    'gas_station' => '<span class="badge bg-success">ปั๊มน้ำมัน</span>',
                                                    'bank' => '<span class="badge bg-info">ธนาคาร</span>',
                                                    'post_office' => '<span class="badge bg-secondary">ไปรษณีย์</span>',
                                                    'other' => '<span class="badge bg-dark">อื่นๆ</span>'
                                                ];
                                                echo $typeLabels[$service['type']] ?? $service['type'];
                                                ?>
                                            </td>
                                            <td><?= htmlspecialchars(mb_substr($service['address'], 0, 50)) ?>...</td>
                                            <td><?= htmlspecialchars($service['phone']) ?></td>
                                            <td><small><?= htmlspecialchars($service['operating_hours']) ?></small></td>
                                        <td class="text-center">
                                            <button type="button" class="btn btn-sm btn-warning" onclick='editService(<?= json_encode($service) ?>)'>
                                                <i class="bi bi-pencil"></i>
                                            </button>
                                            <a href="?delete=<?= $service['id'] ?>" class="btn btn-sm btn-danger" onclick="return confirm('ยืนยันการลบ?')">
                                                <i class="bi bi-trash"></i>
                                            </a>
                                        </td>
                                        </tr>
                                    <?php endforeach; ?>
                            <?php else: ?>
                                <tr>
                                    <td colspan="7" class="text-center text-muted py-4">ไม่มีข้อมูล</td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

<!-- Modal -->
<div class="modal fade" id="serviceModal" tabindex="-1">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="modalTitle">เพิ่มสถานที่บริการ</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <form method="POST">
                <div class="modal-body">
                    <input type="hidden" name="id" id="serviceId">
                    
                    <div class="row">
                        <div class="col-md-8 mb-3">
                            <label class="form-label">ชื่อสถานที่บริการ *</label>
                            <input type="text" name="name" id="serviceName" class="form-control" required>
                        </div>
                        
                        <div class="col-md-4 mb-3">
                            <label class="form-label">ประเภท *</label>
                            <select name="type" id="serviceType" class="form-select" required>
                                <option value="hospital">โรงพยาบาล</option>
                                <option value="police">สถานีตำรวจ</option>
                                <option value="fire_station">สถานีดับเพลิง</option>
                                <option value="gas_station">ปั๊มน้ำมัน</option>
                                <option value="bank">ธนาคาร</option>
                                <option value="post_office">ไปรษณีย์</option>
                                <option value="other">อื่นๆ</option>
                            </select>
                        </div>
                    </div>
                    
                    <div class="mb-3">
                        <label class="form-label">ที่อยู่</label>
                        <textarea name="address" id="serviceAddress" class="form-control" rows="2"></textarea>
                    </div>
                    
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label class="form-label">โทรศัพท์</label>
                            <input type="text" name="phone" id="servicePhone" class="form-control">
                        </div>
                        
                        <div class="col-md-6 mb-3">
                            <label class="form-label">เวลาทำการ</label>
                            <input type="text" name="operating_hours" id="serviceHours" class="form-control" placeholder="เช่น 24 ชั่วโมง, 08:00-17:00">
                        </div>
                    </div>
                    
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label class="form-label">ละติจูด (Latitude)</label>
                            <input type="text" name="latitude" id="serviceLatitude" class="form-control" placeholder="17.4123000">
                        </div>
                        
                        <div class="col-md-6 mb-3">
                            <label class="form-label">ลองจิจูด (Longitude)</label>
                            <input type="text" name="longitude" id="serviceLongitude" class="form-control" placeholder="102.7890000">
                        </div>
                    </div>
                    
                    <div class="mb-3">
                        <label class="form-label">คำอธิบาย</label>
                        <textarea name="description" id="serviceDescription" class="form-control" rows="3"></textarea>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">ยกเลิก</button>
                    <button type="submit" class="btn btn-primary">บันทึก</button>
                </div>
            </form>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script>
function clearForm() {
    document.getElementById('modalTitle').textContent = 'เพิ่มสถานที่บริการ';
    document.getElementById('serviceId').value = '';
    document.getElementById('serviceName').value = '';
    document.getElementById('serviceType').value = 'hospital';
    document.getElementById('serviceAddress').value = '';
    document.getElementById('servicePhone').value = '';
    document.getElementById('serviceHours').value = '';
    document.getElementById('serviceLatitude').value = '';
    document.getElementById('serviceLongitude').value = '';
    document.getElementById('serviceDescription').value = '';
}

function editService(service) {
    document.getElementById('modalTitle').textContent = 'แก้ไขสถานที่บริการ';
    document.getElementById('serviceId').value = service.id;
    document.getElementById('serviceName').value = service.name;
    document.getElementById('serviceType').value = service.type;
    document.getElementById('serviceAddress').value = service.address || '';
    document.getElementById('servicePhone').value = service.phone || '';
    document.getElementById('serviceHours').value = service.operating_hours || '';
    document.getElementById('serviceLatitude').value = service.latitude || '';
    document.getElementById('serviceLongitude').value = service.longitude || '';
    document.getElementById('serviceDescription').value = service.description || '';
    
    var myModal = new bootstrap.Modal(document.getElementById('serviceModal'));
    myModal.show();
}
</script>
</body>
</html>
