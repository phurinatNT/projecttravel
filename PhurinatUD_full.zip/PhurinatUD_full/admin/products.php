<?php
session_start();
require_once '../config/db.php';

// ตรวจสอบว่าเป็น admin หรือไม่
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header('Location: ../auth/login.php');
    exit;
}

// จัดการการลบ
if (isset($_GET['delete'])) {
    $id = $_GET['delete'];
    
    // ลบรูปภาพหลัก
    $stmt = $pdo->prepare("SELECT image FROM products WHERE id = ?");
    $stmt->execute([$id]);
    $product = $stmt->fetch();
    if ($product && $product['image'] && file_exists('../' . $product['image'])) {
        unlink('../' . $product['image']);
    }
    
    // ลบรูปภาพ gallery
    $stmt = $pdo->prepare("SELECT image_path FROM product_images WHERE product_id = ?");
    $stmt->execute([$id]);
    $images = $stmt->fetchAll();
    foreach ($images as $img) {
        if (file_exists('../' . $img['image_path'])) {
            unlink('../' . $img['image_path']);
        }
    }
    
    // ลบข้อมูล
    $stmt = $pdo->prepare("DELETE FROM products WHERE id = ?");
    $stmt->execute([$id]);
    header('Location: products.php?success=deleted');
    exit;
}

// จัดการลบรูป gallery
if (isset($_GET['delete_gallery'])) {
    $img_id = $_GET['delete_gallery'];
    $product_id = $_GET['product_id'];
    
    $stmt = $pdo->prepare("SELECT image_path FROM product_images WHERE id = ?");
    $stmt->execute([$img_id]);
    $img = $stmt->fetch();
    
    if ($img && file_exists('../' . $img['image_path'])) {
        unlink('../' . $img['image_path']);
    }
    
    $stmt = $pdo->prepare("DELETE FROM product_images WHERE id = ?");
    $stmt->execute([$img_id]);
    
    header('Location: products.php?edit=' . $product_id);
    exit;
}

// จัดการการเพิ่ม/แก้ไข
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = $_POST['name'];
    $description = $_POST['description'];
    $price = $_POST['price'];
    $product_url = $_POST['product_url'] ?? '';
    $category = $_POST['category'];
    
    // จัดการอัพโหลดรูปหลัก
    $image_path = $_POST['current_image'] ?? '';
    if (isset($_FILES['image']) && $_FILES['image']['error'] === UPLOAD_ERR_OK) {
        $upload_dir = '../assets/uploads/products/';
        if (!file_exists($upload_dir)) {
            mkdir($upload_dir, 0777, true);
        }
        
        $file_extension = strtolower(pathinfo($_FILES['image']['name'], PATHINFO_EXTENSION));
        $allowed_extensions = ['jpg', 'jpeg', 'png', 'gif', 'webp'];
        
        if (in_array($file_extension, $allowed_extensions)) {
            $new_filename = uniqid() . '_' . time() . '.' . $file_extension;
            $target_path = $upload_dir . $new_filename;
            
            if (move_uploaded_file($_FILES['image']['tmp_name'], $target_path)) {
                // ลบรูปเก่า
                if (!empty($_POST['current_image']) && file_exists('../' . $_POST['current_image'])) {
                    unlink('../' . $_POST['current_image']);
                }
                $image_path = 'assets/uploads/products/' . $new_filename;
            }
        }
    }
    
    if (isset($_POST['id']) && !empty($_POST['id'])) {
        // แก้ไข
        $product_id = $_POST['id'];
        $stmt = $pdo->prepare("UPDATE products SET name = ?, description = ?, price = ?, image = ?, product_url = ?, category = ? WHERE id = ?");
        $stmt->execute([$name, $description, $price, $image_path, $product_url, $category, $product_id]);
        
        // จัดการ Gallery
        if (isset($_FILES['gallery']) && !empty($_FILES['gallery']['name'][0])) {
            $upload_dir = '../assets/uploads/products/';
            foreach ($_FILES['gallery']['tmp_name'] as $key => $tmp_name) {
                if ($_FILES['gallery']['error'][$key] === UPLOAD_ERR_OK) {
                    $file_extension = strtolower(pathinfo($_FILES['gallery']['name'][$key], PATHINFO_EXTENSION));
                    if (in_array($file_extension, $allowed_extensions)) {
                        $new_filename = uniqid() . '_' . time() . '_' . $key . '.' . $file_extension;
                        $target_path = $upload_dir . $new_filename;
                        if (move_uploaded_file($tmp_name, $target_path)) {
                            $gallery_path = 'assets/uploads/products/' . $new_filename;
                            $stmt = $pdo->prepare("INSERT INTO product_images (product_id, image_path) VALUES (?, ?)");
                            $stmt->execute([$product_id, $gallery_path]);
                        }
                    }
                }
            }
        }
        
        header('Location: products.php?success=updated');
    } else {
        // เพิ่มใหม่
        $stmt = $pdo->prepare("INSERT INTO products (name, description, price, image, product_url, category) VALUES (?, ?, ?, ?, ?, ?)");
        $stmt->execute([$name, $description, $price, $image_path, $product_url, $category]);
        $product_id = $pdo->lastInsertId();
        
        // จัดการ Gallery
        if (isset($_FILES['gallery']) && !empty($_FILES['gallery']['name'][0])) {
            $upload_dir = '../assets/uploads/products/';
            $allowed_extensions = ['jpg', 'jpeg', 'png', 'gif', 'webp'];
            
            foreach ($_FILES['gallery']['tmp_name'] as $key => $tmp_name) {
                if ($_FILES['gallery']['error'][$key] === UPLOAD_ERR_OK) {
                    $file_extension = strtolower(pathinfo($_FILES['gallery']['name'][$key], PATHINFO_EXTENSION));
                    if (in_array($file_extension, $allowed_extensions)) {
                        $new_filename = uniqid() . '_' . time() . '_' . $key . '.' . $file_extension;
                        $target_path = $upload_dir . $new_filename;
                        if (move_uploaded_file($tmp_name, $target_path)) {
                            $gallery_path = 'assets/uploads/products/' . $new_filename;
                            $stmt = $pdo->prepare("INSERT INTO product_images (product_id, image_path) VALUES (?, ?)");
                            $stmt->execute([$product_id, $gallery_path]);
                        }
                    }
                }
            }
        }
        
        header('Location: products.php?success=added');
    }
    exit;
}

// ดึงข้อมูลสำหรับแก้ไข
$editData = null;
if (isset($_GET['edit'])) {
    $stmt = $pdo->prepare("SELECT * FROM products WHERE id = ?");
    $stmt->execute([$_GET['edit']]);
    $editData = $stmt->fetch();
}

// ค้นหา
$search = $_GET['search'] ?? '';
$query = "SELECT * FROM products";
if ($search) {
    $query .= " WHERE name LIKE :search OR description LIKE :search";
}
$query .= " ORDER BY created_at DESC";

$stmt = $pdo->prepare($query);
if ($search) {
    $stmt->execute(['search' => "%$search%"]);
} else {
    $stmt->execute();
}
$products = $stmt->fetchAll();

function adminImageSrc($path) {
    if (empty($path)) {
        return '';
    }

    $cleanPath = trim($path);
    if ($cleanPath === '') {
        return '';
    }

    if (preg_match('#^(?:https?:)?//#', $cleanPath)) {
        return $cleanPath;
    }

    if ($cleanPath[0] === '/' || strpos($cleanPath, '../') === 0) {
        return $cleanPath;
    }

    return '../' . ltrim($cleanPath, '/');
}
?>
<!DOCTYPE html>
<html lang="th">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>จัดการสินค้า - Admin</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Athiti:wght@300;400;700&display=swap" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css" rel="stylesheet">
    <style>
        body { font-family: 'Athiti', sans-serif; background-color: #f8f9fa; }
        .sidebar {
            min-height: 100vh;
            background: linear-gradient(180deg, #ff6600 0%, #ff8533 100%);
            color: white;
            position: fixed;
            top: 0;
            left: 0;
            width: 250px;
            padding-top: 20px;
        }
        .sidebar .nav-link {
            color: rgba(255, 255, 255, 0.8);
            padding: 12px 20px;
            margin: 5px 10px;
            border-radius: 8px;
            transition: all 0.3s;
        }
        .sidebar .nav-link:hover,
        .sidebar .nav-link.active {
            background-color: rgba(255, 255, 255, 0.2);
            color: white;
        }
        .main-content {
            margin-left: 250px;
            padding: 30px;
        }
        .product-img {
            width: 80px;
            height: 80px;
            object-fit: cover;
            border-radius: 8px;
        }
    </style>
</head>
<body>
    <!-- Sidebar -->
    <div class="sidebar">
        <div class="text-center mb-4">
            <h3 class="fw-bold">Admin Panel</h3>
            <p class="small mb-0">PhurinatUD</p>
        </div>
        <nav class="nav flex-column">
            <a class="nav-link" href="index.php">
                <i class="bi bi-speedometer2 me-2"></i> Dashboard
            </a>
            <a class="nav-link" href="categories.php">
                <i class="bi bi-tags me-2"></i> ประเภทสถานที่
            </a>
            <a class="nav-link" href="places.php">
                <i class="bi bi-geo-alt me-2"></i> จัดการสถานที่
            </a>
            <a class="nav-link" href="accommodations.php">
                <i class="bi bi-building me-2"></i> จัดการที่พัก
            </a>
            <a class="nav-link" href="services.php">
                <i class="bi bi-hospital me-2"></i> จัดการสถานที่บริการ
            </a>
            <a class="nav-link active" href="products.php">
                <i class="bi bi-box-seam me-2"></i> จัดการสินค้า
            </a>
            <a class="nav-link" href="users.php">
                <i class="bi bi-people me-2"></i> จัดการผู้ใช้
            </a>
            <hr class="text-white">
            <a class="nav-link" href="../pages/index.php">
                <i class="bi bi-house me-2"></i> กลับหน้าหลัก
            </a>
            <a class="nav-link" href="../auth/logout.php">
                <i class="bi bi-box-arrow-right me-2"></i> ออกจากระบบ
            </a>
        </nav>
    </div>

    <!-- Main Content -->
    <div class="main-content">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <div>
                <h2 class="fw-bold mb-0">จัดการสินค้าชุมชน</h2>
                <p class="text-muted">เพิ่ม ลบ แก้ไข ค้นหา ข้อมูลสินค้า</p>
            </div>
            <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#productModal">
                <i class="bi bi-plus-circle me-2"></i>เพิ่มสินค้าใหม่
            </button>
        </div>

        <!-- Success Message -->
        <?php if (isset($_GET['success'])): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <?php
            if ($_GET['success'] === 'added') echo 'เพิ่มสินค้าสำเร็จ!';
            elseif ($_GET['success'] === 'updated') echo 'แก้ไขสินค้าสำเร็จ!';
            elseif ($_GET['success'] === 'deleted') echo 'ลบสินค้าสำเร็จ!';
            ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
        <?php endif; ?>

        <!-- Search -->
        <div class="card border-0 shadow-sm mb-4">
            <div class="card-body">
                <form method="GET" class="row g-3">
                    <div class="col-md-10">
                        <input type="text" name="search" class="form-control" placeholder="ค้นหาสินค้า..." value="<?= htmlspecialchars($search) ?>">
                    </div>
                    <div class="col-md-2">
                        <button type="submit" class="btn btn-primary w-100">
                            <i class="bi bi-search me-2"></i>ค้นหา
                        </button>
                    </div>
                </form>
            </div>
        </div>

        <!-- Products Grid -->
        <div class="row g-4">
            <?php if (count($products) > 0): ?>
                <?php foreach ($products as $product): ?>
                <div class="col-md-4">
                    <div class="card border-0 shadow-sm h-100">
                        <?php if ($product['image']): ?>
                        <img src="<?= htmlspecialchars(adminImageSrc($product['image'])) ?>" class="card-img-top" style="height: 200px; object-fit: cover;" alt="" onerror="this.src='../assets/images/default-product.jpg'">
                        <?php else: ?>
                        <div class="bg-secondary d-flex align-items-center justify-content-center text-white" style="height: 200px;">
                            <i class="bi bi-image fs-1"></i>
                        </div>
                        <?php endif; ?>
                        <div class="card-body">
                            <h5 class="card-title fw-bold"><?= htmlspecialchars($product['name']) ?></h5>
                            <p class="card-text text-muted small"><?= htmlspecialchars($product['description']) ?></p>
                            <div class="d-flex justify-content-between align-items-center">
                                <span class="badge bg-success fs-6"><?= number_format($product['price'], 2) ?> ฿</span>
                                <div>
                                    <a href="?edit=<?= $product['id'] ?>" class="btn btn-sm btn-warning">
                                        <i class="bi bi-pencil"></i>
                                    </a>
                                    <a href="?delete=<?= $product['id'] ?>" class="btn btn-sm btn-danger" onclick="return confirm('ยืนยันการลบ?')">
                                        <i class="bi bi-trash"></i>
                                    </a>
                                </div>
                            </div>
                        </div>
                        <div class="card-footer bg-transparent border-top-0">
                            <small class="text-muted">เพิ่มเมื่อ: <?= date('d/m/Y H:i', strtotime($product['created_at'])) ?></small>
                        </div>
                    </div>
                </div>
                <?php endforeach; ?>
            <?php else: ?>
                <div class="col-12">
                    <div class="alert alert-info text-center">
                        <i class="bi bi-info-circle me-2"></i>ไม่พบข้อมูลสินค้า
                    </div>
                </div>
            <?php endif; ?>
        </div>
    </div>

    <!-- Modal -->
    <div class="modal fade" id="productModal" tabindex="-1">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <form method="POST" enctype="multipart/form-data">
                    <div class="modal-header">
                        <h5 class="modal-title"><?= $editData ? 'แก้ไขสินค้า' : 'เพิ่มสินค้าใหม่' ?></h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                    </div>
                    <div class="modal-body">
                        <input type="hidden" name="id" value="<?= $editData['id'] ?? '' ?>">
                        <input type="hidden" name="current_image" value="<?= $editData['image'] ?? '' ?>">
                        
                        <div class="row">
                            <div class="col-md-8 mb-3">
                                <label class="form-label">ชื่อสินค้า</label>
                                <input type="text" name="name" class="form-control" value="<?= htmlspecialchars($editData['name'] ?? '') ?>" required>
                            </div>
                            <div class="col-md-4 mb-3">
                                <label class="form-label">ราคา (บาท)</label>
                                <input type="number" step="0.01" name="price" class="form-control" value="<?= htmlspecialchars($editData['price'] ?? '') ?>" required>
                            </div>
                        </div>
                        
                        <div class="mb-3">
                            <label class="form-label">คำอธิบาย</label>
                            <textarea name="description" class="form-control" rows="3" required><?= htmlspecialchars($editData['description'] ?? '') ?></textarea>
                        </div>
                        
                        <div class="mb-3">
                            <label class="form-label">รูปภาพหลัก <?= $editData ? '(เลือกใหม่หากต้องการเปลี่ยน)' : '' ?></label>
                            <input type="file" name="image" class="form-control" accept="image/*" onchange="previewMainImage(event)">
                            <small class="text-muted">รองรับไฟล์: JPG, JPEG, PNG, GIF, WEBP</small>
                            
                            <?php if ($editData && $editData['image']): ?>
                                <div class="mt-2">
                                    <p class="mb-1">รูปปัจจุบัน:</p>
                                    <img src="<?= htmlspecialchars(adminImageSrc($editData['image'])) ?>" class="img-thumbnail" style="max-width: 200px;" id="currentMainImage">
                                </div>
                            <?php endif; ?>
                            
                            <img id="mainImagePreview" class="img-thumbnail mt-2" style="max-width: 200px; display:none;">
                        </div>
                        
                        <div class="mb-3">
                            <label class="form-label">รูปภาพเพิ่มเติม (Gallery)</label>
                            <input type="file" name="gallery[]" class="form-control" accept="image/*" multiple onchange="previewGalleryImages(event)">
                            <small class="text-muted">สามารถเลือกหลายรูปได้พร้อมกัน</small>
                            <div id="galleryPreview" class="mt-2 d-flex flex-wrap gap-2"></div>
                            
                            <?php if ($editData): ?>
                                <?php
                                $stmt = $pdo->prepare("SELECT * FROM product_images WHERE product_id = ?");
                                $stmt->execute([$editData['id']]);
                                $gallery_images = $stmt->fetchAll();
                                if (count($gallery_images) > 0):
                                ?>
                                    <div class="mt-3">
                                        <p class="mb-2">รูปภาพที่มีอยู่:</p>
                                        <div class="d-flex flex-wrap gap-2">
                                            <?php foreach ($gallery_images as $img): ?>
                                                <div class="position-relative">
                                                    <img src="<?= htmlspecialchars(adminImageSrc($img['image_path'])) ?>" class="img-thumbnail" style="width: 100px; height: 100px; object-fit: cover;">
                                                    <a href="?delete_gallery=<?= $img['id'] ?>&product_id=<?= $editData['id'] ?>" class="btn btn-danger btn-sm position-absolute top-0 end-0" onclick="return confirm('ลบรูปนี้?')" style="padding: 2px 6px;">
                                                        <i class="bi bi-x"></i>
                                                    </a>
                                                </div>
                                            <?php endforeach; ?>
                                        </div>
                                    </div>
                                <?php endif; ?>
                            <?php endif; ?>
                        </div>
                        
                        <div class="mb-3">
                            <label class="form-label">ลิงก์ขายสินค้า (URL)</label>
                            <input type="url" name="product_url" class="form-control" value="<?= htmlspecialchars($editData['product_url'] ?? '') ?>" placeholder="https://example.com/product">
                            <small class="text-muted">ลิงก์สำหรับซื้อสินค้า (ถ้ามี)</small>
                        </div>
                        
                        <div class="mb-3">
                            <label class="form-label">หมวดหมู่</label>
                            <select name="category" class="form-select">
                                <option value="souvenir" <?= ($editData['category'] ?? '') === 'souvenir' ? 'selected' : '' ?>>ของที่ระลึก</option>
                                <option value="food" <?= ($editData['category'] ?? '') === 'food' ? 'selected' : '' ?>>อาหาร</option>
                                <option value="craft" <?= ($editData['category'] ?? '') === 'craft' ? 'selected' : '' ?>>งานหัตถกรรม</option>
                                <option value="fabric" <?= ($editData['category'] ?? '') === 'fabric' ? 'selected' : '' ?>>ผ้าทอ</option>
                                <option value="other" <?= ($editData['category'] ?? '') === 'other' ? 'selected' : '' ?>>อื่นๆ</option>
                            </select>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">ยกเลิก</button>
                        <button type="submit" class="btn btn-primary">บันทึก</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
    function previewMainImage(event) {
        const preview = document.getElementById('mainImagePreview');
        const file = event.target.files[0];
        
        if (file) {
            const reader = new FileReader();
            reader.onload = function(e) {
                preview.src = e.target.result;
                preview.style.display = 'block';
                
                const currentImage = document.getElementById('currentMainImage');
                if (currentImage) {
                    currentImage.style.display = 'none';
                }
            }
            reader.readAsDataURL(file);
        }
    }
    
    function previewGalleryImages(event) {
        const preview = document.getElementById('galleryPreview');
        preview.innerHTML = '';
        const files = event.target.files;
        
        for (let i = 0; i < files.length; i++) {
            const file = files[i];
            const reader = new FileReader();
            
            reader.onload = function(e) {
                const img = document.createElement('img');
                img.src = e.target.result;
                img.className = 'img-thumbnail';
                img.style.width = '100px';
                img.style.height = '100px';
                img.style.objectFit = 'cover';
                preview.appendChild(img);
            }
            
            reader.readAsDataURL(file);
        }
    }
    </script>
    <?php if ($editData): ?>
    <script>
        var myModal = new bootstrap.Modal(document.getElementById('productModal'));
        myModal.show();
    </script>
    <?php endif; ?>
</body>
</html>
