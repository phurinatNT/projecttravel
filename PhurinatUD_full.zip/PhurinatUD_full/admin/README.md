# ระบบแอดมิน PhurinatUD - คู่มือการใช้งาน

## ฟีเจอร์ระบบแอดมิน

### 1. จัดการประเภทสถานที่ (Place Categories)
- ✅ เพิ่มประเภทสถานที่ใหม่
- ✅ แก้ไขประเภทสถานที่
- ✅ ลบประเภทสถานที่
- ✅ ค้นหาประเภทสถานที่
- ประเภทเริ่มต้น: สถานที่ท่องเที่ยว, ที่พัก, สถานที่ทางศาสนา, สถานพยาบาล, สถานีตำรวจ

### 2. จัดการสถานที่ (Places)
- ✅ เพิ่มสถานที่ใหม่
- ✅ แก้ไขข้อมูลสถานที่
- ✅ ลบสถานที่
- ✅ ค้นหาสถานที่
- ✅ กรองตามประเภทสถานที่
- ข้อมูล: ชื่อ, คำอธิบาย, รูปภาพ, พิกัด (Lat/Long), ประเภท

### 3. จัดการสินค้าชุมชน (Products)
- ✅ เพิ่มสินค้าใหม่
- ✅ แก้ไขข้อมูลสินค้า
- ✅ ลบสินค้า
- ✅ ค้นหาสินค้า
- ข้อมูล: ชื่อ, คำอธิบาย, ราคา, รูปภาพ, หมวดหมู่

### 4. จัดการผู้ใช้ (Users)
- ✅ ดูรายการผู้ใช้ทั้งหมด
- ✅ เปลี่ยนบทบาท (User ↔ Admin)
- ✅ ลบผู้ใช้
- ✅ ค้นหาผู้ใช้

## การเข้าใช้งาน

### บัญชีแอดมินเริ่มต้น
- **Username:** admin
- **Password:** 123456

### วิธีเข้าสู่ระบบแอดมิน
1. เข้าสู่ระบบด้วยบัญชี admin
2. คลิกปุ่ม "Admin" สีแดงที่ navbar
3. หรือเข้า URL: `http://localhost/PhurinatUD_full/admin/index.php`

## โครงสร้างไฟล์

```
admin/
├── index.php          # Dashboard หน้าหลัก
├── categories.php     # จัดการประเภทสถานที่
├── places.php         # จัดการสถานที่
├── products.php       # จัดการสินค้า
└── users.php          # จัดการผู้ใช้
```

## ฐานข้อมูล

### ตาราง place_categories
```sql
- id (INT, AUTO_INCREMENT, PRIMARY KEY)
- name (VARCHAR(100), UNIQUE)
- description (TEXT)
- icon (VARCHAR(50))
- created_at (TIMESTAMP)
```

### ตาราง places
```sql
- id (INT, AUTO_INCREMENT, PRIMARY KEY)
- name (VARCHAR(255))
- slug (VARCHAR(255), UNIQUE)
- description (TEXT)
- image (VARCHAR(512))
- latitude (DECIMAL(10,7))
- longitude (DECIMAL(10,7))
- category (VARCHAR(100))
- created_at (TIMESTAMP)
```

### ตาราง products
```sql
- id (INT, AUTO_INCREMENT, PRIMARY KEY)
- name (VARCHAR(255))
- description (TEXT)
- price (DECIMAL(10,2))
- image (VARCHAR(512))
- category (VARCHAR(100))
- created_at (TIMESTAMP)
```

### ตาราง users
```sql
- id (INT, AUTO_INCREMENT, PRIMARY KEY)
- username (VARCHAR(100), UNIQUE)
- email (VARCHAR(255), UNIQUE)
- password (VARCHAR(255))
- role (ENUM: 'user', 'admin')
- created_at (TIMESTAMP)
```

## ฟีเจอร์เด่น

### Dashboard
- 📊 แสดงสถิติแบบ Real-time
- 📈 จำนวนประเภทสถานที่, สถานที่, สินค้า, ผู้ใช้
- 🔥 รายการข้อมูลล่าสุด
- 🎯 เมนูจัดการด่วน

### การค้นหาและกรอง
- 🔍 ค้นหาแบบ Real-time
- 🏷️ กรองตามประเภท (สำหรับสถานที่)
- ⚡ ผลลัพธ์ทันที

### UI/UX
- 🎨 สีสันสวยงาม Gradient
- 📱 Responsive Design
- 🖱️ Hover Effects
- ✨ Bootstrap 5.3.3
- 🎭 Bootstrap Icons

### ความปลอดภัย
- 🔐 ตรวจสอบสิทธิ์ admin ทุกหน้า
- 🛡️ ป้องกันการลบ/แก้ไขตัวเอง (users.php)
- 🔒 Session Management
- ✅ SQL Prepared Statements

## การใช้งานแต่ละหน้า

### 1. ประเภทสถานที่
- คลิก "เพิ่มประเภทใหม่" เพื่อเพิ่มประเภท
- กรอก: ไอคอน (emoji), ชื่อประเภท, คำอธิบาย
- ใช้ปุ่มแก้ไข/ลบในตาราง

### 2. สถานที่
- คลิก "เพิ่มสถานที่ใหม่"
- กรอกข้อมูลทั้งหมด (ชื่อ, ประเภท, คำอธิบาย, รูปภาพ, พิกัด)
- Slug จะถูกสร้างอัตโนมัติ
- ใช้ Search + Filter เพื่อค้นหา

### 3. สินค้า
- คลิก "เพิ่มสินค้าใหม่"
- กรอก: ชื่อ, ราคา, คำอธิบาย, รูปภาพ, หมวดหมู่
- แสดงผลแบบ Card Grid
- ดูราคาและรายละเอียดได้ทันที

### 4. ผู้ใช้
- ดูรายการผู้ใช้ทั้งหมด
- เปลี่ยนบทบาทด้วยปุ่ม ↻
- ลบผู้ใช้ (ยกเว้นตัวเอง)

## เทคโนโลยีที่ใช้

- **Frontend:** Bootstrap 5.3.3, Bootstrap Icons
- **Backend:** PHP 7.4+
- **Database:** MySQL
- **Font:** Athiti (Google Fonts)
- **Design:** Gradient Backgrounds, Card Components, Responsive Grid

## ข้อควรระวัง

⚠️ **สำคัญ:**
- ต้องล็อกอินด้วยบัญชี admin เท่านั้น
- ไม่สามารถลบหรือเปลี่ยน role ของตัวเองได้
- ตรวจสอบข้อมูลก่อนลบ (ไม่สามารถกู้คืนได้)
- URL รูปภาพควรเริ่มด้วย /PhurinatUD_full/assets/images/

## การ Backup

แนะนำให้ Backup ข้อมูลเป็นประจำ:
```sql
mysqldump -u root -p udonjourney > backup_$(date +%Y%m%d).sql
```

## ผู้พัฒนา

👨‍💻 **Phurinat (104)**  
📧 Email: admin@example.com  
🏫 Project: PhurinatUD Tourism System

---

## Change Log

### Version 1.0 (2025-10-30)
- ✅ สร้างระบบแอดมินครบทั้ง 4 โมดูล
- ✅ Dashboard แสดงสถิติ Real-time
- ✅ CRUD สมบูรณ์ทุกตาราง
- ✅ Search & Filter
- ✅ Responsive Design
- ✅ Security: Role-based Access Control

---

**พร้อมใช้งานแล้ว! 🎉**
