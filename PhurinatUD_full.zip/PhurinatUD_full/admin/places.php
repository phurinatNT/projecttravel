<?php
session_start();
require_once '../config/db.php';

// ตรวจสอบว่าเป็น admin หรือไม่
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header('Location: ../auth/login.php');
    exit;
}

// จัดการการลบ
if (isset($_GET['delete'])) {
    $id = $_GET['delete'];
    $stmt = $pdo->prepare("DELETE FROM places WHERE id = ?");
    $stmt->execute([$id]);
    header('Location: places.php?success=deleted');
    exit;
}

// จัดการการเพิ่ม/แก้ไข
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = $_POST['name'];
    $description = $_POST['description'];
    $image = $_POST['image'];
    $latitude = $_POST['latitude'];
    $longitude = $_POST['longitude'];
    $category = $_POST['category'];
    $slug = strtolower(str_replace(' ', '-', preg_replace('/[^A-Za-z0-9\s-]/', '', $name)));
    
    if (isset($_POST['id']) && !empty($_POST['id'])) {
        // แก้ไข
        $stmt = $pdo->prepare("UPDATE places SET name = ?, slug = ?, description = ?, image = ?, latitude = ?, longitude = ?, category = ? WHERE id = ?");
        $stmt->execute([$name, $slug, $description, $image, $latitude, $longitude, $category, $_POST['id']]);
        header('Location: places.php?success=updated');
    } else {
        // เพิ่มใหม่
        $stmt = $pdo->prepare("INSERT INTO places (name, slug, description, image, latitude, longitude, category) VALUES (?, ?, ?, ?, ?, ?, ?)");
        $stmt->execute([$name, $slug, $description, $image, $latitude, $longitude, $category]);
        header('Location: places.php?success=added');
    }
    exit;
}

// ดึงข้อมูลสำหรับแก้ไข
$editData = null;
if (isset($_GET['edit'])) {
    $stmt = $pdo->prepare("SELECT * FROM places WHERE id = ?");
    $stmt->execute([$_GET['edit']]);
    $editData = $stmt->fetch();
}

// ดึงประเภทสถานที่
$categories = $pdo->query("SELECT * FROM place_categories ORDER BY name")->fetchAll();

// ค้นหา
$search = $_GET['search'] ?? '';
$filterCategory = $_GET['category'] ?? '';
$query = "SELECT * FROM places WHERE 1=1";
$params = [];

if ($search) {
    $query .= " AND (name LIKE :search OR description LIKE :search)";
    $params['search'] = "%$search%";
}

if ($filterCategory) {
    $query .= " AND category = :category";
    $params['category'] = $filterCategory;
}

$query .= " ORDER BY created_at DESC";

$stmt = $pdo->prepare($query);
$stmt->execute($params);
$places = $stmt->fetchAll();
?>
<!DOCTYPE html>
<html lang="th">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>จัดการสถานที่ - Admin</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Athiti:wght@300;400;700&display=swap" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css" rel="stylesheet">
    <style>
        body { font-family: 'Athiti', sans-serif; background-color: #f8f9fa; }
        .sidebar {
            min-height: 100vh;
            background: linear-gradient(180deg, #ff6600 0%, #ff8533 100%);
            color: white;
            position: fixed;
            top: 0;
            left: 0;
            width: 250px;
            padding-top: 20px;
        }
        .sidebar .nav-link {
            color: rgba(255, 255, 255, 0.8);
            padding: 12px 20px;
            margin: 5px 10px;
            border-radius: 8px;
            transition: all 0.3s;
        }
        .sidebar .nav-link:hover,
        .sidebar .nav-link.active {
            background-color: rgba(255, 255, 255, 0.2);
            color: white;
        }
        .main-content {
            margin-left: 250px;
            padding: 30px;
        }
        .place-img {
            width: 60px;
            height: 60px;
            object-fit: cover;
            border-radius: 8px;
        }
    </style>
</head>
<body>
    <!-- Sidebar -->
    <div class="sidebar">
        <div class="text-center mb-4">
            <h3 class="fw-bold">Admin Panel</h3>
            <p class="small mb-0">PhurinatUD</p>
        </div>
        <nav class="nav flex-column">
            <a class="nav-link" href="index.php">
                <i class="bi bi-speedometer2 me-2"></i> Dashboard
            </a>
            <a class="nav-link" href="categories.php">
                <i class="bi bi-tags me-2"></i> ประเภทสถานที่
            </a>
            <a class="nav-link active" href="places.php">
                <i class="bi bi-geo-alt me-2"></i> จัดการสถานที่
            </a>
            <a class="nav-link" href="accommodations.php">
                <i class="bi bi-building me-2"></i> จัดการที่พัก
            </a>
            <a class="nav-link" href="products.php">
                <i class="bi bi-box-seam me-2"></i> จัดการสินค้า
            </a>
            <a class="nav-link" href="users.php">
                <i class="bi bi-people me-2"></i> จัดการผู้ใช้
            </a>
            <hr class="text-white">
            <a class="nav-link" href="../pages/index.php">
                <i class="bi bi-house me-2"></i> กลับหน้าหลัก
            </a>
            <a class="nav-link" href="../auth/logout.php">
                <i class="bi bi-box-arrow-right me-2"></i> ออกจากระบบ
            </a>
        </nav>
    </div>

    <!-- Main Content -->
    <div class="main-content">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <div>
                <h2 class="fw-bold mb-0">จัดการสถานที่</h2>
                <p class="text-muted">เพิ่ม ลบ แก้ไข ค้นหา ข้อมูลสถานที่ในจังหวัด</p>
            </div>
            <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#placeModal">
                <i class="bi bi-plus-circle me-2"></i>เพิ่มสถานที่ใหม่
            </button>
        </div>

        <!-- Success Message -->
        <?php if (isset($_GET['success'])): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <?php
            if ($_GET['success'] === 'added') echo 'เพิ่มสถานที่สำเร็จ!';
            elseif ($_GET['success'] === 'updated') echo 'แก้ไขสถานที่สำเร็จ!';
            elseif ($_GET['success'] === 'deleted') echo 'ลบสถานที่สำเร็จ!';
            ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
        <?php endif; ?>

        <!-- Search & Filter -->
        <div class="card border-0 shadow-sm mb-4">
            <div class="card-body">
                <form method="GET" class="row g-3">
                    <div class="col-md-5">
                        <input type="text" name="search" class="form-control" placeholder="ค้นหาสถานที่..." value="<?= htmlspecialchars($search) ?>">
                    </div>
                    <div class="col-md-5">
                        <select name="category" class="form-select">
                            <option value="">ทุกประเภท</option>
                            <?php foreach ($categories as $cat): ?>
                            <option value="<?= htmlspecialchars($cat['name']) ?>" <?= $filterCategory === $cat['name'] ? 'selected' : '' ?>>
                                <?= htmlspecialchars($cat['icon'] . ' ' . $cat['name']) ?>
                            </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="col-md-2">
                        <button type="submit" class="btn btn-primary w-100">
                            <i class="bi bi-search me-2"></i>ค้นหา
                        </button>
                    </div>
                </form>
            </div>
        </div>

        <!-- Places Table -->
        <div class="card border-0 shadow-sm">
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-hover">
                        <thead class="table-light">
                            <tr>
                                <th width="50">#</th>
                                <th width="80">รูปภาพ</th>
                                <th>ชื่อสถานที่</th>
                                <th>ประเภท</th>
                                <th>พิกัด</th>
                                <th>วันที่สร้าง</th>
                                <th width="150" class="text-center">จัดการ</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (count($places) > 0): ?>
                                <?php foreach ($places as $index => $place): ?>
                                <tr>
                                    <td><?= $index + 1 ?></td>
                                    <td>
                                        <?php if ($place['image']): ?>
                                        <img src="<?= htmlspecialchars($place['image']) ?>" class="place-img" alt="">
                                        <?php else: ?>
                                        <div class="place-img bg-secondary d-flex align-items-center justify-content-center text-white">
                                            <i class="bi bi-image"></i>
                                        </div>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <strong><?= htmlspecialchars($place['name']) ?></strong>
                                        <br><small class="text-muted"><?= htmlspecialchars(substr($place['description'], 0, 50)) ?>...</small>
                                    </td>
                                    <td><?= htmlspecialchars($place['category']) ?></td>
                                    <td class="small">
                                        <?= $place['latitude'] ?>, <?= $place['longitude'] ?>
                                    </td>
                                    <td><?= date('d/m/Y', strtotime($place['created_at'])) ?></td>
                                    <td class="text-center">
                                        <a href="?edit=<?= $place['id'] ?>" class="btn btn-sm btn-warning">
                                            <i class="bi bi-pencil"></i>
                                        </a>
                                        <a href="?delete=<?= $place['id'] ?>" class="btn btn-sm btn-danger" onclick="return confirm('ยืนยันการลบ?')">
                                            <i class="bi bi-trash"></i>
                                        </a>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            <?php else: ?>
                                <tr>
                                    <td colspan="7" class="text-center text-muted py-4">ไม่พบข้อมูล</td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <!-- Modal -->
    <div class="modal fade" id="placeModal" tabindex="-1">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <form method="POST">
                    <div class="modal-header">
                        <h5 class="modal-title"><?= $editData ? 'แก้ไขสถานที่' : 'เพิ่มสถานที่ใหม่' ?></h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                    </div>
                    <div class="modal-body">
                        <input type="hidden" name="id" value="<?= $editData['id'] ?? '' ?>">
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label class="form-label">ชื่อสถานที่</label>
                                <input type="text" name="name" class="form-control" value="<?= htmlspecialchars($editData['name'] ?? '') ?>" required>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label class="form-label">ประเภท</label>
                                <select name="category" class="form-select" required>
                                    <option value="">เลือกประเภท</option>
                                    <?php foreach ($categories as $cat): ?>
                                    <option value="<?= htmlspecialchars($cat['name']) ?>" <?= ($editData['category'] ?? '') === $cat['name'] ? 'selected' : '' ?>>
                                        <?= htmlspecialchars($cat['icon'] . ' ' . $cat['name']) ?>
                                    </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">คำอธิบาย</label>
                            <textarea name="description" class="form-control" rows="3" required><?= htmlspecialchars($editData['description'] ?? '') ?></textarea>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">URL รูปภาพ</label>
                            <input type="text" name="image" class="form-control" value="<?= htmlspecialchars($editData['image'] ?? '') ?>" placeholder="/PhurinatUD_full/assets/images/example.jpg">
                        </div>
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label class="form-label">ละติจูด (Latitude)</label>
                                <input type="number" step="0.0000001" name="latitude" class="form-control" value="<?= htmlspecialchars($editData['latitude'] ?? '') ?>" placeholder="17.4055000">
                            </div>
                            <div class="col-md-6 mb-3">
                                <label class="form-label">ลองจิจูด (Longitude)</label>
                                <input type="number" step="0.0000001" name="longitude" class="form-control" value="<?= htmlspecialchars($editData['longitude'] ?? '') ?>" placeholder="102.7875000">
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">ยกเลิก</button>
                        <button type="submit" class="btn btn-primary">บันทึก</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <?php if ($editData): ?>
    <script>
        var myModal = new bootstrap.Modal(document.getElementById('placeModal'));
        myModal.show();
    </script>
    <?php endif; ?>
</body>
</html>
