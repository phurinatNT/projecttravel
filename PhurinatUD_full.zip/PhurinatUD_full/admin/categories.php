<?php
session_start();
require_once '../config/db.php';

// ตรวจสอบว่าเป็น admin หรือไม่
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header('Location: ../auth/login.php');
    exit;
}

// จัดการการลบ
if (isset($_GET['delete'])) {
    $id = $_GET['delete'];
    $stmt = $pdo->prepare("DELETE FROM place_categories WHERE id = ?");
    $stmt->execute([$id]);
    header('Location: categories.php?success=deleted');
    exit;
}

// จัดการการเพิ่ม/แก้ไข
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = $_POST['name'];
    $description = $_POST['description'];
    $icon = $_POST['icon'];
    
    if (isset($_POST['id']) && !empty($_POST['id'])) {
        // แก้ไข
        $stmt = $pdo->prepare("UPDATE place_categories SET name = ?, description = ?, icon = ? WHERE id = ?");
        $stmt->execute([$name, $description, $icon, $_POST['id']]);
        header('Location: categories.php?success=updated');
    } else {
        // เพิ่มใหม่
        $stmt = $pdo->prepare("INSERT INTO place_categories (name, description, icon) VALUES (?, ?, ?)");
        $stmt->execute([$name, $description, $icon]);
        header('Location: categories.php?success=added');
    }
    exit;
}

// ดึงข้อมูลสำหรับแก้ไข
$editData = null;
if (isset($_GET['edit'])) {
    $stmt = $pdo->prepare("SELECT * FROM place_categories WHERE id = ?");
    $stmt->execute([$_GET['edit']]);
    $editData = $stmt->fetch();
}

// ค้นหา
$search = $_GET['search'] ?? '';
$query = "SELECT * FROM place_categories";
if ($search) {
    $query .= " WHERE name LIKE :search OR description LIKE :search";
}
$query .= " ORDER BY created_at DESC";

$stmt = $pdo->prepare($query);
if ($search) {
    $stmt->execute(['search' => "%$search%"]);
} else {
    $stmt->execute();
}
$categories = $stmt->fetchAll();
?>
<!DOCTYPE html>
<html lang="th">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>จัดการประเภทสถานที่ - Admin</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Athiti:wght@300;400;700&display=swap" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css" rel="stylesheet">
    <style>
        body { font-family: 'Athiti', sans-serif; background-color: #f8f9fa; }
        .sidebar {
            min-height: 100vh;
            background: linear-gradient(180deg, #ff6600 0%, #ff8533 100%);
            color: white;
            position: fixed;
            top: 0;
            left: 0;
            width: 250px;
            padding-top: 20px;
        }
        .sidebar .nav-link {
            color: rgba(255, 255, 255, 0.8);
            padding: 12px 20px;
            margin: 5px 10px;
            border-radius: 8px;
            transition: all 0.3s;
        }
        .sidebar .nav-link:hover,
        .sidebar .nav-link.active {
            background-color: rgba(255, 255, 255, 0.2);
            color: white;
        }
        .main-content {
            margin-left: 250px;
            padding: 30px;
        }
    </style>
</head>
<body>
    <!-- Sidebar -->
    <div class="sidebar">
        <div class="text-center mb-4">
            <h3 class="fw-bold">Admin Panel</h3>
            <p class="small mb-0">PhurinatUD</p>
        </div>
        <nav class="nav flex-column">
            <a class="nav-link" href="index.php">
                <i class="bi bi-speedometer2 me-2"></i> Dashboard
            </a>
            <a class="nav-link active" href="categories.php">
                <i class="bi bi-tags me-2"></i> ประเภทสถานที่
            </a>
            <a class="nav-link" href="places.php">
                <i class="bi bi-geo-alt me-2"></i> จัดการสถานที่
            </a>
            <a class="nav-link" href="accommodations.php">
                <i class="bi bi-building me-2"></i> จัดการที่พัก
            </a>
            <a class="nav-link" href="products.php">
                <i class="bi bi-box-seam me-2"></i> จัดการสินค้า
            </a>
            <a class="nav-link" href="users.php">
                <i class="bi bi-people me-2"></i> จัดการผู้ใช้
            </a>
            <hr class="text-white">
            <a class="nav-link" href="../pages/index.php">
                <i class="bi bi-house me-2"></i> กลับหน้าหลัก
            </a>
            <a class="nav-link" href="../auth/logout.php">
                <i class="bi bi-box-arrow-right me-2"></i> ออกจากระบบ
            </a>
        </nav>
    </div>

    <!-- Main Content -->
    <div class="main-content">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <div>
                <h2 class="fw-bold mb-0">จัดการประเภทสถานที่</h2>
                <p class="text-muted">เพิ่ม ลบ แก้ไข ค้นหา ประเภทสถานที่</p>
            </div>
            <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#categoryModal">
                <i class="bi bi-plus-circle me-2"></i>เพิ่มประเภทใหม่
            </button>
        </div>

        <!-- Success Message -->
        <?php if (isset($_GET['success'])): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <?php
            if ($_GET['success'] === 'added') echo 'เพิ่มประเภทสถานที่สำเร็จ!';
            elseif ($_GET['success'] === 'updated') echo 'แก้ไขประเภทสถานที่สำเร็จ!';
            elseif ($_GET['success'] === 'deleted') echo 'ลบประเภทสถานที่สำเร็จ!';
            ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
        <?php endif; ?>

        <!-- Search -->
        <div class="card border-0 shadow-sm mb-4">
            <div class="card-body">
                <form method="GET" class="row g-3">
                    <div class="col-md-10">
                        <input type="text" name="search" class="form-control" placeholder="ค้นหาประเภทสถานที่..." value="<?= htmlspecialchars($search) ?>">
                    </div>
                    <div class="col-md-2">
                        <button type="submit" class="btn btn-primary w-100">
                            <i class="bi bi-search me-2"></i>ค้นหา
                        </button>
                    </div>
                </form>
            </div>
        </div>

        <!-- Categories Table -->
        <div class="card border-0 shadow-sm">
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-hover">
                        <thead class="table-light">
                            <tr>
                                <th width="50">#</th>
                                <th width="80">ไอคอน</th>
                                <th>ชื่อประเภท</th>
                                <th>คำอธิบาย</th>
                                <th>วันที่สร้าง</th>
                                <th width="150" class="text-center">จัดการ</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (count($categories) > 0): ?>
                                <?php foreach ($categories as $index => $cat): ?>
                                <tr>
                                    <td><?= $index + 1 ?></td>
                                    <td class="fs-2"><?= htmlspecialchars($cat['icon']) ?></td>
                                    <td class="fw-bold"><?= htmlspecialchars($cat['name']) ?></td>
                                    <td><?= htmlspecialchars($cat['description']) ?></td>
                                    <td><?= date('d/m/Y H:i', strtotime($cat['created_at'])) ?></td>
                                    <td class="text-center">
                                        <a href="?edit=<?= $cat['id'] ?>" class="btn btn-sm btn-warning" data-bs-toggle="modal" data-bs-target="#categoryModal">
                                            <i class="bi bi-pencil"></i>
                                        </a>
                                        <a href="?delete=<?= $cat['id'] ?>" class="btn btn-sm btn-danger" onclick="return confirm('ยืนยันการลบ?')">
                                            <i class="bi bi-trash"></i>
                                        </a>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            <?php else: ?>
                                <tr>
                                    <td colspan="6" class="text-center text-muted py-4">ไม่พบข้อมูล</td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <!-- Modal -->
    <div class="modal fade" id="categoryModal" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <form method="POST">
                    <div class="modal-header">
                        <h5 class="modal-title"><?= $editData ? 'แก้ไขประเภทสถานที่' : 'เพิ่มประเภทสถานที่ใหม่' ?></h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                    </div>
                    <div class="modal-body">
                        <input type="hidden" name="id" value="<?= $editData['id'] ?? '' ?>">
                        <div class="mb-3">
                            <label class="form-label">ไอคอน (Emoji)</label>
                            <input type="text" name="icon" class="form-control" value="<?= htmlspecialchars($editData['icon'] ?? '') ?>" placeholder="🏞️" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">ชื่อประเภท</label>
                            <input type="text" name="name" class="form-control" value="<?= htmlspecialchars($editData['name'] ?? '') ?>" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">คำอธิบาย</label>
                            <textarea name="description" class="form-control" rows="3"><?= htmlspecialchars($editData['description'] ?? '') ?></textarea>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">ยกเลิก</button>
                        <button type="submit" class="btn btn-primary">บันทึก</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <?php if ($editData): ?>
    <script>
        var myModal = new bootstrap.Modal(document.getElementById('categoryModal'));
        myModal.show();
    </script>
    <?php endif; ?>
</body>
</html>
