<?php
session_start();
require_once '../config/db.php';

// ตรวจสอบว่าเป็น admin หรือไม่
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header('Location: ../auth/login.php');
    exit;
}

// จัดการการลบ
if (isset($_GET['delete'])) {
    $id = $_GET['delete'];
    // ป้องกันการลบ admin ตัวเอง
    if ($id != $_SESSION['user_id']) {
        $stmt = $pdo->prepare("DELETE FROM users WHERE id = ?");
        $stmt->execute([$id]);
        header('Location: users.php?success=deleted');
    } else {
        header('Location: users.php?error=cannot_delete_self');
    }
    exit;
}

// จัดการการเปลี่ยน role
if (isset($_GET['toggle_role'])) {
    $id = $_GET['toggle_role'];
    // ป้องกันการเปลี่ยน role ตัวเอง
    if ($id != $_SESSION['user_id']) {
        $stmt = $pdo->prepare("UPDATE users SET role = IF(role = 'admin', 'user', 'admin') WHERE id = ?");
        $stmt->execute([$id]);
        header('Location: users.php?success=role_changed');
    } else {
        header('Location: users.php?error=cannot_change_self');
    }
    exit;
}

// ค้นหา
$search = $_GET['search'] ?? '';
$query = "SELECT * FROM users";
if ($search) {
    $query .= " WHERE username LIKE :search OR email LIKE :search";
}
$query .= " ORDER BY created_at DESC";

$stmt = $pdo->prepare($query);
if ($search) {
    $stmt->execute(['search' => "%$search%"]);
} else {
    $stmt->execute();
}
$users = $stmt->fetchAll();
?>
<!DOCTYPE html>
<html lang="th">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>จัดการผู้ใช้ - Admin</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Athiti:wght@300;400;700&display=swap" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css" rel="stylesheet">
    <style>
        body { font-family: 'Athiti', sans-serif; background-color: #f8f9fa; }
        .sidebar {
            min-height: 100vh;
            background: linear-gradient(180deg, #ff6600 0%, #ff8533 100%);
            color: white;
            position: fixed;
            top: 0;
            left: 0;
            width: 250px;
            padding-top: 20px;
        }
        .sidebar .nav-link {
            color: rgba(255, 255, 255, 0.8);
            padding: 12px 20px;
            margin: 5px 10px;
            border-radius: 8px;
            transition: all 0.3s;
        }
        .sidebar .nav-link:hover,
        .sidebar .nav-link.active {
            background-color: rgba(255, 255, 255, 0.2);
            color: white;
        }
        .main-content {
            margin-left: 250px;
            padding: 30px;
        }
    </style>
</head>
<body>
    <!-- Sidebar -->
    <div class="sidebar">
        <div class="text-center mb-4">
            <h3 class="fw-bold">Admin Panel</h3>
            <p class="small mb-0">PhurinatUD</p>
        </div>
        <nav class="nav flex-column">
            <a class="nav-link" href="index.php">
                <i class="bi bi-speedometer2 me-2"></i> Dashboard
            </a>
            <a class="nav-link" href="categories.php">
                <i class="bi bi-tags me-2"></i> ประเภทสถานที่
            </a>
            <a class="nav-link" href="places.php">
                <i class="bi bi-geo-alt me-2"></i> จัดการสถานที่
            </a>
            <a class="nav-link" href="accommodations.php">
                <i class="bi bi-building me-2"></i> จัดการที่พัก
            </a>
            <a class="nav-link" href="products.php">
                <i class="bi bi-box-seam me-2"></i> จัดการสินค้า
            </a>
            <a class="nav-link active" href="users.php">
                <i class="bi bi-people me-2"></i> จัดการผู้ใช้
            </a>
            <hr class="text-white">
            <a class="nav-link" href="../pages/index.php">
                <i class="bi bi-house me-2"></i> กลับหน้าหลัก
            </a>
            <a class="nav-link" href="../auth/logout.php">
                <i class="bi bi-box-arrow-right me-2"></i> ออกจากระบบ
            </a>
        </nav>
    </div>

    <!-- Main Content -->
    <div class="main-content">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <div>
                <h2 class="fw-bold mb-0">จัดการผู้ใช้</h2>
                <p class="text-muted">ดูรายการผู้ใช้ทั้งหมด</p>
            </div>
        </div>

        <!-- Messages -->
        <?php if (isset($_GET['success'])): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <?php
            if ($_GET['success'] === 'deleted') echo 'ลบผู้ใช้สำเร็จ!';
            elseif ($_GET['success'] === 'role_changed') echo 'เปลี่ยนบทบาทสำเร็จ!';
            ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
        <?php endif; ?>

        <?php if (isset($_GET['error'])): ?>
        <div class="alert alert-danger alert-dismissible fade show" role="alert">
            <?php
            if ($_GET['error'] === 'cannot_delete_self') echo 'ไม่สามารถลบบัญชีของตัวเองได้!';
            elseif ($_GET['error'] === 'cannot_change_self') echo 'ไม่สามารถเปลี่ยนบทบาทของตัวเองได้!';
            ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
        <?php endif; ?>

        <!-- Search -->
        <div class="card border-0 shadow-sm mb-4">
            <div class="card-body">
                <form method="GET" class="row g-3">
                    <div class="col-md-10">
                        <input type="text" name="search" class="form-control" placeholder="ค้นหาผู้ใช้..." value="<?= htmlspecialchars($search) ?>">
                    </div>
                    <div class="col-md-2">
                        <button type="submit" class="btn btn-primary w-100">
                            <i class="bi bi-search me-2"></i>ค้นหา
                        </button>
                    </div>
                </form>
            </div>
        </div>

        <!-- Users Table -->
        <div class="card border-0 shadow-sm">
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-hover">
                        <thead class="table-light">
                            <tr>
                                <th width="50">#</th>
                                <th>ชื่อผู้ใช้</th>
                                <th>อีเมล</th>
                                <th>บทบาท</th>
                                <th>วันที่สมัคร</th>
                                <th width="200" class="text-center">จัดการ</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (count($users) > 0): ?>
                                <?php foreach ($users as $index => $user): ?>
                                <tr>
                                    <td><?= $index + 1 ?></td>
                                    <td>
                                        <strong><?= htmlspecialchars($user['username']) ?></strong>
                                        <?php if ($user['id'] == $_SESSION['user_id']): ?>
                                        <span class="badge bg-info ms-2">คุณ</span>
                                        <?php endif; ?>
                                    </td>
                                    <td><?= htmlspecialchars($user['email']) ?></td>
                                    <td>
                                        <?php if ($user['role'] === 'admin'): ?>
                                        <span class="badge bg-danger">Admin</span>
                                        <?php else: ?>
                                        <span class="badge bg-secondary">User</span>
                                        <?php endif; ?>
                                    </td>
                                    <td><?= date('d/m/Y H:i', strtotime($user['created_at'])) ?></td>
                                    <td class="text-center">
                                        <?php if ($user['id'] != $_SESSION['user_id']): ?>
                                        <a href="?toggle_role=<?= $user['id'] ?>" class="btn btn-sm btn-warning" 
                                           onclick="return confirm('ยืนยันการเปลี่ยนบทบาท?')" 
                                           title="เปลี่ยนบทบาท">
                                            <i class="bi bi-arrow-repeat"></i>
                                        </a>
                                        <a href="?delete=<?= $user['id'] ?>" class="btn btn-sm btn-danger" 
                                           onclick="return confirm('ยืนยันการลบ?')"
                                           title="ลบผู้ใช้">
                                            <i class="bi bi-trash"></i>
                                        </a>
                                        <?php else: ?>
                                        <span class="text-muted small">ไม่สามารถแก้ไขได้</span>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            <?php else: ?>
                                <tr>
                                    <td colspan="6" class="text-center text-muted py-4">ไม่พบข้อมูล</td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
