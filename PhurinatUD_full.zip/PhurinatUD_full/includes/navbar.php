<?php 
if(session_status()===PHP_SESSION_NONE) session_start(); 
require_once __DIR__ . '/../config/config.php';
?>
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css" rel="stylesheet">
<style>
  .navbar-custom {
    padding: 1rem 0;
    font-size: 1.15rem;
    background: rgba(255, 255, 255, 0.95) !important;
    backdrop-filter: blur(10px);
    -webkit-backdrop-filter: blur(10px);
  }
  .navbar-brand-custom {
    font-size: 2.3rem !important;
    font-weight: 700;
  }
  .nav-link-custom {
    font-size: 1.25rem;
    font-weight: 500;
    padding: 0.5rem 1rem !important;
  }
  .btn-custom {
    font-size: 1.05rem;
    padding: 0.5rem 1.2rem;
  }
</style>
<nav class="navbar navbar-expand-lg navbar-light shadow-sm fixed-top navbar-custom">
  <div class="container">
    <a href="<?= BASE_PATH ?>/pages/index.php" class="navbar-brand fw-bold navbar-brand-custom" style="color: #ff6600;">PhurinatUD</a>
    
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
      <span class="navbar-toggler-icon"></span>
    </button>
    
    <div class="collapse navbar-collapse" id="navbarNav">
      <ul class="navbar-nav mx-auto">
        <li class="nav-item">
          <a href="<?= BASE_PATH ?>/pages/index.php" class="nav-link nav-link-custom">หน้าแรก</a>
        </li>
        <li class="nav-item">
          <a href="<?= BASE_PATH ?>/pages/attractions.php" class="nav-link nav-link-custom">สถานที่ท่องเที่ยว</a>
        </li>
        <li class="nav-item">
          <a href="<?= BASE_PATH ?>/pages/accommodations.php" class="nav-link nav-link-custom">ที่พัก</a>
        </li>
        <li class="nav-item">
          <a href="<?= BASE_PATH ?>/pages/services.php" class="nav-link nav-link-custom">สถานที่บริการ</a>
        </li>
        <li class="nav-item">
          <a href="<?= BASE_PATH ?>/pages/products.php" class="nav-link nav-link-custom">สินค้าชุมชน</a>
        </li>
      </ul>
      
      <div class="d-flex align-items-center">
        <?php if(isset($_SESSION['user_id'])): ?>
          <div class="me-3 d-flex align-items-center" style="background: linear-gradient(135deg, #ff6600 0%, #ff8533 100%); padding: 8px 16px; border-radius: 25px;">
            <i class="bi bi-person-circle text-white me-2" style="font-size: 1.3rem;"></i>
            <span class="text-white" style="font-size: 1rem; font-weight: 500;"><?=htmlspecialchars($_SESSION['username'])?></span>
          </div>
          <?php if($_SESSION['role'] === 'admin'): ?>
          <a href="<?= BASE_PATH ?>/admin/index.php" class="btn btn-sm btn-custom me-2" style="background-color: #dc3545; color: white;">
            <i class="bi bi-speedometer2"></i> Admin
          </a>
          <?php endif; ?>
          <a href="<?= BASE_PATH ?>/auth/change_password.php" class="btn btn-warning btn-sm btn-custom me-2" title="เปลี่ยนรหัสผ่าน">
            <i class="bi bi-key-fill"></i>
          </a>
          <a href="<?= BASE_PATH ?>/auth/logout.php" class="btn btn-outline-danger btn-sm btn-custom">
            <i class="bi bi-box-arrow-right"></i> ออกจากระบบ
          </a>
        <?php else: ?>
          <a href="<?= BASE_PATH ?>/auth/login.php" class="btn btn-outline-primary btn-sm me-2 btn-custom">เข้าสู่ระบบ</a>
          <a href="<?= BASE_PATH ?>/auth/register.php" class="btn btn-sm btn-custom" style="background-color: #ff6600; color: white;">สมัครสมาชิก</a>
        <?php endif; ?>
      </div>
    </div>
  </div>
</nav>
<div style="height: 100px;"></div>