<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
  <div class="container-fluid">
    <a class="navbar-brand" href="index.php">PhurinatUD Admin</a>
    <div class="collapse navbar-collapse">
      <ul class="navbar-nav ms-auto">
        <li class="nav-item"><a href="manage_categories.php" class="nav-link">ประเภทสถานที่</a></li>
        <li class="nav-item"><a href="manage_places.php" class="nav-link">สถานที่</a></li>
        <li class="nav-item"><a href="manage_products.php" class="nav-link">สินค้าชุมชน</a></li>
        <li class="nav-item"><a href="../auth/logout.php" class="nav-link text-danger">ออกจากระบบ</a></li>
      </ul>
    </div>
  </div>
</nav>
