<?php
session_start();
require_once '../config/db.php';

$username = trim($_POST['username'] ?? '');
$password = trim($_POST['password'] ?? '');

if (!$username || !$password) {
  $_SESSION['error'] = 'กรุณากรอกชื่อผู้ใช้และรหัสผ่าน';
  header('Location: login.php');
  exit;
}

$stmt = $mysqli->prepare('SELECT id, username, password, role FROM users WHERE username = ? LIMIT 1');
$stmt->bind_param('s', $username);
$stmt->execute();
$res = $stmt->get_result();

if ($row = $res->fetch_assoc()) {
  if (password_verify($password, $row['password']) || $password === $row['password']) {
    $_SESSION['user'] = [
      'id' => $row['id'],
      'username' => $row['username'],
      'role' => $row['role']
    ];
    if ($row['role'] === 'admin') {
      header('Location: ../admin/index.php');
    } else {
      header('Location: ../pages/index.php');
    }
    exit;
  } else {
    $_SESSION['error'] = 'รหัสผ่านไม่ถูกต้อง';
  }
} else {
  $_SESSION['error'] = 'ไม่พบบัญชีผู้ใช้นี้ กรุณาสมัครสมาชิกก่อน';
}

header('Location: login.php');
exit;
?>
