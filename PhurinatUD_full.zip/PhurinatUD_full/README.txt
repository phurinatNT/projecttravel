PhurinatUD full package. Put this folder in XAMPP htdocs (e.g., C:\xampp\htdocs) and open http://localhost/PhurinatUD_full/pages/index.php
Configure config/db.php for your MySQL credentials and import udonjourney.sql
