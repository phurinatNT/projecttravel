-- เพิ่มฟิลด์ product_url สำหรับลิงก์ขายสินค้า
USE udonjourney;

-- ตรวจสอบว่ามีคอลัมน์อยู่แล้วหรือไม่
SET @dbname = 'udonjourney';
SET @tablename = 'products';
SET @columnname = 'product_url';
SET @preparedStatement = (SELECT IF(
  (
    SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS
    WHERE
      (table_name = @tablename)
      AND (table_schema = @dbname)
      AND (column_name = @columnname)
  ) > 0,
  "SELECT 1",
  CONCAT("ALTER TABLE ", @tablename, " ADD COLUMN ", @columnname, " VARCHAR(512) AFTER image")
));
PREPARE alterIfNotExists FROM @preparedStatement;
EXECUTE alterIfNotExists;
DEALLOCATE PREPARE alterIfNotExists;

-- ตัวอย่างการอัพเดทข้อมูลเดิม (ถ้าต้องการ)
-- UPDATE products SET product_url = 'https://example.com/product/1' WHERE id = 1;
-- UPDATE products SET product_url = 'https://shopee.co.th/product/123' WHERE id = 2;
-- UPDATE products SET product_url = 'https://www.lazada.co.th/product/456' WHERE id = 3;
