<?php
session_start();
require_once '../config/config.php';
require_once '../config/db.php';

// ตรวจสอบการเข้าสู่ระบบ
if (!isset($_SESSION['user_id'])) {
    $_SESSION['error'] = 'กรุณาเข้าสู่ระบบก่อน';
    header('Location: ' . BASE_PATH . '/auth/login.php');
    exit();
}

$user_id = $_SESSION['user_id'];
$message = '';
$error = '';

// ประมวลผลการเปลี่ยนรหัสผ่าน
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $current_password = $_POST['current_password'] ?? '';
    $new_password = $_POST['new_password'] ?? '';
    $confirm_password = $_POST['confirm_password'] ?? '';

    // ตรวจสอบข้อมูล
    if (empty($current_password) || empty($new_password) || empty($confirm_password)) {
        $error = 'กรุณากรอกข้อมูลให้ครบทุกช่อง';
    } elseif ($new_password !== $confirm_password) {
        $error = 'รหัสผ่านใหม่และยืนยันรหัสผ่านไม่ตรงกัน';
    } elseif (strlen($new_password) < 6) {
        $error = 'รหัสผ่านใหม่ต้องมีความยาวอย่างน้อย 6 ตัวอักษร';
    } else {
        // ดึงรหัสผ่านปัจจุบันจากฐานข้อมูล
        $stmt = $pdo->prepare("SELECT password FROM users WHERE id = ?");
        $stmt->execute([$user_id]);
        $user = $stmt->fetch();

        if ($user) {
            // ตรวจสอบรหัสผ่านปัจจุบัน
            if (password_verify($current_password, $user['password']) || $current_password === $user['password']) {
                // เข้ารหัสรหัสผ่านใหม่
                $hashed_password = password_hash($new_password, PASSWORD_DEFAULT);
                
                // อัปเดตรหัสผ่าน
                $update_stmt = $pdo->prepare("UPDATE users SET password = ? WHERE id = ?");
                if ($update_stmt->execute([$hashed_password, $user_id])) {
                    $_SESSION['success'] = 'เปลี่ยนรหัสผ่านเรียบร้อยแล้ว';
                    header('Location: change_password.php');
                    exit();
                } else {
                    $error = 'เกิดข้อผิดพลาดในการเปลี่ยนรหัสผ่าน';
                }
            } else {
                $error = 'รหัสผ่านปัจจุบันไม่ถูกต้อง';
            }
        }
    }
}

// แสดงข้อความสำเร็จ
if (isset($_SESSION['success'])) {
    $message = $_SESSION['success'];
    unset($_SESSION['success']);
}
?>
<!DOCTYPE html>
<html lang="th">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>เปลี่ยนรหัสผ่าน - PhurinatUD</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Athiti:wght@300;400;700&display=swap" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css" rel="stylesheet">
    <link href="../assets/css/style.css" rel="stylesheet">
    <style>
        body {
            font-family: 'Athiti', sans-serif;
            background: linear-gradient(135deg, #fff5eb 0%, #ffe4cc 100%);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        .change-password-card {
            background: white;
            border-radius: 20px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
            padding: 40px;
            max-width: 500px;
            width: 100%;
        }
        .btn-change {
            background: linear-gradient(135deg, #ff6600 0%, #ff8533 100%);
            border: none;
            color: white;
            padding: 12px;
            border-radius: 10px;
            font-weight: 600;
        }
        .btn-change:hover {
            background: linear-gradient(135deg, #ff8533 0%, #ff6600 100%);
            color: white;
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(255, 102, 0, 0.3);
        }
        .form-control:focus {
            border-color: #ff6600;
            box-shadow: 0 0 0 0.2rem rgba(255, 102, 0, 0.25);
        }
    </style>
</head>
<body>
<?php include('../includes/navbar.php'); ?>

<div class="change-password-card">
    <div class="text-center mb-4">
        <i class="bi bi-shield-lock" style="font-size: 3rem; color: #ff6600;"></i>
        <h2 class="fw-bold mt-3" style="color: #ff6600;">เปลี่ยนรหัสผ่าน</h2>
        <p class="text-muted">กรอกข้อมูลด้านล่างเพื่อเปลี่ยนรหัสผ่านของคุณ</p>
    </div>

    <?php if ($message): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <i class="bi bi-check-circle-fill me-2"></i><?= htmlspecialchars($message) ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>

    <?php if ($error): ?>
        <div class="alert alert-danger alert-dismissible fade show" role="alert">
            <i class="bi bi-exclamation-triangle-fill me-2"></i><?= htmlspecialchars($error) ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>

    <form method="POST" action="">
        <div class="mb-3">
            <label for="current_password" class="form-label">
                <i class="bi bi-key-fill text-muted"></i> รหัสผ่านปัจจุบัน
            </label>
            <input type="password" class="form-control" id="current_password" name="current_password" required>
        </div>

        <div class="mb-3">
            <label for="new_password" class="form-label">
                <i class="bi bi-shield-lock-fill text-muted"></i> รหัสผ่านใหม่
            </label>
            <input type="password" class="form-control" id="new_password" name="new_password" required minlength="6">
            <small class="text-muted">ต้องมีความยาวอย่างน้อย 6 ตัวอักษร</small>
        </div>

        <div class="mb-4">
            <label for="confirm_password" class="form-label">
                <i class="bi bi-shield-check-fill text-muted"></i> ยืนยันรหัสผ่านใหม่
            </label>
            <input type="password" class="form-control" id="confirm_password" name="confirm_password" required minlength="6">
        </div>

        <button type="submit" class="btn btn-change w-100 mb-3">
            <i class="bi bi-check-circle-fill"></i> เปลี่ยนรหัสผ่าน
        </button>

        <div class="text-center">
            <?php if ($_SESSION['role'] === 'admin'): ?>
                <a href="<?= BASE_PATH ?>/admin/index.php" class="text-decoration-none text-muted">
                    <i class="bi bi-arrow-left"></i> กลับหน้าแอดมิน
                </a>
            <?php else: ?>
                <a href="<?= BASE_PATH ?>/pages/index.php" class="text-decoration-none text-muted">
                    <i class="bi bi-arrow-left"></i> กลับหน้าหลัก
                </a>
            <?php endif; ?>
        </div>
    </form>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script>
// ตรวจสอบรหัสผ่านตรงกันหรือไม่
document.querySelector('form').addEventListener('submit', function(e) {
    const newPassword = document.getElementById('new_password').value;
    const confirmPassword = document.getElementById('confirm_password').value;
    
    if (newPassword !== confirmPassword) {
        e.preventDefault();
        alert('รหัสผ่านใหม่และยืนยันรหัสผ่านไม่ตรงกัน');
    }
});
</script>
</body>
</html>
