<?php 
// 1. เรียกใช้ 'ผู้รักษาประตู' ของแอดมิน
// *** นี่คือบรรทัดที่สำคัญที่สุด ***
// ถ้าไม่ใช่แอดมิน จะโดนเตะออกไปตั้งแต่บรรทัดนี้
include('../auth/auth_admin.php'); 

// 2. เรียกใช้ navbar
// (ซึ่ง navbar.php จะแสดง "สวัสดี, [Admin]" และปุ่ม "จัดการข้อมูล" อยู่แล้ว)
include('../includes/navbar.php'); 
?>
<!DOCTYPE html>
<html lang="th">
<head>
    <meta charset="UTF-8">
    <title>จัดการสถานที่ (สำหรับแอดมิน)</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Athiti:wght@300;400;700&display=swap" rel="stylesheet">
    <style> body { font-family: 'Athiti', sans-serif; } </style>
</head>
<body class="bg-gray-100">
    <div class="container mx-auto p-6 max-w-6xl">
        <h1 class="text-3xl font-bold text-blue-600 mb-6">ระบบจัดการข้อมูล (แอดมิน)</h1>
        
        <p class="mb-6 text-lg">
            สวัสดีคุณ <span class="font-semibold text-blue-700"><?php echo htmlspecialchars($_SESSION['user']['username']); ?></span>, 
            นี่คือหน้าที่คุณสามารถ เพิ่ม/ลบ/แก้ไข ข้อมูลทั้งหมดในระบบได้
        </p>

        <!-- 
          ส่วนนี้คือที่แอดมินจะทำงาน
          (ตาม Requirement 1, 2, 3 ของคุณ)
        -->
        
        <!-- 1. จัดการประเภทสถานที่ -->
        <div class="bg-white p-6 rounded-lg shadow-md mb-6">
            <h2 class="text-2xl font-semibold mb-4">1. จัดการประเภทสถานที่</h2>
            <p class="mb-4 text-gray-700">(เช่น สถานที่ท่องเที่ยว, ที่พัก, ร้านอาหาร...)</p>
            <a href="manage_categories.php" class="bg-green-500 text-white px-4 py-2 rounded-lg hover:bg-green-600 transition">
                + เพิ่ม/ลบ/แก้ไข ประเภท
            </a>
            <!-- (คุณต้องสร้างตาราง SELECT * FROM categories ที่นี่) -->
        </div>

        <!-- 2. จัดการสถานที่ -->
        <div class="bg-white p-6 rounded-lg shadow-md mb-6">
            <h2 class="text-2xl font-semibold mb-4">2. จัดการสถานที่</h2>
            <a href="manage_places_list.php" class="bg-green-500 text-white px-4 py-2 rounded-lg hover:bg-green-600 transition">
                + เพิ่ม/ลบ/แก้ไข สถานที่
            </a>
            <!-- (ตาราง SELECT * FROM places ที่นี่) -->
        </div>
        
        <!-- 3. จัดการสินค้าชุมชน -->
        <div class="bg-white p-6 rounded-lg shadow-md">
            <h2 class="text-2xl font-semibold mb-4">3. จัดการสินค้าชุมชน</h2>
            <a href="manage_products.php" class="bg-green-500 text-white px-4 py-2 rounded-lg hover:bg-green-600 transition">
                + เพิ่ม/ลบ/แก้ไข สินค้า
            </a>
            <!-- (ตาราง SELECT * FROM products ที่นี่) -->
        </div>

    </div>
</body>
</html>
