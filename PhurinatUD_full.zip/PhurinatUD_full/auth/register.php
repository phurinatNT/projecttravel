<!DOCTYPE html>
<html lang="th">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>สมัครสมาชิก | PhurinatUD</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Athiti:wght@300;400;700&display=swap" rel="stylesheet">
    <link href="../assets/css/style.css" rel="stylesheet">
    <style>
        body { 
            font-family: 'Athiti', sans-serif; 
            background: linear-gradient(135deg, #fff5eb 0%, #ffe4cc 100%);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        .register-card {
            background: rgba(255, 255, 255, 0.9);
            backdrop-filter: blur(10px);
            border-radius: 25px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
            padding: 40px;
            max-width: 400px;
            width: 100%;
        }
        .btn-register {
            background-color: #ff6600;
            border: none;
            color: white;
            padding: 12px;
            border-radius: 10px;
            font-weight: 600;
        }
        .btn-register:hover {
            background-color: #ff8533;
            color: white;
        }
    </style>
</head>
<body>
<?php include('../includes/navbar.php'); ?>
<div class="register-card">
  <h2 class="text-center fw-bold mb-4" style="color: #ff6600;">สมัครสมาชิก</h2>
  <form action='register_process.php' method='post'>
    <div class="mb-3">
      <input type='text' name='username' placeholder='ชื่อผู้ใช้' class='form-control' required>
    </div>
    <div class="mb-3">
      <input type='email' name='email' placeholder='อีเมล' class='form-control' required>
    </div>
    <div class="mb-3">
      <input type='password' name='password' placeholder='รหัสผ่าน' class='form-control' required>
    </div>
    <div class="mb-3">
      <input type='password' name='confirm_password' placeholder='ยืนยันรหัสผ่าน' class='form-control' required>
    </div>
    <button type="submit" class='btn btn-register w-100'>สมัครสมาชิก</button>
  </form>
  <p class='mt-3 text-center text-muted'>มีบัญชีอยู่แล้ว? <a href='login.php' style='color: #ff6600; text-decoration: none;'>เข้าสู่ระบบ</a></p>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>