<?php
// ต้องเรียก session_start() ไว้บนสุดของไฟล์เสมอ
session_start(); 
?>
<!DOCTYPE html>
<html lang="th">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>เข้าสู่ระบบ | PhurinatUD</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Athiti:wght@300;400;700&display=swap" rel="stylesheet">
    <link href="../assets/css/style.css" rel="stylesheet">
    <style>
        body { 
            font-family: 'Athiti', sans-serif; 
            background: linear-gradient(135deg, #fff5eb 0%, #ffe4cc 100%);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        .login-card {
            background: rgba(255, 255, 255, 0.9);
            backdrop-filter: blur(10px);
            border-radius: 25px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
            padding: 40px;
            max-width: 400px;
            width: 100%;
        }
        .btn-login {
            background-color: #ff6600;
            border: none;
            color: white;
            padding: 12px;
            border-radius: 10px;
            font-weight: 600;
        }
        .btn-login:hover {
            background-color: #ff8533;
            color: white;
        }
    </style>
</head>
<body>
<?php include('../includes/navbar.php'); ?>
    <div class="login-card">
        <h2 class="text-center fw-bold mb-4" style="color: #ff6600;">เข้าสู่ระบบ</h2>

        <?php
        // ตรวจสอบว่ามี error ใน SESSION หรือไม่
        if (isset($_SESSION['error'])) {
            // แสดงกล่องข้อความ error
            echo "<div class='alert alert-danger' role='alert'>";
            // ใช้ htmlspecialchars เพื่อความปลอดภัย
            echo htmlspecialchars($_SESSION['error']); 
            echo "</div>";
            
            // ลบ error ออกจาก session เพื่อไม่ให้แสดงซ้ำ
            unset($_SESSION['error']);
        }
        ?>

        <form action='login_process.php' method='post'>
            <div class="mb-3">
                <label for="username" class="form-label">ชื่อผู้ใช้</label>
                <input type='text' id="username" name='username' placeholder='ชื่อผู้ใช้' class='form-control' required>
            </div>
            <div class="mb-3">
                <label for="password" class="form-label">รหัสผ่าน</label>
                <input type='password' id="password" name='password' placeholder='รหัสผ่าน' class='form-control' required>
            </div>
            <button type="submit" class='btn btn-login w-100'>เข้าสู่ระบบ</button>
        </form>
        <p class='mt-3 text-center text-muted'>ยังไม่มีบัญชี? <a href='register.php' style='color: #ff6600; text-decoration: none;'>สมัครสมาชิก</a></p>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>