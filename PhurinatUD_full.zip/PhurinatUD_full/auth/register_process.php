<?php
require_once '../config/db.php';
$username = $_POST['username'] ?? '';
$email = $_POST['email'] ?? '';
$password = $_POST['password'] ?? '';
$confirm = $_POST['confirm_password'] ?? '';
if(!$username || !$email || !$password){ header('Location: register.php?err=1'); exit; }
if($password !== $confirm){ header('Location: register.php?err=2'); exit; }
$hash = password_hash($password, PASSWORD_DEFAULT);
$stmt = $mysqli->prepare('INSERT INTO users (username,password,email) VALUES (?,?,?)');
$stmt->bind_param('sss',$username,$hash,$email);
if($stmt->execute()){
  header('Location: login.php?reg=1'); exit;
} else {
  header('Location: register.php?err=3'); exit;
}
