
</main>
<footer class="footer">
  &copy; <?php echo date('Y'); ?> PhurinatTour — ภูริณัฐท่องเที่ยว จังหวัดอุดรธานี
</footer>
<script src="https://unpkg.com/aos@next/dist/aos.js"></script>
<script> AOS.init({once:true}); </script>
</body></html>
